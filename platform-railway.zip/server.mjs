/* ==========================================================================
  Habiba teacher   onlayn o'quv platformasi
  Node.js + SQLite, tashqi kutubxonalarsiz.
  Ishga tushirish: node server.mjs  (yoki start-platform.bat)
  ========================================================================== */
import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { randomBytes, randomInt, scryptSync, timingSafeEqual, createHmac } from "node:crypto";
import { Readable } from "node:stream";
import { spawn } from "node:child_process";
import { inflateRawSync } from "node:zlib";
import { DatabaseSync } from "node:sqlite";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

function readJsonConfig(file) {
  try {
    return JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
  } catch (e) {
    return {};
  }
}

const fileConfig = readJsonConfig(path.join(__dirname, "config.json"));
const config = {
  siteName: "Habiba teacher",
  maxUploadMb: 100,
  notifyOnFinish: true,
  ...fileConfig,
  ...(process.env.SITE_NAME ? { siteName: process.env.SITE_NAME } : {}),
  ...(process.env.ADMIN_PASSWORD ? { adminPassword: process.env.ADMIN_PASSWORD } : {}),
  ...(process.env.TELEGRAM_BOT_TOKEN ? { telegramBotToken: process.env.TELEGRAM_BOT_TOKEN } : {}),
  ...(process.env.TELEGRAM_BOT_USERNAME ? { telegramBotUsername: process.env.TELEGRAM_BOT_USERNAME } : {}),
  ...(process.env.TELEGRAM_CHAT_ID ? { telegramChatId: process.env.TELEGRAM_CHAT_ID } : {}),
  ...(process.env.TELEGRAM_URL ? { telegram: process.env.TELEGRAM_URL } : {}),
  ...(process.env.CONTACT_PHONE ? { phone: process.env.CONTACT_PHONE } : {}),
  ...(process.env.APP_URL ? { appUrl: process.env.APP_URL } : {}),
  ...(process.env.MAX_UPLOAD_MB ? { maxUploadMb: Number(process.env.MAX_UPLOAD_MB) || 60 } : {}),
  ...(process.env.NOTIFY_ON_FINISH ? { notifyOnFinish: process.env.NOTIFY_ON_FINISH !== "0" } : {}),
};
const PORT = Number(process.env.PORT || config.port || 8788);
const VOLUME_DIR = process.env.RAILWAY_VOLUME_MOUNT_PATH || "";
const DATA_DIR = process.env.DATA_DIR
  ? path.resolve(process.env.DATA_DIR)
  : VOLUME_DIR
  ? path.join(VOLUME_DIR, "data")
  : path.join(__dirname, "data");
const STORAGE_DIR = process.env.STORAGE_DIR
  ? path.resolve(process.env.STORAGE_DIR)
  : VOLUME_DIR
  ? path.join(VOLUME_DIR, "storage")
  : path.join(__dirname, "storage");
const PUBLIC_DIR = path.join(__dirname, "public");
const MAX_UPLOAD = Number(config.maxUploadMb || 60) * 1024 * 1024;

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(STORAGE_DIR, { recursive: true });

const nowISO = () => new Date().toISOString();

function metaGet(key, fallback = "") {
  const row = db.prepare("SELECT value FROM meta WHERE key = ?").get(key);
  return row ? row.value: fallback;
}

function metaSet(key, value) {
  db.prepare(
  "INSERT INTO meta (key, value) VALUES (?, ?) ON CONFLICT(key) DO UPDATE SET value = excluded.value"
  ).run(key, String(value));
}

const DEFAULT_CONTRACT_TEXT = `1. Umumiy qoidalar
1.1. Ushbu shartnoma "Habiba teacher" onlayn ta'lim platformasidan foydalanish tartibini belgilaydi.
1.2. Platformadan foydalanishni boshlash orqali siz ushbu shartlar bilan tanishganingizni va ularga rozilik bildirganingizni tasdiqlaysiz.

2. Taqdim etiladigan xizmatlar
2.1. Platforma attestatsiya va TKT yo'nalishlari bo'yicha testlar, metodik materiallar, demo darslar va boshqa o'quv resurslarini taqdim etadi.
2.2. Materiallar faqat shaxsiy ta'lim maqsadlarida foydalanish uchun beriladi.

3. Foydalanuvchining majburiyatlari
3.1. Hisob ma'lumotlari (parol, kirish kodi) maxfiy saqlanishi foydalanuvchining zimmasida.
3.2. Platforma materiallarini ruxsatsiz ko'chirish, tarqatish yoki sotish taqiqlanadi.
3.3. Boshqa foydalanuvchilarga xalaqit berish, tizimga ruxsatsiz kirishga urinish taqiqlanadi.

4. Mualliflik huquqi
4.1. Platformadagi barcha testlar, matnlar, videolar va boshqa materiallar mualliflik huquqi bilan himoyalangan.
4.2. Materiallardan tijoriy maqsadda foydalanish faqat yozma ruxsat bilan amalga oshiriladi.

5. Shaxsiy ma'lumotlar
5.1. Foydalanuvchining ismi, telefon raqami va Telegram ID'si faqat platforma xizmatlarini ko'rsatish uchun ishlatiladi.
5.2. Shaxsiy ma'lumotlar uchinchi shaxslarga ruxsatsiz berilmaydi.

6. Yakuniy qoidalar
6.1. Platforma ma'muriyati xizmat shartlarini yangilash huquqini saqlab qoladi.
6.2. Shartlar buzilganda akkaunt vaqtincha yoki butunlay bloklanishi mumkin.`;

function contractText() {
  return metaGet("contract_text", DEFAULT_CONTRACT_TEXT) || DEFAULT_CONTRACT_TEXT;
}

const db = new DatabaseSync(path.join(DATA_DIR, "platform.db"));
db.exec(`
  PRAGMA journal_mode = WAL;
  PRAGMA foreign_keys = ON;

  CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  phone TEXT NOT NULL UNIQUE,
  pass TEXT NOT NULL,
  telegram_id TEXT,
  created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  expires_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS admin_sessions (
  token TEXT PRIMARY KEY,
  expires_at INTEGER NOT NULL
  );

  CREATE TABLE IF NOT EXISTS courses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  title TEXT NOT NULL,
  description TEXT DEFAULT '',
  category TEXT NOT NULL DEFAULT 'attestation',
  is_published INTEGER NOT NULL DEFAULT 1,
  created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS lessons (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  course_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  type TEXT NOT NULL,
  content TEXT DEFAULT '',
  video_url TEXT DEFAULT '',
  file_id TEXT DEFAULT '',
  file_name TEXT DEFAULT '',
  file_size INTEGER DEFAULT 0,
  duration_min INTEGER NOT NULL DEFAULT 30,
  position INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS questions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id INTEGER NOT NULL,
  text TEXT NOT NULL,
  o1 TEXT NOT NULL,
  o2 TEXT NOT NULL,
  o3 TEXT NOT NULL,
  o4 TEXT NOT NULL,
  correct INTEGER NOT NULL,
  passage TEXT NOT NULL DEFAULT ''
  );

  CREATE TABLE IF NOT EXISTS test_sections (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  from_no INTEGER NOT NULL DEFAULT 1,
  to_no INTEGER NOT NULL DEFAULT 0,
  passage TEXT NOT NULL DEFAULT '',
  position INTEGER NOT NULL DEFAULT 0
  );

  CREATE TABLE IF NOT EXISTS progress (
  user_id INTEGER NOT NULL,
  lesson_id INTEGER NOT NULL,
  score INTEGER,
  completed_at TEXT NOT NULL,
  PRIMARY KEY (user_id, lesson_id)
  );

  CREATE TABLE IF NOT EXISTS enrollments (
  user_id INTEGER NOT NULL,
  course_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, course_id)
  );

  CREATE TABLE IF NOT EXISTS purchases (
  user_id INTEGER NOT NULL,
  lesson_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, lesson_id)
  );

  CREATE TABLE IF NOT EXISTS materials (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  lesson_id INTEGER NOT NULL,
  title TEXT NOT NULL,
  type TEXT NOT NULL DEFAULT 'link',
  url TEXT DEFAULT '',
  file_id TEXT DEFAULT '',
  file_name TEXT DEFAULT '',
  file_size INTEGER DEFAULT 0,
  body TEXT DEFAULT '',
  created_at TEXT NOT NULL
  );

  CREATE TABLE IF NOT EXISTS duels (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  code TEXT NOT NULL UNIQUE,
  lesson_id INTEGER NOT NULL,
  creator_id INTEGER NOT NULL,
  opponent_id INTEGER,
  status TEXT NOT NULL DEFAULT 'waiting',
  created_at TEXT NOT NULL,
  finished_at TEXT
  );

  CREATE TABLE IF NOT EXISTS duel_plays (
  duel_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  score INTEGER NOT NULL,
  correct INTEGER NOT NULL,
  total INTEGER NOT NULL,
  elapsed_ms INTEGER NOT NULL,
  finished_at TEXT NOT NULL,
  PRIMARY KEY (duel_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS duel_starts (
  duel_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  started_at TEXT NOT NULL,
  PRIMARY KEY (duel_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS tournaments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  day TEXT NOT NULL,
  group_no INTEGER NOT NULL DEFAULT 1,
  test_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  size INTEGER NOT NULL DEFAULT 8,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT,
  UNIQUE(day, group_no)
  );

  CREATE TABLE IF NOT EXISTS tournament_entries (
  tournament_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  seed INTEGER NOT NULL,
  joined_at TEXT NOT NULL,
  PRIMARY KEY (tournament_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS tournament_matches (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  tournament_id INTEGER NOT NULL,
  round INTEGER NOT NULL,
  slot INTEGER NOT NULL,
  p1 INTEGER,
  p2 INTEGER,
  winner INTEGER,
  s1 INTEGER,
  s2 INTEGER,
  t1 INTEGER,
  t2 INTEGER,
  status TEXT NOT NULL DEFAULT 'pending',
  created_at TEXT NOT NULL,
  finished_at TEXT
  );

  CREATE TABLE IF NOT EXISTS tournament_starts (
  match_id INTEGER NOT NULL,
  user_id INTEGER NOT NULL,
  started_at TEXT NOT NULL,
  PRIMARY KEY (match_id, user_id)
  );

  CREATE TABLE IF NOT EXISTS meta (
  key TEXT PRIMARY KEY,
  value TEXT NOT NULL
  );
`);

/* Telegram ID   bitta ID, bitta akkaunt */
const userCols = db.prepare("PRAGMA table_info(users)").all();
if (!userCols.some((c) => c.name === "telegram_id")) {
  db.exec("ALTER TABLE users ADD COLUMN telegram_id TEXT");
}
db.exec(
  "CREATE UNIQUE INDEX IF NOT EXISTS idx_users_telegram_id ON users(telegram_id) WHERE telegram_id IS NOT NULL AND telegram_id <> ''"
);

/* Eski bitta-kunlik turnir jadvalini guruhli jadvalga o'tkazish */
const tournamentCols = db.prepare("PRAGMA table_info(tournaments)").all();
if (!tournamentCols.some((c) => c.name === "group_no")) {
  db.exec(`
  ALTER TABLE tournaments RENAME TO tournaments_legacy;
  CREATE TABLE tournaments (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  day TEXT NOT NULL,
  group_no INTEGER NOT NULL DEFAULT 1,
  test_id INTEGER NOT NULL,
  status TEXT NOT NULL DEFAULT 'open',
  size INTEGER NOT NULL DEFAULT 8,
  created_at TEXT NOT NULL,
  started_at TEXT,
  finished_at TEXT,
  UNIQUE(day, group_no)
  );
  INSERT INTO tournaments (id, day, group_no, test_id, status, size, created_at, started_at, finished_at)
  SELECT id, day, 1, test_id, status, 8, created_at, started_at, finished_at FROM tournaments_legacy;
  DROP TABLE tournaments_legacy;
  `);
}

const adminSessionCols = db.prepare("PRAGMA table_info(admin_sessions)").all();
if (!adminSessionCols.some((c) => c.name === "ip")) {
  db.exec("ALTER TABLE admin_sessions ADD COLUMN ip TEXT NOT NULL DEFAULT ''");
}

const contractUserCols = db.prepare("PRAGMA table_info(users)").all();
if (!contractUserCols.some((c) => c.name === "contract_accepted_at")) {
  db.exec("ALTER TABLE users ADD COLUMN contract_accepted_at TEXT NOT NULL DEFAULT ''");
}

db.prepare("DELETE FROM sessions WHERE expires_at < ?").run(Date.now());
db.prepare("DELETE FROM admin_sessions WHERE expires_at < ?").run(Date.now());

db.exec(`CREATE TABLE IF NOT EXISTS duel_questions (
  duel_id INTEGER NOT NULL,
  question_id INTEGER NOT NULL,
  position INTEGER NOT NULL,
  PRIMARY KEY (duel_id, position)
)`);

db.exec(`CREATE TABLE IF NOT EXISTS tournament_questions (
  tournament_id INTEGER NOT NULL,
  question_id INTEGER NOT NULL,
  position INTEGER NOT NULL,
  PRIMARY KEY (tournament_id, position)
)`);

const duelCols = db.prepare("PRAGMA table_info(duels)").all();
if (!duelCols.some((c) => c.name === "title")) {
  db.exec("ALTER TABLE duels ADD COLUMN title TEXT NOT NULL DEFAULT ''");
}

db.exec(`CREATE TABLE IF NOT EXISTS device_sessions (
  token TEXT PRIMARY KEY,
  user_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  last_seen TEXT NOT NULL
)`);

db.exec(`CREATE TABLE IF NOT EXISTS login_codes (
  phone TEXT PRIMARY KEY,
  code_hash TEXT NOT NULL,
  expires_at INTEGER NOT NULL,
  attempts INTEGER NOT NULL DEFAULT 0,
  created_at TEXT NOT NULL
)`);

db.exec(`CREATE TABLE IF NOT EXISTS likes (
  user_id INTEGER NOT NULL,
  lesson_id INTEGER NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY (user_id, lesson_id)
)`);

db.exec(`CREATE TABLE IF NOT EXISTS video_watch (
  user_id INTEGER NOT NULL,
  lesson_id INTEGER NOT NULL,
  max_seconds REAL NOT NULL DEFAULT 0,
  duration REAL NOT NULL DEFAULT 0,
  updated_at TEXT NOT NULL,
  PRIMARY KEY (user_id, lesson_id)
)`);

// Eski bazalarga ustun qo'shish
const lessonCols = db.prepare("PRAGMA table_info(lessons)").all();
if (!lessonCols.some((c) => c.name === "duration_min")) {
  db.exec("ALTER TABLE lessons ADD COLUMN duration_min INTEGER NOT NULL DEFAULT 30");
}

const courseCols = db.prepare("PRAGMA table_info(courses)").all();
if (!courseCols.some((c) => c.name === "category")) {
  db.exec("ALTER TABLE courses ADD COLUMN category TEXT NOT NULL DEFAULT 'attestation'");
}
if (!courseCols.some((c) => c.name === "is_test_group")) {
  db.exec("ALTER TABLE courses ADD COLUMN is_test_group INTEGER NOT NULL DEFAULT 0");
}

/* Test kartochkalari uchun qo'shimcha ustunlar */
const extraLessonCols = [
  ["price", "INTEGER NOT NULL DEFAULT 0"],
  ["is_pro", "INTEGER NOT NULL DEFAULT 0"],
  ["max_score", "INTEGER NOT NULL DEFAULT 100"],
  ["question_count", "INTEGER NOT NULL DEFAULT 0"],
  ["likes", "INTEGER NOT NULL DEFAULT 0"],
  ["views", "INTEGER NOT NULL DEFAULT 0"],
  ["about", "TEXT NOT NULL DEFAULT ''"]
];
for (const [name, def] of extraLessonCols) {
  if (!lessonCols.some((c) => c.name === name)) {
  db.exec(`ALTER TABLE lessons ADD COLUMN ${name} ${def}`);
  }
}

/* Savol matni (passage) ustuni */
const questionCols = db.prepare("PRAGMA table_info(questions)").all();
if (!questionCols.some((c) => c.name === "passage")) {
  db.exec("ALTER TABLE questions ADD COLUMN passage TEXT NOT NULL DEFAULT ''");
}

/* Boshlang'ich katalog   attestatsiya va TKT testlari ro'yxati */
function ensureDemoContent() {
  const already = db.prepare("SELECT value FROM meta WHERE key = 'mk_catalog_v1'").get();
  if (already && already.value === "1") return;

  function ensureCourse({ legacyTitle, title, description, category, isTestGroup = 1 }) {
  let course = db.prepare("SELECT * FROM courses WHERE title = ? ORDER BY id LIMIT 1").get(title);
  if (!course && legacyTitle) {
  course = db.prepare("SELECT * FROM courses WHERE title = ? ORDER BY id LIMIT 1").get(legacyTitle);
  if (course) {
  db.prepare(
  "UPDATE courses SET title = ?, description = ?, category = ?, is_test_group = ? WHERE id = ?"
  ).run(title, description, category, isTestGroup, course.id);
  }
  }
  if (course) {
  db.prepare("UPDATE courses SET description = ?, category = ?, is_test_group = ? WHERE id = ?").run(
  description,
  category,
  isTestGroup,
  course.id
  );
  return course.id;
  }
  const info = db
.prepare("INSERT INTO courses (title, description, category, is_test_group, created_at) VALUES (?, ?, ?, ?, ?)")
.run(title, description, category, isTestGroup, nowISO());
  return Number(info.lastInsertRowid);
  }

  function putTest(courseId, spec, position, legacyTitle) {
  let lesson = db.prepare("SELECT * FROM lessons WHERE title = ? ORDER BY id LIMIT 1").get(spec.title);
  if (!lesson && legacyTitle) {
  lesson = db.prepare("SELECT * FROM lessons WHERE title = ? ORDER BY id LIMIT 1").get(legacyTitle);
  }
  const price = Number(spec.price) || 0;
  const isPro = price > 0 ? 1: 0;
  if (lesson) {
  db.prepare(
  `UPDATE lessons SET course_id = ?, title = ?, type = 'test', duration_min = ?, position = ?,
  price = ?, is_pro = ?, max_score = ?, question_count = ?, likes = ?, views = ?
  WHERE id = ?`
  ).run(
  courseId,
  spec.title,
  spec.duration,
  position,
  price,
  isPro,
  spec.max,
  spec.qcount,
  spec.likes,
  spec.views,
  lesson.id
  );
  return;
  }
  db.prepare(
  `INSERT INTO lessons
  (course_id, title, type, content, duration_min, position, price, is_pro, max_score, question_count, likes, views, created_at)
  VALUES (?, ?, 'test', '', ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(
  courseId,
  spec.title,
  spec.duration,
  position,
  price,
  isPro,
  spec.max,
  spec.qcount,
  spec.likes,
  spec.views,
  nowISO()
  );
  }

  const t = (title, duration, qcount, max, likes, views, price = 0) => ({
  title,
  duration,
  qcount,
  max,
  likes,
  views,
  price
  });

  const toifa = [
  t("Attestatsiya Ingliz tili Mock test 1", 90, 50, 100, 5, 118),
  t("Attestatsiya Ingliz tili Mock Test 2", 90, 50, 100, 0, 59),
  t("Attestatsiya Demo test 2025, Bahor", 60, 35, 70, 2, 27),
  t("Attestatsiya Demo test 2024, Kuz", 60, 35, 70, 1, 16),
  t("Kasbiy Standartlash Demo testi 2025", 60, 40, 80, 5, 52),
  t("SINOV.UZ DEMO TESTI 2025 KUZ", 90, 50, 100, 3, 110),
  t("Ingliz tili Attestatsiya Repititsion test 2026 Bahor", 105, 50, 100, 17, 388)
  ];

  const mockLikes = [4, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 0, 0, 0, 0, 0, 0];
  const mockViews = [71, 19, 9, 5, 10, 12, 3, 12, 6, 4, 7, 7, 3, 8, 13, 2, 4, 4, 7, 1];
  const mocks = Array.from({ length: 20 }, (_, i) =>
  t(`2026 FALL MOCK ${i + 1}`, 105, 50, 100, mockLikes[i], mockViews[i], 20000)
  );

  const readings = [t("Advanced Passage 1", 60, 9, 0, 0, 50, 2000)];

  const tkt1 = [t("TKT 1-modul mock testi 1", 80, 80, 80, 2, 16), t("TKT 1-modul mock testi 2", 80, 80, 80, 1, 61)];
  const tkt2 = [t("TKT 2-modul mock testi 1", 80, 80, 80, 0, 9), t("TKT 2-modul mock testi 2", 80, 80, 80, 0, 11)];
  const tkt3 = [t("TKT 3-modul mock testi 1", 80, 80, 80, 0, 7), t("TKT 3-modul amaliy testi 2", 80, 80, 0, 0, 8)];

  const toifaId = ensureCourse({
  legacyTitle: "Attestatsiya   mock testlar",
  title: "Toifa testlari",
  description: "O'qituvchilar uchun bepul toifa testlari.",
  category: "attestation"
  });
  toifa.forEach((spec, i) => putTest(toifaId, spec, i + 1, i === 0 ? "MOCK 1   Reading": undefined));

  const mocksId = ensureCourse({
  title: "2026 KUZ PLATFORMA MOCKLARI",
  description: "2026 kuz mavsumi platforma mock testlari.",
  category: "attestation"
  });
  mocks.forEach((spec, i) => putTest(mocksId, spec, i + 1));

  const readingsId = ensureCourse({
  title: "Attestatsiya Readinglari",
  description: "Attestatsiya uchun advanced reading passage testlari.",
  category: "attestation"
  });
  readings.forEach((spec, i) => putTest(readingsId, spec, i + 1));

  const tkt1Id = ensureCourse({
  legacyTitle: "TKT   mock testlar",
  title: "TKT MODULE 1",
  description: "TKT 1-modul: til tizimi va o'qitish metodikasi asoslari.",
  category: "tkt"
  });
  tkt1.forEach((spec, i) => putTest(tkt1Id, spec, i + 1, i === 0 ? "TKT MOCK 1   Methodology": undefined));

  const tkt2Id = ensureCourse({
  title: "TKT MODULE 2",
  description: "TKT 2-modul: dars rejalashtirish va resurslardan foydalanish.",
  category: "tkt"
  });
  tkt2.forEach((spec, i) => putTest(tkt2Id, spec, i + 1));

  const tkt3Id = ensureCourse({
  title: "TKT MODULE 3",
  description: "TKT 3-modul: sinfni boshqarish va o'quvchilarni qo'llab-quvvatlash.",
  category: "tkt"
  });
  tkt3.forEach((spec, i) => putTest(tkt3Id, spec, i + 1));

  db.prepare("INSERT INTO meta (key, value) VALUES ('mk_catalog_v1', '1') ON CONFLICT(key) DO UPDATE SET value = '1'").run();
  console.log("[seed] attestatsiya va TKT test katalogi qo'shildi");
}

ensureDemoContent();

/* Test guruhi kurslarini umumiy kurslar ro'yxatidan yashirish */
db.prepare(
  `UPDATE courses SET is_test_group = 1
  WHERE title IN ('Toifa testlari', '2026 KUZ PLATFORMA MOCKLARI', 'Attestatsiya Readinglari',
  'TKT MODULE 1', 'TKT MODULE 2', 'TKT MODULE 3')`
).run();

/* ------------------------------------------------------------------ utils */
const h = (v) =>
  String(v == null ? "": v)
.replace(/&/g, "&amp;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;")
.replace(/"/g, "&quot;")
.replace(/'/g, "&#39;");

const nl2br = (s) => h(s).replace(/\r?\n/g, "<br>");

/* ------------------------------------------------ test import (xlsx/docx) */
function zipEntries(buffer) {
  const entries = new Map();
  let end = -1;
  for (let i = buffer.length - 22; i >= Math.max(0, buffer.length - 66000); i -= 1) {
  if (buffer.readUInt32LE(i) === 0x06054b50) {
  end = i;
  break;
  }
  }
  if (end < 0) return entries;
  const count = buffer.readUInt16LE(end + 10);
  let ptr = buffer.readUInt32LE(end + 16);
  for (let i = 0; i < count && ptr + 46 <= buffer.length; i += 1) {
  if (buffer.readUInt32LE(ptr) !== 0x02014b50) break;
  const method = buffer.readUInt16LE(ptr + 10);
  const compSize = buffer.readUInt32LE(ptr + 20);
  const nameLen = buffer.readUInt16LE(ptr + 28);
  const extraLen = buffer.readUInt16LE(ptr + 30);
  const commentLen = buffer.readUInt16LE(ptr + 32);
  const localOff = buffer.readUInt32LE(ptr + 42);
  const name = buffer.toString("utf8", ptr + 46, ptr + 46 + nameLen).replace(/\\/g, "/");
  ptr += 46 + nameLen + extraLen + commentLen;
  if (localOff + 30 > buffer.length || buffer.readUInt32LE(localOff) !== 0x04034b50) continue;
  const localName = buffer.readUInt16LE(localOff + 26);
  const localExtra = buffer.readUInt16LE(localOff + 28);
  const start = localOff + 30 + localName + localExtra;
  const data = buffer.subarray(start, start + compSize);
  try {
  entries.set(name, method === 0 ? Buffer.from(data): inflateRawSync(data));
  } catch (e) {}
  }
  return entries;
}

function xmlDecode(value) {
  return String(value || "")
.replace(/&lt;/g, "<")
.replace(/&gt;/g, ">")
.replace(/&quot;/g, '"')
.replace(/&apos;/g, "'")
.replace(/&#x([0-9a-f]+);/gi, (_, code) => String.fromCodePoint(parseInt(code, 16)))
.replace(/&#(\d+);/g, (_, code) => String.fromCodePoint(Number(code)))
.replace(/&amp;/g, "&");
}

function xmlPlain(value) {
  return xmlDecode(String(value || "").replace(/<[^>]*>/g, " "))
.replace(/\u00a0/g, " ")
.replace(/\s+/g, " ")
.trim();
}

const CRC_TABLE = (() => {
  const table = new Uint32Array(256);
  for (let n = 0; n < 256; n += 1) {
  let c = n;
  for (let k = 0; k < 8; k += 1) c = c & 1 ? 0xedb88320 ^ (c >>> 1): c >>> 1;
  table[n] = c >>> 0;
  }
  return table;
})();

function crc32(buffer) {
  let c = 0xffffffff;
  for (const byte of buffer) c = CRC_TABLE[(c ^ byte) & 0xff] ^ (c >>> 8);
  return (c ^ 0xffffffff) >>> 0;
}

function zipStore(files) {
  const chunks = [];
  const central = [];
  let offset = 0;
  const names = Object.keys(files);
  for (const name of names) {
  const data = files[name];
  const nameBuf = Buffer.from(name, "utf8");
  const crc = crc32(data);
  const local = Buffer.alloc(30);
  local.writeUInt32LE(0x04034b50, 0);
  local.writeUInt16LE(20, 4);
  local.writeUInt16LE(0x0800, 6);
  local.writeUInt16LE(0, 8);
  local.writeUInt16LE(0, 10);
  local.writeUInt16LE(0, 12);
  local.writeUInt32LE(crc, 14);
  local.writeUInt32LE(data.length, 18);
  local.writeUInt32LE(data.length, 22);
  local.writeUInt16LE(nameBuf.length, 26);
  local.writeUInt16LE(0, 28);
  chunks.push(local, nameBuf, data);
  const cen = Buffer.alloc(46);
  cen.writeUInt32LE(0x02014b50, 0);
  cen.writeUInt16LE(20, 4);
  cen.writeUInt16LE(20, 6);
  cen.writeUInt16LE(0x0800, 8);
  cen.writeUInt16LE(0, 10);
  cen.writeUInt16LE(0, 12);
  cen.writeUInt16LE(0, 14);
  cen.writeUInt32LE(crc, 16);
  cen.writeUInt32LE(data.length, 20);
  cen.writeUInt32LE(data.length, 24);
  cen.writeUInt16LE(nameBuf.length, 28);
  cen.writeUInt16LE(0, 30);
  cen.writeUInt16LE(0, 32);
  cen.writeUInt16LE(0, 34);
  cen.writeUInt16LE(0, 36);
  cen.writeUInt32LE(0, 38);
  cen.writeUInt32LE(offset, 42);
  central.push(cen, nameBuf);
  offset += local.length + nameBuf.length + data.length;
  }
  const centralBuf = Buffer.concat(central);
  const end = Buffer.alloc(22);
  end.writeUInt32LE(0x06054b50, 0);
  end.writeUInt16LE(0, 4);
  end.writeUInt16LE(0, 6);
  end.writeUInt16LE(names.length, 8);
  end.writeUInt16LE(names.length, 10);
  end.writeUInt32LE(centralBuf.length, 12);
  end.writeUInt32LE(offset, 16);
  end.writeUInt16LE(0, 20);
  return Buffer.concat([...chunks, centralBuf, end]);
}

function questionsXlsxTemplate() {
  const headers = ["Savol", "A", "B", "C", "D", "Javob", "Matn"];
  const rows = [
  ["She ___ to school every day.", "go", "goes", "going", "gone", "B", ""],
  [
  "Choose the correct sentence",
  "Cats catch mice and dogs.",
  "Cats and dogs catch mice.",
  "Cats catch and dogs mice.",
  "Dogs catch cats and mice.",
  "C",
  "Read the passage and choose the best option."
  ]
  ];
  const colLetters = ["A", "B", "C", "D", "E", "F", "G"];
  const cell = (ref, value) =>
  `<c r="${ref}" t="inlineStr"><is><t>${h(String(value || ""))}</t></is></c>`;
  const sheetRows = [
  `<row r="1">${headers.map((value, i) => cell(`${colLetters[i]}1`, value)).join("")}</row>`,
...rows.map(
  (row, r) =>
  `<row r="${r + 2}">${row.map((value, i) => cell(`${colLetters[i]}${r + 2}`, value)).join("")}</row>`
  )
  ].join("");
  const sheet = `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">
<cols><col min="1" max="1" width="55" customWidth="1"/><col min="2" max="5" width="32" customWidth="1"/><col min="6" max="6" width="10" customWidth="1"/><col min="7" max="7" width="55" customWidth="1"/></cols>
<sheetData>${sheetRows}</sheetData>
</worksheet>`;
  return zipStore({
  "[Content_Types].xml": Buffer.from(
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
<Default Extension="xml" ContentType="application/xml"/>
<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>
<Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>
</Types>`,
  "utf8"
  ),
  "_rels/.rels": Buffer.from(
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/>
</Relationships>`,
  "utf8"
  ),
  "xl/workbook.xml": Buffer.from(
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">
<sheets><sheet name="Savollar" sheetId="1" r:id="rId1"/></sheets>
</workbook>`,
  "utf8"
  ),
  "xl/_rels/workbook.xml.rels": Buffer.from(
  `<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/>
</Relationships>`,
  "utf8"
  ),
  "xl/worksheets/sheet1.xml": Buffer.from(sheet, "utf8")
  });
}

function parseQuestionsFromXlsx(buffer) {  const files = zipEntries(buffer);
  const shared = [];
  const stringsXml = files.get("xl/sharedStrings.xml");
  if (stringsXml) {
  for (const item of stringsXml.toString("utf8").matchAll(/<si\b[\s\S]*?<\/si>/g)) {
  const parts = [...item[0].matchAll(/<t\b[^>]*>([\s\S]*?)<\/t>/g)].map((m) => xmlDecode(m[1]));
  shared.push(parts.join(""));
  }
  }
  const sheetName = [...files.keys()]
.filter((name) => /^xl\/worksheets\/sheet\d+\.xml$/i.test(name))
.sort()[0];
  if (!sheetName) return [];
  const xml = files.get(sheetName).toString("utf8");
  const rows = [];
  for (const rowMatch of xml.matchAll(/<row\b[^>]*>([\s\S]*?)<\/row>/g)) {
  const cells = [];
  for (const cellMatch of rowMatch[1].matchAll(/<c\b([^>]*?)(?:\/>|>([\s\S]*?)<\/c>)/g)) {
  const attrs = cellMatch[1] || "";
  const inner = cellMatch[2] || "";
  const ref = (attrs.match(/\br="([A-Z]+)\d+"/i) || [])[1] || "";
  const type = (attrs.match(/\bt="([^"]+)"/) || [])[1] || "";
  let text = "";
  if (type === "inlineStr") {
  text = xmlPlain((inner.match(/<is\b[\s\S]*?<\/is>/) || [inner])[0]);
  } else {
  const raw = (inner.match(/<v\b[^>]*>([\s\S]*?)<\/v>/) || [])[1] || "";
  text = type === "s" ? shared[Number(raw)] || "": xmlDecode(raw);
  }
  if (!text) continue;
  let col = 0;
  for (const ch of ref.toUpperCase()) col = col * 26 + (ch.charCodeAt(0) - 64);
  cells[col - 1] = text.replace(/\u00a0/g, " ").trim();
  }
  if (cells.some((c) => c)) rows.push(cells);
  }
  return questionsFromRows(rows);
}

function normalizeAnswer(value, options) {
  const text = String(value || "").trim();
  if (!text) return 0;
  const letter = text.match(/^[ABCD]/i);
  if (letter) return "ABCD".indexOf(letter[0].toUpperCase()) + 1;
  if (/^[1-4]$/.test(text)) return Number(text);
  const byText = options.findIndex((option) => option && option.trim().toLowerCase() === text.toLowerCase());
  return byText >= 0 ? byText + 1: 0;
}

function questionsFromRows(rows) {
  const header = (rows[0] || []).map((cell) => String(cell || "").toLowerCase().replace(/[`'"]/g, "").trim());
  const find = (tests) => header.findIndex((cell) => tests.some((test) => test(cell)));
  let map = {
  text: find([(c) => c.includes("savol") && !c.includes("matn"), (c) => c === "question", (c) => c === "text"]),
  o1: find([(c) => c.includes("variant1") || c.includes("1variant") || c === "a" || c === "a1"]),
  o2: find([(c) => c.includes("variant2") || c.includes("2variant") || c === "b" || c === "b1"]),
  o3: find([(c) => c.includes("variant3") || c.includes("3variant") || c === "c" || c === "c1"]),
  o4: find([(c) => c.includes("variant4") || c.includes("4variant") || c === "d" || c === "d1"]),
  correct: find([(c) => c.includes("javob") || c.includes("correct") || c.includes("answer")]),
  passage: find([(c) => c.includes("matn") || c.includes("passage") || c.includes("reading")])
  };
  const detected = map.text >= 0 && map.o1 >= 0 && map.o2 >= 0 && map.o3 >= 0 && map.o4 >= 0 && map.correct >= 0;
  let start = detected ? 1: 0;
  if (!detected) map = { text: 0, o1: 1, o2: 2, o3: 3, o4: 4, correct: 5, passage: 6 };
  const result = [];
  for (let i = start; i < rows.length; i += 1) {
  const row = rows[i];
  const text = String(row[map.text] || "").trim();
  const options = [
  String(row[map.o1] || "").trim(),
  String(row[map.o2] || "").trim(),
  String(row[map.o3] || "").trim(),
  String(row[map.o4] || "").trim()
  ];
  const correct = normalizeAnswer(row[map.correct], options);
  if (!text || options.some((option) => !option) || !correct) continue;
  result.push({
  text: text.replace(/^\d+[.)]\s*/, ""),
  o1: options[0],
  o2: options[1],
  o3: options[2],
  o4: options[3],
  correct,
  passage: map.passage >= 0 ? String(row[map.passage] || "").trim(): ""
  });
  }
  return result;
}

function parseQuestionsFromDocx(buffer) {
  const files = zipEntries(buffer);
  const documentXml = files.get("word/document.xml");
  if (!documentXml) return [];
  const xml = documentXml.toString("utf8");
  const paragraphs = [];
  for (const para of xml.matchAll(/<w:p\b[\s\S]*?<\/w:p>/g)) {
  const texts = [...para[0].matchAll(/<w:t\b[^>]*>([\s\S]*?)<\/w:t>/g)].map((m) => xmlDecode(m[1]));
  const line = texts.join("").replace(/\u00a0/g, " ").trim();
  paragraphs.push(line);
  }
  const optionRe = /^([A-D-   ])[).\-:]\s*(.+)$/i;
  const answerRe = /^(?:javob|to'g'ri javob|togri javob|answer|correct)\s*[:\-]\s*(.+)$/i;
  const passageRe = /^(?:matn|passage|reading|matn:)\s*[:\-]\s*(.*)$/i;
  const result = [];
  let current = null;
  let passageMode = false;
  const flush = () => {
  if (current && current.text && current.options.length === 4 && current.correct) {
  result.push({
  text: current.text,
  o1: current.options[0],
  o2: current.options[1],
  o3: current.options[2],
  o4: current.options[3],
  correct: current.correct,
  passage: current.passage.join("\n").trim()
  });
  }
  current = null;
  passageMode = false;
  };
  for (const line of paragraphs) {
  if (!line) {
  passageMode = false;
  continue;
  }
  const numbered = line.match(/^(\d+)\s*[.)]\s*(.+)$/);
  if (numbered && (!current || current.options.length === 4 || current.correct)) {
  flush();
  current = { text: numbered[2].trim(), options: [], correct: 0, passage: [] };
  continue;
  }
  const answer = line.match(answerRe);
  if (answer && current && !current.correct) {
  current.correct = normalizeAnswer(answer[1], current.options);
  passageMode = false;
  continue;
  }
  const passage = line.match(passageRe);
  if (passage && current) {
  passageMode = true;
  if (passage[1].trim()) current.passage.push(passage[1].trim());
  continue;
  }
  const option = line.match(optionRe);
  if (option && current && current.options.length < 4 && !current.correct) {
  current.options.push(option[2].trim());
  passageMode = false;
  continue;
  }
  if (passageMode && current) {
  current.passage.push(line);
  continue;
  }
  if (!current) {
  current = { text: line, options: [], correct: 0, passage: [] };
  } else if (current.options.length === 4 && !current.correct) {
  flush();
  current = { text: line, options: [], correct: 0, passage: [] };
  } else if (!current.correct && current.options.length < 4) {
  current.text += " " + line;
  }
  }
  flush();
  return result;
}


function safeNext(value) {
  const next = String(value || "");
  return next.startsWith("/") && !next.startsWith("//") && !next.startsWith("/\\") ? next: "";
}

/* ------------------------------------------------------------------- i18n */
const LANG_CODES = ["uz", "ru", "en"];
const I18N = {
  ru: {
    "Teaching Knowledge Test (TKT) uchun tayyorgarlik imtihon uslubidagi modul sinov testlari": "Подготовка к Teaching Knowledge Test (TKT) — модульные пробные тесты в экзаменационном формате",
    "Birgalikda natijaga": "Вместе — к результату",
    "Bitta tarif bilan barcha pullik testlarni oching ancha tejamkor.": "Один тариф открывает все платные тесты — гораздо выгоднее.",
    "Attestatsiya yoki TKT o'zingizga kerakli yo'nalishdan boshlang.": "Аттестация или TKT — начните с нужного направления.",
    "Ingliz tili fani o'qituvchilari uchun testlar, metodika va demo dars.": "Тесты, методика и демо-уроки для учителей английского языка.",
    "Teaching Knowledge Test formatidagi metodika va sinf boshqaruvi testlari.": "Тесты по методике и управлению классом в формате Teaching Knowledge Test.",
    "Atestatsiyaga tayyorlov, metodika, demo dars va testlar barchasi bir joyda.": "Подготовка к аттестации, методика, демо-уроки и тесты — всё в одном месте.",
    "Teaching Knowledge Test (TKT) uchun tayyorgarlik imtihon uslubidagi modul sinov testlari.": "Подготовка к Teaching Knowledge Test (TKT) — модульные пробные тесты в экзаменационном формате.",
    "Habiba teacher ingliz tili fani o'qituvchilarini atestatsiyaga tayyorlaydigan onlayn platforma. Testlar, metodika, demo dars va portfolio bo'yicha tizimli materiallar.": "Habiba teacher — онлайн-платформа для подготовки учителей английского языка к аттестации. Системные материалы: тесты, методика, демо-уроки и портфолио.",
    "Har bir dars sinfdagi haqiqiy vaziyatlarga moslashtirilgan.": "Каждый урок адаптирован к реальным ситуациям в классе.",
    "Darslik va qo'llanmalarni platformadan ochish yoki yuklab olish.": "Открывайте учебники и пособия на платформе или скачивайте их.",
    "O'qituvchilar uchun toifa attestatsiyasiga tayyorgarlik sinov testlari, natijalar va javoblar.": "Подготовка учителей к аттестации на категорию — пробные тесты, результаты и ответы.",
    "Barcha yo'nalishlar": "Все направления",
    "Do'stingiz bilan bir testda kuch sinashing. Kod yarating, do'stingiz qo'shilsin va eng ko'p to'g'ri javob bergan yutsin.": "Проверьте силы с другом в одном тесте. Создайте код, пригласите друга — побеждает тот, у кого больше правильных ответов.",
    "Atestatsiyaga tayyorlov kurslari. Kursni ochish uchun tizimga kiring.": "Курсы подготовки к аттестации. Войдите, чтобы открыть курс.",
    "Tugatilgan darslar va o'rtacha test natijasi bo'yicha.": "По пройденным урокам и среднему результату тестов.",
    "Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov: testlar, metodika, demo dars va portfolio.": "Подготовка учителей английского языка к аттестации: тесты, методика, демо-уроки и портфолио.",
    "Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov platformasi.": "Платформа подготовки учителей английского языка к аттестации.",
    "Telegram orqali bog'laning": "Свяжитесь через Telegram",
    "Excel / Word dan yuklash": "Загрузка из Excel / Word",
    "Bo'limlar va matnlar": "Разделы и тексты",
    "Namuna Excel faylni yuklab olish": "Скачать образец Excel",
    "Yuklash": "Загрузить",
    "Savol qo'shish": "Добавить вопрос",
    "Dars qo'shish": "Добавить урок",
    "Yangi savol": "Новый вопрос",
    "Tahrirlash": "Редактировать",
    "Saqlash": "Сохранить",
    "O'chirish": "Удалить",
    "Kurs nomini tahrirlash": "Редактировать название курса",
    "Yangi dars": "Новый урок",
    "Yangi kurs": "Новый курс",
    "Yangi bo'lim": "Новый раздел",
    "Darslar": "Уроки",
    "Savollar": "Вопросы",
    "Ruxsatlar": "Доступы",
    "Materiallar": "Материалы",
    "Test savollari": "Вопросы теста",
    "Bo'limlar": "Разделы",
    "Admin panel": "Админ-панель",
    "Bosh sahifa": "Главная",
    Attestatsiya: "Аттестация",
    TKT: "TKT",
    Duel: "Дуэль",
    Kurslar: "Курсы",
    Tariflar: "Тарифы",
    Reyting: "Рейтинг",
    Kirish: "Войти",
    Chiqish: "Выйти",
    Platforma: "Платформа",
    Admin: "Админ",
    "O'quvchilar": "Ученики",
    "Saytni ko'rish": "Открыть сайт",
    "Biz haqimizda": "О нас",
    "Onlayn o'quv platformasi": "Онлайн-платформа обучения",
    "Hoziroq boshlash": "Начать сейчас",
    "Platformadan foydalanish": "Войти на платформу",
    ATESTATSIYA: "АТТЕСТАЦИЯ",
    "Mock testlar. Metodika. Demo dars": "Мок-тесты. Методика. Демо-урок",
    "Yo'nalishni tanlang": "Выберите направление",
    "Ochish   ": "Открыть",
    "Barcha kurslar": "Все курсы",
    "O'qituvchilar uchun amaliy tayyorlov": "Практическая подготовка для учителей",
    "Haqiqiy formatdagi mock testlar": "Мок-тесты в реальном формате",
    "PDF darslik va qo'llanmalar": "PDF-учебники и пособия",
    "Video tushuntirishlar": "Видео-объяснения",
    "Progress va natijalar nazorati": "Контроль прогресса и результатов",
    "Bilim   amaliyotda kuch.": "Знания — сила на практике.",
    "O'quvchilar": "Ученики",
    Darslar: "Уроки",
    "Tugatilgan darslar": "Пройденные уроки",
    "Nega biz": "Почему мы",
    "Natijaga olib boradigan tayyorlov": "Подготовка, которая приводит к результату",
    "PDF materiallar": "PDF-материалы",
    "Video darslar": "Видео-уроки",
    "Trener tushuntirishlari va amaliy namunalar.": "Объяснения тренера и практические примеры.",
    "Mock testlar": "Мок-тесты",
    "Haqiqiy formatdagi testlar, natija va tahlil.": "Тесты в реальном формате, результаты и анализ.",
    "Atestatsiyaga bugun tayyorlanishni boshlang": "Начните подготовку к аттестации сегодня",
    "Ro'yxatdan o'ting yoki Telegram orqali bog'laning.": "Зарегистрируйтесь или напишите нам в Telegram.",
    "Ro'yxatdan o'tish": "Регистрация",
    "Barcha huquqlar himoyalangan.": "Все права защищены.",
    "  Barcha yo'nalishlar": "Все направления",
    "O'qituvchlar uchun mock testlar": "Мок-тесты для учителей",
    "Attestatsiya testlari": "Тесты аттестации",
    "TKT testlari": "Тесты TKT",
    "Toifa testlari": "Тесты по категории",
    "Ajratilgan vaqt:": "Время:",
    "Savollar soni:": "Вопросы:",
    "Eng yuqori ball:": "Максимальный балл:",
    Bepul: "Бесплатно",
    Ochilgan: "Открыто",
    "Bu testlarni birma-bir sotib olish shart emas": "Не нужно покупать эти тесты по отдельности",
    "Tarifni ko'rish   ": "Посмотреть тарифы",
    Narx: "Цена",
    "Test haqida": "О тесте",
    Materiallar: "Материалы",
    "Materiallar test ochilgach ko'rinadi.": "Материалы откроются после покупки теста.",
    "Natijalar taqsimoti": "Распределение результатов",
    "Har bir ishtirokchining eng yaxshi natijasi asosida": "По лучшему результату каждого участника",
    "70% va yuqori": "70% и выше",
    "Jami qatnashganlar:": "Всего участников:",
    "Testga kirish uchun tizimga kiring": "Войдите, чтобы открыть тест",
    "Testni boshlash": "Начать тест",
    "Qayta topshirish": "Пройти заново",
    "Sizning natijangiz:": "Ваш результат:",
    "Tayyor bo'lsangiz, testni boshlang.": "Когда будете готовы, начните тест.",
    "Telegram orqali sotib olish": "Купить через Telegram",
    "Bu testni tarif bilan oching": "Откройте тест по тарифу",
    "Bitta tarif   barcha pullik testlar uchun.": "Один тариф для всех платных тестов.",
    "Savollar uchun:": "Вопросы:",
    "Eng yaxshi 10 ishtirokchi": "Топ-10 участников",
    "Hozircha natijalar yo'q. Birinchi bo'lib topshiring.": "Пока результатов нет. Будьте первым.",
    "Tavsif va materiallarni tahrirlash   ": "Редактировать описание и материалы",
    Boshqarish: "Управлять",
    "Yangi test qo'shish": "Добавить новый тест",
    Katalog: "Каталог",
    "Bitta to'lov bilan barcha kurs va materiallarga kirish.": "Одна оплата — доступ ко всем курсам и материалам.",
    "Tavsiya etiladi": "Рекомендуется",
    "To'liq kirish": "Полный доступ",
    "Barcha kurslar, PDF materiallar, testlar va yangilanishlar.": "Все курсы, PDF-материалы, тесты и обновления.",
    "/ 3 oy": "/ 3 месяца",
    "Barcha kurslarga kirish": "Доступ ко всем курсам",
    "Mock testlar va natijalar": "Мок-тесты и результаты",
    "Yangi materiallar bepul": "Новые материалы бесплатно",
    "Sotib olish": "Купить",
    "Telefon va parolingizni kiriting.": "Введите телефон и пароль.",
    Telefon: "Телефон",
    Parol: "Пароль",
    "Akkountingiz yo'qmi?": "Нет аккаунта?",
    "Ismingiz": "Ваше имя",
    "Ism, telefon va parolni kiriting.": "Введите имя, телефон и пароль.",
    "Akkountingiz bormi?": "Уже есть аккаунт?",
    "Kamida 6 belgi": "Минимум 6 символов",
    "Eng faol o'quvchilar": "Самые активные ученики",
    "Tugatilgan darslar va o'tacha test natijasi bo'yicha.": "По пройденным урокам и среднему результату тестов.",
    "O'quvchi": "Ученик",
    "Tugatgan darslari": "Пройденные уроки",
    "O'rtacha natija": "Средний результат",
    "Hozircha natijalar yo'q.": "Пока результатов нет.",
    "1-savol": "Вопрос 1",
    "Oldingi": "Назад",
    "Keyingi": "Далее",
    "Yakunlash": "Завершить",
    "Saytga o'tish": "Перейти на сайт",
    "Test yakunlandi": "Тест завершён",
    "Yaxshi natija!": "Хороший результат!",
    "Yana urinib ko'ring": "Попробуйте ещё раз",
    "Testlarga qaytish": "К тестам",
    "Shriftni kichraytirish": "Уменьшить шрифт",
    "Shriftni kattalashtirish": "Увеличить шрифт",
    "Test savollari hali qo'shilmagan": "Вопросы теста ещё не добавлены",
    "Administrator tez orada savollarni qo'shadi.": "Администратор скоро добавит вопросы.",
    "Darsni tugatdim": "Урок завершён",
    "Testni yakunlash": "Завершить тест",
    "Kursga qaytish": "К курсу",
    "Tugatilgan": "Завершено",
    "Ochish": "Открыть",
    Matn: "Текст",
    Video: "Видео",
    Test: "Тест",
    "dars": "уроков",
    "Yakunlandi": "Завершено",
    "Natija": "Результат",
    "Sertifikatlar": "Сертификаты",
    "Til": "Язык",
    "Kunduzgi va tungi rejim": "Дневной и ночной режим",
    "Duel xonasi": "Комната дуэли",
    "1 vs 1": "1 на 1",
    "Raqib kutilmoqda": "Ожидание соперника",
    "Hali o'ynamadi": "Ещё не играл",
    "Kodni do'stingizga yuboring": "Отправьте код другу",
    "Taklif kodi": "Код приглашения",
    "Nusxalash": "Копировать",
    "Do'stga yuborish": "Отправить другу",
    "Duelni bekor qilish": "Отменить дуэль",
    "G'alaba!": "Победа!",
    "Mag'lubiyat": "Поражение",
    "Durang!": "Ничья!",
    "G'olib:": "Победитель:",
    "Yangi duel": "Новая дуэль",
    "Testlarga o'tish": "К тестам",
    "Raqib natijasi kutilmoqda": "Ожидание результата соперника",
    "Tayyormisiz?": "Готовы?",
    "Duelni boshlash a ": "Start duel a\u001d",
    "Faol duellar": "Активные дуэли",
    "Duel tarixi": "История дуэлей",
    "Kod": "Код",
    "Holat": "Статус",
    "Kutilmoqda": "Ожидание",
    "Jonli": "В эфире",
    "Yakunlangan": "Завершено",
    "Xonaga kirish   ": "Войти в комнату",
    "Bepul testlardan birini tanlang.": "Выберите один из бесплатных тестов.",
    "Do'stingiz bergan 6 xonali kodni kiriting.": "Введите 6-значный код от друга.",
    "Qo'shilish": "Присоединиться",
    "Duel yaratish a ": "Create duel a\u001d",
    "Duel   kim kuchli?": "Дуэль — кто сильнее?",
    "Do'stingiz /duel sahifasida shu kodni kiritib qo'shiladi.": "Друг вводит этот код на /duel и присоединяется.",
    "Ikkalangiz teng natija ko'rsatdingiz.": "У вас обоих одинаковый результат.",
    "Kunlik pley-off": "Ежедневный плей-офф",
    "Kunlik duel": "Ежедневная дуэль",
    "Kunlik duel   finalga qadar sxema": "Ежедневная дуэль — сетка до финала",
    "Sxemani ko'rish   ": "Посмотреть сетку",
    "Turnirga qo'shilish a ": "Join the tournament a\u001d",
    "Turnirni boshqarish": "Управление турниром",
    "Turnirni boshlash": "Начать турнир",
    "Siz ro'yxatdasiz": "Вы зарегистрированы",
    "Kunlik duel g'olibi": "Победитель ежедневной дуэли",
    "Aniqlanmadi": "Не определено",
    "Hozircha ishtirokchilar yo'q.": "Пока нет участников.",
    "O'ynash": "Играть",
    "Turnirni boshlash uchun kamida 2 ishtirokchi kerak.": "Для старта нужно минимум 2 участника.",
    "Bugun": "Сегодня",
    "Attestatsiya jarayoni": "Процесс аттестации",
    "Amaliy tayyorlov": "Практическая подготовка",
    "Amaliyotchi o'qituvchi": "Практикующий учитель",
    "Har bir dars   hayotdagi haqiqiy vaziyatlar uchun.": "Каждый урок — для реальных жизненных ситуаций.",
    MATN: "ТЕКСТ",
    SAVOL: "ВОПРОС",
    "Tugatish": "Завершить",
    "Bekor qilish": "Отмена",
    "Ha": "Да",
    "Javob berilgan": "Отвечено",
    "Hozirgi savol": "Текущий вопрос",
    "Testni tugatishni tasdiqlaysizmi?": "Завершить тест?",
    "ta savol javobsiz.": "вопросов без ответа.",
    "Barcha savollarga javob berilgan.": "Все вопросы отвечены.",
  },
  en: {
  "Bosh sahifa": "Home",
  Attestatsiya: "Attestation",
  TKT: "TKT",
  Duel: "Duel",
  Kurslar: "Courses",
  Tariflar: "Plans",
  Reyting: "Rating",
  Kirish: "Log in",
  Chiqish: "Log out",
  Platforma: "Platform",
  Admin: "Admin",
  "O'quvchilar": "Students",
  "Saytni ko'rish": "View site",
  "Biz haqimizda": "About us",
  "Onlayn o'quv platformasi": "Online learning platform",
  "Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov: testlar, metodika, demo dars va portfolio.":
  "Exam preparation for English teachers: tests, methodology, demo lessons and portfolio.",
  "Hoziroq boshlash": "Start now",
  "Platformadan foydalanish": "Use the platform",
  ATESTATSIYA: "ATTESTATION",
  "Mock testlar. Metodika. Demo dars": "Mock tests. Methodology. Demo lesson",
  "Yo'nalishni tanlang": "Choose a direction",
  "Attestatsiya yoki TKT   o'zingizga kerakli yo'nalishdan boshlang.":
  "Attestation or TKT   start with the direction you need.",
  "Ingliz tili fani o'qituvchilari uchun testlar, metodika va demo dars.":
  "Tests, methodology and demo lessons for English teachers.",
  "Ochish   ": "Open   ",
  "Teaching Knowledge Test formatidagi metodika va sinf boshqaruvi testlari.":
  "Methodology and classroom management tests in the Teaching Knowledge Test format.",
  "Barcha kurslar": "All courses",
  "Atestatsiyaga tayyorlov, metodika, demo dars va testlar   barchasi bir joyda.":
  "Exam preparation, methodology, demo lessons and tests   all in one place.",
  "O'qituvchilar uchun amaliy tayyorlov": "Practical preparation for teachers",
  "Habiba teacher   ingliz tili fani o'qituvchilarini atestatsiyaga tayyorlaydigan onlayn platforma. Testlar, metodika, demo dars va portfolio bo'yicha tizimli materiallar.":
  "Habiba teacher is an online platform preparing English teachers for attestation, with tests, methodology, demo lessons and portfolio materials.",
  "Haqiqiy formatdagi mock testlar": "Mock tests in the real format",
  "PDF darslik va qo'llanmalar": "PDF textbooks and guides",
  "Video tushuntirishlar": "Video explanations",
  "Progress va natijalar nazorati": "Progress and result tracking",
  "Bilim   amaliyotda kuch.": "Knowledge is power in practice.",
  "Har bir dars sinfdagi haqiqiy vaziyatlarga moslashtirilgan.":
  "Every lesson is adapted to real classroom situations.",
  "O'quvchilar": "Students",
  Darslar: "Lessons",
  "Tugatilgan darslar": "Completed lessons",
  "Nega biz": "Why us",
  "Natijaga olib boradigan tayyorlov": "Preparation that leads to results",
  "PDF materiallar": "PDF materials",
  "Darslik va qo'llanmalarni platformadan ochish yoki yuklab olish.":
  "Open or download textbooks and guides on the platform.",
  "Video darslar": "Video lessons",
  "Trener tushuntirishlari va amaliy namunalar.": "Trainer explanations and practical examples.",
  "Mock testlar": "Mock tests",
  "Haqiqiy formatdagi testlar, natija va tahlil.": "Real-format tests, results and analysis.",
  "Atestatsiyaga bugun tayyorlanishni boshlang": "Start preparing for attestation today",
  "Ro'yxatdan o'ting yoki Telegram orqali bog'laning.": "Register or contact us on Telegram.",
  "Ro'yxatdan o'tish": "Sign up",
  "Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov platformasi.":
  "An attestation preparation platform for English teachers.",
  "Barcha huquqlar himoyalangan.": "All rights reserved.",
  "  Barcha yo'nalishlar": "  All directions",
  "O'qituvchilar uchun toifa attestatsiyasiga tayyorgarlik   sinov testlari, natijalar va javoblar.":
  "Preparation for qualification attestation: practice tests, results and answers.",
  "O'qituvchlar uchun mock testlar": "Mock tests for teachers",
  "Attestatsiya testlari": "Attestation tests",
  "TKT testlari": "TKT tests",
  "Toifa testlari": "Category tests",
  "Ajratilgan vaqt:": "Time:",
  "Savollar soni:": "Questions:",
  "Eng yuqori ball:": "Max score:",
  Bepul: "Free",
  Ochilgan: "Unlocked",
  "Bu testlarni birma-bir sotib olish shart emas": "You don't have to buy these tests one by one",
  "Bitta tarif bilan barcha pullik testlarni oching   ancha tejamkor.":
  "One plan unlocks all paid tests   much more economical.",
  "Tarifni ko'rish   ": "View plans   ",
  Narx: "Price",
  "Test haqida": "About the test",
  Materiallar: "Materials",
  "Materiallar test ochilgach ko'rinadi.": "Materials will be available after unlocking the test.",
  "Natijalar taqsimoti": "Score distribution",
  "Har bir ishtirokchining eng yaxshi natijasi asosida": "Based on each participant's best result",
  "70% va yuqori": "70% and above",
  "Jami qatnashganlar:": "Total participants:",
  "Testga kirish uchun tizimga kiring": "Log in to open the test",
  "Testni boshlash": "Start test",
  "Qayta topshirish": "Retake",
  "Sizning natijangiz:": "Your result:",
  "Tayyor bo'lsangiz, testni boshlang.": "When ready, start the test.",
  "Test pullik. To'lovdan so'ng admin uni hisobingizga ochadi.":
  "This test is paid. After payment the admin will unlock it for your account.",
  "Telegram orqali sotib olish": "Buy via Telegram",
  "Bu testni tarif bilan oching": "Unlock this test with a plan",
  "Bitta tarif   barcha pullik testlar uchun.": "One plan   for all paid tests.",
  "Savollar uchun:": "Questions:",
  "Eng yaxshi 10 ishtirokchi": "Top 10 participants",
  "Hozircha natijalar yo'q. Birinchi bo'lib topshiring.": "No results yet. Be the first to take it.",
  "Tavsif va materiallarni tahrirlash   ": "Edit description and materials   ",
  Boshqarish: "Manage",
  "Yangi test qo'shish": "Add a new test",
  Katalog: "Catalog",
  "Atestatsiyaga tayyorlov kurslari. Kursni ochish uchun tizimga kiring.":
  "Attestation preparation courses. Log in to open a course.",
  "Bitta to'lov bilan barcha kurs va materiallarga kirish.": "One payment for access to all courses and materials.",
  "Tavsiya etiladi": "Recommended",
  "To'liq kirish": "Full access",
  "Barcha kurslar, PDF materiallar, testlar va yangilanishlar.": "All courses, PDF materials, tests and updates.",
  "/ 3 oy": "/ 3 months",
  "Barcha kurslarga kirish": "Access to all courses",
  "Mock testlar va natijalar": "Mock tests and results",
  "Yangi materiallar bepul": "New materials free",
  "Sotib olish": "Buy",
  "Telefon va parolingizni kiriting.": "Enter your phone and password.",
  Telefon: "Phone",
  Parol: "Password",
  "Akkountingiz yo'qmi?": "No account?",
  "Ismingiz": "Your name",
  "Ism, telefon va parolni kiriting.": "Enter your name, phone and password.",
  "Akkountingiz bormi?": "Already have an account?",
  "Kamida 6 belgi": "At least 6 characters",
  "Eng faol o'quvchilar": "Most active students",
  "Tugatilgan darslar va o'tacha test natijasi bo'yicha.": "By completed lessons and average test score.",
  "O'quvchi": "Student",
  "Tugatgan darslari": "Completed lessons",
  "O'rtacha natija": "Average score",
  "Hozircha natijalar yo'q.": "No results yet.",
  "1-savol": "Question 1",
  "Oldingi": "Previous",
  "Keyingi": "Next",
  "Yakunlash": "Finish",
  "Saytga o'tish": "Go to site",
  "Test yakunlandi": "Test completed",
  "Yaxshi natija!": "Good result!",
  "Yana urinib ko'ring": "Try again",
  "Testlarga qaytish": "Back to tests",
  "Shriftni kichraytirish": "Decrease font size",
  "Shriftni kattalashtirish": "Increase font size",
  "Test savollari hali qo'shilmagan": "Test questions have not been added yet",
  "Administrator tez orada savollarni qo'shadi.": "The administrator will add questions soon.",
  "Darsni tugatdim": "Lesson completed",
  "Testni yakunlash": "Finish test",
  "Kursga qaytish": "Back to course",
  "Tugatilgan": "Completed",
  "Ochish": "Open",
  Matn: "Text",
  Video: "Video",
  Test: "Test",
  "dars": "lessons",
  "Yakunlandi": "Completed",
  "Natija": "Result",
  "Sertifikatlar": "Certificates",
  "Til": "Language",
  "Kunduzgi va tungi rejim": "Day and night mode",
  "Duel xonasi": "Duel room",
  "1 vs 1": "1 vs 1",
  "Raqib kutilmoqda": "Waiting for opponent",
  "Hali o'ynamadi": "Hasn't played yet",
  "Kodni do'stingizga yuboring": "Send the code to your friend",
  "Taklif kodi": "Invite code",
  "Nusxalash": "Copy",
  "Do'stga yuborish": "Send to friend",
  "Duelni bekor qilish": "Cancel duel",
  "G'alaba!": "Victory!",
  "Mag'lubiyat": "Defeat",
  "Durang!": "Draw!",
  "G'olib:": "Winner:",
  "Yangi duel": "New duel",
  "Testlarga o'tish": "Back to tests",
  "Raqib natijasi kutilmoqda": "Waiting for the opponent's result",
  "Tayyormisiz?": "Ready?",
  "Duelni boshlash a ": "Start duel a ",
  "Faol duellar": "Active duels",
  "Duel tarixi": "Duel history",
  "Kod": "Code",
  "Holat": "Status",
  "Kutilmoqda": "Waiting",
  "Jonli": "Live",
  "Yakunlangan": "Finished",
  "Xonaga kirish   ": "Enter room   ",
  "Bepul testlardan birini tanlang.": "Choose one of the free tests.",
  "Do'stingiz bergan 6 xonali kodni kiriting.": "Enter the 6-character code from your friend.",
  "Qo'shilish": "Join",
  "Duel yaratish a ": "Create duel a ",
  "Duel   kim kuchli?": "Duel   who is stronger?",
  "Do'stingiz bilan bir testda kuch sinashing. Kod yarating, do'stingiz qo'shilsin va eng ko'p to'g'ri javob bergan yutsin.":
  "Challenge a friend in one test. Create a code, let them join, and the one with more correct answers wins.",
  "Test tanlang, kod yarating va do'stingizni chaqiring. Eng ko'p to'g'ri javob bergan   g'olib.":
  "Choose a test, create a code and invite a friend. More correct answers wins.",
  "Do'stingiz /duel sahifasida shu kodni kiritib qo'shiladi.": "Your friend enters this code on /duel to join.",
  "Ikkalangiz teng natija ko'rsatdingiz.": "You both achieved the same result.",
  "Kunlik pley-off": "Daily playoff",
  "Kunlik duel": "Daily duel",
  "Kunlik duel   finalga qadar sxema": "Daily duel   bracket to the final",
  "Sxemani ko'rish   ": "View bracket   ",
  "Turnirga qo'shilish a ": "Join the tournament a ",
  "Turnirni boshqarish": "Manage tournament",
  "Turnirni boshlash": "Start tournament",
  "Siz ro'yxatdasiz": "You are registered",
  "Do'stlaringizni taklif qiling   turnir 2 ishtirokchidan boshlanadi.":
  "Invite your friends   the tournament starts with 2 participants.",
  "Kunlik duel g'olibi": "Daily duel champion",
  "Aniqlanmadi": "Not determined",
  "Hozircha ishtirokchilar yo'q.": "No participants yet.",
  "Sxema ishtirokchilar qo'shilgach to'ladi. Boshlash uchun kamida 2 ishtirokchi kerak.":
  "The bracket fills up as participants join. At least 2 participants are needed to start.",
  "Har bir match 15 ta aralash savol. Har savolga 60 soniya. ko'proq to'g'ri javob, teng bo'lsa tezroq o'yinchi yutadi.":
  "Each match has 15 mixed questions. 60 seconds per question. More correct answers wins; if tied, the faster player wins.",
  "O'ynash": "Play",
  "Turnirni boshlash uchun kamida 2 ishtirokchi kerak.": "At least 2 participants are needed to start.",
  "Bugun": "Today",
  "Attestatsiya jarayoni": "Attestation process",
  "Amaliy tayyorlov": "Practical preparation",
  "Amaliyotchi o'qituvchi": "Practicing teacher",
  "Har bir dars   hayotdagi haqiqiy vaziyatlar uchun.": "Every lesson   for real-life situations.",
  MATN: "TEXT",
  SAVOL: "QUESTION",
  "Tugatish": "Finish",
  "Bekor qilish": "Cancel",
  "Ha": "Yes",
  "Javob berilgan": "Answered",
  "Hozirgi savol": "Current question",
  "Testni tugatishni tasdiqlaysizmi?": "Finish the test?",
  "ta savol javobsiz.": "questions unanswered.",
  "Barcha savollarga javob berilgan.": "All questions answered."
  }
};

function detectLang(req) {
  const value = parseCookies(req).ht_lang;
  return LANG_CODES.includes(value) ? value: "uz";
}

const NORM_CACHE = new WeakMap();
function normKey(value) {
  return String(value || "")
    .replace(/[\u0000-\u001f]/g, " ")
    .replace(/[\u2014\u2013]/g, " ")
    .replace(/\s+-\s+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function translateCore(text, lang) {
  const dict = I18N[lang];
  if (!dict) return text;
  const source = text.trim();
  if (!source) return text;
  const put = (value) => text.replace(source, value);
  const decoded = source
    .replace(/&#39;/g, "'")
    .replace(/&amp;/g, "&")
    .replace(/&quot;/g, '"')
    .replace(/&lt;/g, "<")
    .replace(/&gt;/g, ">");

  if (dict[source] !== undefined) return put(dict[source]);
  if (dict[decoded] !== undefined) return put(dict[decoded]);

  let cache = NORM_CACHE.get(dict);
  if (!cache) {
    cache = new Map();
    for (const [key, value] of Object.entries(dict)) cache.set(normKey(key), value);
    NORM_CACHE.set(dict, cache);
  }
  const normalized = normKey(decoded);
  if (cache.has(normalized)) return put(cache.get(normalized));

  let m;
  if ((m = source.match(/^Jami qatnashganlar:\s*(\d+)\s*ta$/))) {
    return put(lang === "ru" ? `Всего участников: ${m[1]}` : `Total participants: ${m[1]}`);
  }
  if ((m = source.match(/^Sizning natijangiz:\s*(\d+)%$/))) {
    return put(lang === "ru" ? `Ваш результат: ${m[1]}%` : `Your result: ${m[1]}%`);
  }
  if ((m = source.match(/^(\d+)\s*\/\s*(\d+)\s*savol$/))) {
    return put(`${m[1]} / ${m[2]} ${lang === "ru" ? "вопросов" : "questions"}`);
  }
  if ((m = source.match(/^(\d+)-savol$/))) {
    return put(lang === "ru" ? `Вопрос ${m[1]}` : `Question ${m[1]}`);
  }
  if ((m = source.match(/^(\d+)\s*soat(?:\s*(\d+)\s*daqiqa)?$/))) {
    const h = Number(m[1]);
    const min = m[2] ? Number(m[2]) : 0;
    if (lang === "ru") return put(`${h} ч${min ? ` ${min} мин` : ""}`);
    return put(`${h} ${h === 1 ? "hour" : "hours"}${min ? ` ${min} min` : ""}`);
  }
  if ((m = source.match(/^(\d+)\s*daqiqa$/))) {
    return put(lang === "ru" ? `${m[1]} мин` : `${m[1]} min`);
  }
  if ((m = source.match(/^([\d\s]+)\s*so'm$/))) {
    return put(lang === "ru" ? `${m[1].trim()} сум` : `${m[1].trim()} UZS`);
  }
  if ((m = source.match(/^(\d+)\s*ballik$/)) || (m = source.match(/^(\d+)\s*ball$/))) {
    return put(lang === "ru" ? `${m[1]} баллов` : `${m[1]} points`);
  }
  if ((m = source.match(/^(\d+)\s*dars$/))) {
    return put(lang === "ru" ? `${m[1]} уроков` : `${m[1]} lessons`);
  }
  if ((m = source.match(/^(\d+)\s*Ko'rishlar$/))) {
    return put(lang === "ru" ? `${m[1]} просмотров` : `${m[1]} views`);
  }
  if ((m = source.match(/^(\d+)\s*\/\s*(\d+)\s*to'g'ri javob$/))) {
    return put(
      lang === "ru"
        ? `${m[1]} / ${m[2]} правильных ответов`
        : `${m[1]} / ${m[2]} correct answers`
    );
  }
  if ((m = source.match(/^(\d+)\s*ta$/))) {
    return put(lang === "ru" ? `${m[1]} шт.` : `${m[1]} questions`);
  }
  if ((m = source.match(/^(\d+)\s*ta\s+test$/))) {
    return put(lang === "ru" ? `${m[1]} тестов` : `${m[1]} tests`);
  }
  if ((m = source.match(/^(.+)\s+guruhiga$/))) {
    return put(lang === "ru" ? `в группу ${m[1]}` : `to ${m[1]} group`);
  }
  if ((m = source.match(/^Bugun\s+(\d+)\/8\s+ishtirokchi\.$/))) {
    return put(lang === "ru" ? `Сегодня ${m[1]}/8 участников.` : `Today ${m[1]}/8 participants.`);
  }
  if ((m = source.match(/^Kunlik pley-off\s*.\s+(.+)$/))) {
    return put(lang === "ru" ? `Ежедневный плей-офф. ${m[1]}` : `Daily playoff. ${m[1]}`);
  }
  if ((m = source.match(/^Siz shu yerdasiz$/))) {
    return put(lang === "ru" ? "Вы здесь" : "You are here");
  }
  return text;
}

function translateHtml(html, lang) {
  if (lang === "uz" || !I18N[lang]) return html;
  let out = html.replace('<html lang="uz">', `<html lang="${lang}">`);
  out = out.replace(/<title>([\s\S]*?)<\/title>/, (match, inner) => {
    const parts = inner.split(/[\u0000-\u001f\u2014\u2013]+|\s{2,}/).map((part) => translateCore(part, lang).trim()).filter(Boolean);
    return `<title>${parts.join(" - ")}</title>`;
  });
  out = out.replace(
  /(<script[\s\S]*?<\/script>|<style[\s\S]*?<\/style>)|>([^<]*)</g,
  (match, skip, text) => (skip ? match: `>${translateCore(text, lang)}<`)
  );
  out = out.replace(/\b(placeholder|aria-label|title)="([^"]*)"/g, (match, attr, value) => {
  const decoded = value
.replace(/&amp;/g, "&")
.replace(/&#39;/g, "'")
.replace(/&quot;/g, '"')
.replace(/&lt;/g, "<")
.replace(/&gt;/g, ">");
  const translated = translateCore(decoded, lang).trim();
  if (translated === decoded.trim()) return match;
  const encoded = translated
.replace(/&/g, "&amp;")
.replace(/"/g, "&quot;")
.replace(/</g, "&lt;")
.replace(/>/g, "&gt;");
  return `${attr}="${encoded}"`;
  });
  return out;
}

const TYPE_LABEL = { text: "Matn", pdf: "PDF", video: "Video", test: "Test" };
const CAT_LABEL = { attestation: "Attestatsiya", tkt: "TKT", other: "Boshqa" };

function icon(name) {
  const icons = {
  book: '<path d="M4 5.5A2.5 2.5 0 0 1 6.5 3H19v15H6.5A2.5 2.5 0 0 0 4 20.5z"/><path d="M6.5 15H19"/>',
  play: '<circle cx="12" cy="12" r="8.5"/><path d="m10 8.5 5 3.5-5 3.5z"/>',
  quiz: '<circle cx="12" cy="12" r="8.5"/><path d="M9.6 9.2a2.6 2.6 0 1 1 3.8 2.4c-.8.4-1.2.9-1.2 1.9"/><circle cx="12" cy="17" r=".9" fill="currentColor" stroke="none"/>',
  heart:
  '<path d="M20.8 4.6a5.5 5.5 0 0 0-7.8 0L12 5.7l-1-1.1a5.5 5.5 0 0 0-7.8 7.8l1.1 1L12 21l7.7-7.6 1.1-1a5.5 5.5 0 0 0 0-7.8Z"/>',
  eye: '<path d="M1 12s4-7 11-7 11 7 11 7-4 7-11 7-11-7-11-7Z"/><circle cx="12" cy="12" r="3"/>',
  clock: '<circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/>',
  star: '<path d="m12 3 2.7 5.6 6.1.9-4.4 4.3 1 6.1-5.4-2.9-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z"/>',
  tag: '<path d="M20 13 11 22l-8-8 9-9h8z"/><circle cx="16" cy="8" r="1.4"/>',
  file: '<path d="M14 3H6a1.5 1.5 0 0 0-1.5 1.5v15A1.5 1.5 0 0 0 6 21h12a1.5 1.5 0 0 0 1.5-1.5V8.5z"/><path d="M14 3v5.5h5.5"/>',
  link: '<path d="M10 13a5 5 0 0 0 7 0l2-2a5 5 0 0 0-7-7l-1 1"/><path d="M14 11a5 5 0 0 0-7 0l-2 2a5 5 0 0 0 7 7l1-1"/>',
  list: '<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1"/><circle cx="3.5" cy="12" r="1"/><circle cx="3.5" cy="18" r="1"/>',
  swords: '<path d="m14.5 4.5 5 5M4 20l5-5M4 4l7 7M20 20l-7-7"/><path d="m16 16 4 4M4 20l2-2M18 4l2 2"/>',
  layers: '<path d="m12 3 8 4.5-8 4.5-8-4.5z"/><path d="m4 12 8 4.5 8-4.5"/><path d="m4 16.5 8 4.5 8-4.5"/>'
  };
  return `<svg viewBox="0 0 24 24" aria-hidden="true">${icons[name] || ""}</svg>`;
}

function send(res, status, body, headers = {}) {
  if (res.lang && res.lang !== "uz" && typeof body === "string" && body.includes("<!DOCTYPE html>")) {
  body = translateHtml(body, res.lang);
  }
  res.writeHead(status, {
  "Content-Type": "text/html; charset=utf-8",
  "Cache-Control": "no-store",
...headers
  });
  res.end(body);
}

function redirect(res, location, extraHeaders = {}) {
  res.writeHead(303, { Location: location,...extraHeaders });
  res.end();
}

function json(res, status, data) {
  res.writeHead(status, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify(data));
}

function parseCookies(req) {
  const out = {};
  const raw = req.headers.cookie || "";
  raw.split(";").forEach((part) => {
  const i = part.indexOf("=");
  if (i > -1) out[part.slice(0, i).trim()] = decodeURIComponent(part.slice(i + 1).trim());
  });
  return out;
}

function clientIp(req) {
  const forwarded = String(req.headers["cf-connecting-ip"] || req.headers["x-forwarded-for"] || "").split(",")[0].trim();
  return forwarded || req.socket.remoteAddress || "unknown";
}

function cookie(name, value, maxAge, req) {
  const secure = (req.headers["x-forwarded-proto"] || "").split(",")[0].trim() === "https";
  const age = maxAge ? `; Max-Age=${maxAge}` : "";
  return `${name}=${encodeURIComponent(value)}; Path=/; HttpOnly; SameSite=Lax${age}${
  secure ? "; Secure": ""
  }`;
}

function accessCode() {
  return metaGet("access_code", "2026") || "2026";
}

function accessToken(code) {
  return createHmac("sha256", config.telegramBotToken || "ht-access")
.update(String(code || ""))
.digest("hex");
}

function hasPlatformAccess(req) {
  const token = parseCookies(req).ht_access;
  return !!token && token === accessToken(accessCode());
}

function hashPassword(password) {
  const salt = randomBytes(16).toString("hex");
  const hash = scryptSync(password, salt, 64).toString("hex");
  return `${salt}:${hash}`;
}

function verifyPassword(password, stored) {
  try {
  const [salt, hash] = String(stored).split(":");
  if (!salt || !hash) return false;
  const expected = Buffer.from(hash, "hex");
  const actual = scryptSync(password, salt, 64);
  return expected.length === actual.length && timingSafeEqual(expected, actual);
  } catch (e) {
  return false;
  }
}

function safeEqual(a, b) {
  const ba = Buffer.from(String(a));
  const bb = Buffer.from(String(b));
  return ba.length === bb.length && timingSafeEqual(ba, bb);
}

const MEDIA_SECRET = randomBytes(32);
const LOGIN_SECRET = randomBytes(32);
function loginCodeHash(phone, code) {
  return createHmac("sha256", LOGIN_SECRET).update(`${phone}:${code}`).digest("hex");
}
function mediaToken(lessonId, userId) {
  const exp = Math.floor(Date.now() / 1000) + 14400;
  const sig = createHmac("sha256", MEDIA_SECRET)
    .update(`${lessonId}:${userId}:${exp}`)
    .digest("hex")
    .slice(0, 32);
  return `${exp}.${sig}`;
}

function mediaTokenValid(lessonId, userId, token) {
  const [expRaw, sig] = String(token || "").split(".");
  const exp = Number(expRaw);
  if (!exp || exp < Math.floor(Date.now() / 1000)) return false;
  const expected = createHmac("sha256", MEDIA_SECRET)
    .update(`${lessonId}:${userId}:${exp}`)
    .digest("hex")
    .slice(0, 32);
  return safeEqual(sig || "", expected);
}

function telegramUserFromInitData(initData) {
  try {
  const params = new URLSearchParams(String(initData || ""));
  const hash = params.get("hash");
  if (!hash || !config.telegramBotToken) return null;
  params.delete("hash");
  const dataCheckString = [...params.entries()]
.sort(([a], [b]) => a.localeCompare(b))
.map(([key, value]) => `${key}=${value}`)
.join("\n");
  const secret = createHmac("sha256", "WebAppData").update(config.telegramBotToken).digest();
  const calculated = createHmac("sha256", secret).update(dataCheckString).digest("hex");
  if (calculated.length !== hash.length || !timingSafeEqual(Buffer.from(calculated), Buffer.from(hash))) {
  return null;
  }
  const user = JSON.parse(params.get("user") || "null");
  return user && user.id ? user: null;
  } catch (e) {
  return null;
  }
}

function normalizePhone(value) {
  let digits = String(value || "").replace(/\D/g, "");
  if (digits.startsWith("998")) digits = digits.slice(3);
  else if (digits.length === 10 && digits.startsWith("8")) digits = digits.slice(1);
  if (digits.length !== 9) return digits;
  return "998" + digits;
}

function validPhone(digits) {
  return /^998\d{9}$/.test(digits);
}

/* --------------------------------------------------------------- sessions */
function currentUser(req) {
  const token = parseCookies(req).ht_session;
  if (!token) return null;
  const row = db
.prepare(
  `SELECT u.id, u.name, u.phone, u.created_at, u.contract_accepted_at
  FROM sessions s JOIN users u ON u.id = s.user_id
  WHERE s.token = ? AND s.expires_at > ?`
  )
.get(token, Date.now());
  return row || null;
}

function isAdmin(req) {
  const token = parseCookies(req).ht_admin;
  if (!token) return false;
  const row = db
.prepare("SELECT 1 AS ok FROM admin_sessions WHERE token = ? AND expires_at > ?")
.get(token, Date.now());
  return !!row;
}

function createUserSession(res, userId, req) {
  const token = randomBytes(32).toString("hex");
  const maxAge = 30 * 24 * 60 * 60;
  db.prepare("INSERT INTO sessions (token, user_id, expires_at) VALUES (?, ?, ?)").run(
  token,
  userId,
  Date.now() + maxAge * 1000
  );
  res.setHeader("Set-Cookie", cookie("ht_session", token, maxAge, req));
}

function createDeviceSession(res, userId, req) {
  const token = randomBytes(32).toString("hex");
  db.prepare("INSERT INTO device_sessions (token, user_id, created_at, last_seen) VALUES (?, ?, ?, ?)").run(
    token,
    userId,
    nowISO(),
    nowISO()
  );
  const value = cookie("ht_device", token, 365 * 24 * 60 * 60, req);
  const prev = res.getHeader("Set-Cookie");
  res.setHeader("Set-Cookie", prev ? [].concat(prev, value) : value);
}

function createAdminSession(res, req) {
  const token = randomBytes(32).toString("hex");
  const maxAge = 2 * 60 * 60;
  db.prepare("INSERT INTO admin_sessions (token, expires_at) VALUES (?, ?)").run(
  token,
  Date.now() + maxAge * 1000
  );
  res.setHeader("Set-Cookie", cookie("ht_admin", token, null, req));
}

function clearCookie(res, name) {
  const value = `${name}=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0`;
  const prev = res.getHeader("Set-Cookie");
  res.setHeader("Set-Cookie", prev ? [].concat(prev, value) : value);
}

function sameOrigin(req) {
  const origin = req.headers.origin;
  if (!origin) return true;
  try {
  return new URL(origin).host === req.headers.host;
  } catch (e) {
  return false;
  }
}

/* ---------------------------------------------------------- login limiting */
const attempts = new Map();

function lockedFor(ip) {
  const rec = attempts.get(ip);
  if (!rec) return 0;
  if (rec.until > Date.now()) return Math.ceil((rec.until - Date.now()) / 1000);
  attempts.delete(ip);
  return 0;
}

function noteFailure(ip) {
  const rec = attempts.get(ip) || { count: 0, until: 0 };
  rec.count += 1;
  if (rec.count >= 5) {
  rec.until = Date.now() + 5 * 60 * 1000;
  rec.count = 0;
  }
  attempts.set(ip, rec);
}

function clearFailures(ip) {
  attempts.delete(ip);
}

/* ------------------------------------------------------------------ views */
function navFor(user, admin, publicPage = false) {
  if (admin && !publicPage) {
  return `<nav class="nav">
  <a href="/admin" class="active">Admin</a>
  <a href="/admin/students">O'quvchilar</a>
  <a href="/leaderboard">Reyting</a>
  <a href="/">Saytni ko'rish</a>
  <form method="post" action="/admin/logout"><button class="link" type="submit">Chiqish</button></form>
  </nav>`;
  }

  const links = `
  <a href="/">Bosh sahifa</a>
  <a href="/attestation">Attestatsiya</a>
  <a href="/tkt">TKT</a>
  <a href="/duel">Duel</a>
  <a href="/courses">Kurslar</a>
  <a href="/plans">Tariflar</a>
  <a href="/leaderboard">Reyting</a>`;

  if (user) {
  return `<nav class="nav">${links}
  <span class="who">${h(user.name)}</span>
  <a href="/dashboard">Kabinet</a>
  <form method="post" action="/logout"><button class="link" type="submit">Chiqish</button></form>
  </nav>`;
  }

  return `<nav class="nav">${links}
  <a class="btn btn-sm" href="/login">Kirish</a>
  </nav>`;
}

function layout(opts) {
  const { title, body, admin = false } = opts;
  const user = opts.user || null;
  const publicPage = Object.prototype.hasOwnProperty.call(opts, "user");
  return `<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#061726">
<title>${h(title)}   ${h(config.siteName)}</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='9' fill='%2312b5a6'/%3E%3Ctext x='16' y='22' font-family='Arial' font-size='18' font-weight='bold' text-anchor='middle' fill='%2303211d'%3EH%3C/text%3E%3C/svg%3E">
<script async src="https://telegram.org/js/telegram-web-app.js"></script>
<script>try{if(localStorage.getItem('ht_theme')==='light')document.documentElement.dataset.theme='light';}catch(e){}</script>
<link rel="stylesheet" href="/assets/platform.css?v=20261114h">
</head>
<body>
<header class="topbar">
  <div class="wrap bar">
  <a class="brand" href="${admin ? "/admin": user ? "/courses": "/"}">
  <span class="mark">H</span>
  <span>${h(config.siteName)}</span>
  <span class="tag">${admin ? "Admin": "Platforma"}</span>
  </a>
  <div class="bar-right">
  ${navFor(user, admin, publicPage)}
  <div class="prefs">
  <div class="lang-switch" aria-label="Til">
  <a href="/lang/uz" class="lang-uz">UZ</a>
  <a href="/lang/ru" class="lang-ru">RU</a>
  <a href="/lang/en" class="lang-en">EN</a>
  </div>
  <button class="theme-toggle" type="button" data-theme-toggle aria-label="Kunduzgi va tungi rejim">
  <span class="theme-sun"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></span>
  <span class="theme-moon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.8A8.5 8.5 0 1 1 11.2 3a6.6 6.6 0 0 0 9.8 9.8Z"/></svg></span>
  </button>
  </div>
  <button class="menu-toggle" type="button" id="menuToggle" aria-label="Menyu" aria-expanded="false">
  <span></span><span></span><span></span>
  </button>
  </div>
  </div>
  <div class="mobile-menu" id="mobileMenu" hidden>
  <nav class="mobile-links">
  ${
  admin && !publicPage
  ? `<a href="/admin">Admin</a><a href="/admin/students">O'quvchilar</a><a href="/leaderboard">Reyting</a><a href="/">Saytni ko'rish</a>
  <form method="post" action="/admin/logout"><button class="mobile-link-btn" type="submit">Chiqish</button></form>`
: `<a href="/">Bosh sahifa</a>
  <a href="/attestation">Attestatsiya</a>
  <a href="/tkt">TKT</a>
  <a href="/duel">Duel</a>
  <a href="/courses">Kurslar</a>
  <a href="/plans">Tariflar</a>
  <a href="/leaderboard">Reyting</a>
  ${
  user
  ? `<div class="mobile-user">${h(user.name)}</div>
  <a href="/dashboard">Kabinet</a>
  <form method="post" action="/logout"><button class="mobile-link-btn" type="submit">Chiqish</button></form>`
: `<a class="mobile-login" href="/login">Kirish</a>`
  }`
  }
  </nav>
  <div class="mobile-prefs">
  <div class="lang-switch" aria-label="Til">
  <a href="/lang/uz" class="lang-uz">UZ</a>
  <a href="/lang/ru" class="lang-ru">RU</a>
  <a href="/lang/en" class="lang-en">EN</a>
  </div>
  <button class="theme-toggle" type="button" data-theme-toggle aria-label="Kunduzgi va tungi rejim">
  <span class="theme-sun"><svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"/></svg></span>
  <span class="theme-moon"><svg viewBox="0 0 24 24" aria-hidden="true"><path d="M21 12.8A8.5 8.5 0 1 1 11.2 3a6.6 6.6 0 0 0 9.8 9.8Z"/></svg></span>
  </button>
  </div>
  </div>
</header>
<main class="wrap page">
${body.includes("home-hero") ? "" : `<a class="page-back" href="/" onclick="if(history.length>1){history.back();return false;}">&larr; Orqaga</a>`}
${body}
</main>
<footer class="site-footer">
  <div class="wrap footer-grid">
  <div class="footer-brand">
  <a class="brand" href="/">
  <span class="mark">H</span>
  <span>${h(config.siteName)}</span>
  </a>
  <p>Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov platformasi.</p>
  </div>
  <nav class="footer-links">
  <a href="/">Bosh sahifa</a>
  <a href="/attestation">Attestatsiya</a>
  <a href="/tkt">TKT</a>
  <a href="/duel">Duel</a>
  <a href="/courses">Kurslar</a>
  <a href="/plans">Tariflar</a>
  <a href="/leaderboard">Reyting</a>
  <a href="/#about">Biz haqimizda</a>
  </nav>
  <div class="footer-contact">
  <a href="${h(config.telegram || "#")}" target="_blank" rel="noopener">Telegram</a>
  <a href="tel:${h(String(config.phone || "").replace(/[^\d+]/g, ""))}">${h(config.phone || "")}</a>
  </div>
  </div>
  <div class="wrap footer-bottom">
  ${new Date().getFullYear()} ${h(config.siteName)}. Barcha huquqlar himoyalangan.
  </div>
</footer>
${
user && !user.contract_accepted_at
? `<div class="contract-overlay" id="contractOverlay">
<div class="contract-modal">
<div class="contract-head">
<span class="contract-ico">H</span>
<div><b>Ta'lim shartnomasi</b><small>Davom etish uchun shartnomani o'qing va qabul qiling</small></div>
</div>
<div class="contract-body">${nl2br(contractText())}</div>
<form method="post" action="/contract/accept" class="contract-foot">
<label class="contract-check"><input type="checkbox" id="contractAgree"> <span>Shartnoma shartlariga to'liq roziman</span></label>
<button class="btn btn-primary" type="submit" id="contractBtn" disabled>Qabul qilaman</button>
</form>
</div>
</div>
<script>
(function () {
var c = document.getElementById('contractAgree');
var b = document.getElementById('contractBtn');
if (!c || !b) return;
c.addEventListener('change', function () { b.disabled = !c.checked; });
})();
</script>`
: ""
}
<script>
(function () {
  document.querySelectorAll('input[data-phone]').forEach(function (input) {
  function format() {
  var d = input.value.replace(/\\D/g, '');
  if (d.indexOf('998') === 0) d = d.slice(3);
  if (d.length > 9 && d.charAt(0) === '8') d = d.slice(1);
  d = d.slice(0, 9);
  var out = '+998';
  if (d.length) out += ' ' + d.slice(0, 2);
  if (d.length > 2) out += ' ' + d.slice(2, 5);
  if (d.length > 5) out += ' ' + d.slice(5, 7);
  if (d.length > 7) out += ' ' + d.slice(7, 9);
  input.value = out;
  }
  input.addEventListener('focus', function () {
  if (!input.value.trim()) input.value = '+998 ';
  });
  input.addEventListener('input', format);
  input.addEventListener('blur', function () {
  if (input.value.replace(/\\D/g, '') === '998') input.value = '';
  });
  });

  document.querySelectorAll('[data-theme-toggle]').forEach(function (themeBtn) {
  themeBtn.addEventListener('click', function () {
  var root = document.documentElement;
  var light = root.getAttribute('data-theme') === 'light';
  if (light) {
  root.removeAttribute('data-theme');
  try { localStorage.setItem('ht_theme', 'dark'); } catch (e) {}
  } else {
  root.setAttribute('data-theme', 'light');
  try { localStorage.setItem('ht_theme', 'light'); } catch (e) {}
  }
  });
  });

  var menuToggle = document.getElementById('menuToggle');
  var mobileMenu = document.getElementById('mobileMenu');
  if (menuToggle && mobileMenu) {
  function setMenu(open) {
  mobileMenu.hidden = !open;
  menuToggle.classList.toggle('open', open);
  menuToggle.setAttribute('aria-expanded', open ? 'true': 'false');
  document.body.style.overflow = open ? 'hidden': '';
  }
  menuToggle.addEventListener('click', function () { setMenu(mobileMenu.hidden); });
  mobileMenu.querySelectorAll('a,.mobile-links button').forEach(function (el) {
  el.addEventListener('click', function () {
  if (!el.closest('form')) setMenu(false);
  });
  });
  document.addEventListener('keydown', function (e) {
  if (e.key === 'Escape' && !mobileMenu.hidden) setMenu(false);
  });
  }

  function fillTelegramFields() {
  if (!window.Telegram || !window.Telegram.WebApp) return false;
  try {
  var tg = window.Telegram.WebApp;
  tg.ready();
  var tgUser = tg.initDataUnsafe && tg.initDataUnsafe.user;
  if (tgUser && tgUser.id) {
  var tgIdInput = document.querySelector('input[name="telegram_id"]');
  if (tgIdInput && !tgIdInput.value) tgIdInput.value = tgUser.id;
  var tgDataInput = document.querySelector('input[name="tg_init_data"]');
  if (tgDataInput) tgDataInput.value = tg.initData || '';
  }
  return true;
  } catch (e) {
  return false;
  }
  }
  if (!fillTelegramFields()) {
  var tgTries = 0;
  var tgTimer = setInterval(function () {
  if (fillTelegramFields() || ++tgTries > 20) clearInterval(tgTimer);
  }, 300);
  }

  document.querySelectorAll('[data-copy]').forEach(function (btn) {
  btn.addEventListener('click', function () {
  var value = btn.getAttribute('data-copy');
  if (navigator.clipboard) navigator.clipboard.writeText(value).then(function () {
  var old = btn.textContent;
  btn.textContent = 'Nusxalandi S ';
  setTimeout(function () { btn.textContent = old; }, 1600);
  });
  });
  });

  document.querySelectorAll('[data-share]').forEach(function (btn) {
  btn.addEventListener('click', function () {
  var text = btn.getAttribute('data-share');
  if (navigator.share) {
  navigator.share({ title: 'Duel', text: text }).catch(function () {});
  } else {
  var ta = document.createElement('textarea');
  ta.value = text;
  document.body.appendChild(ta);
  ta.select();
  try { document.execCommand('copy'); } catch (e) {}
  document.body.removeChild(ta);
  var old = btn.textContent;
  btn.textContent = 'Nusxalandi S ';
  setTimeout(function () { btn.textContent = old; }, 1600);
  }
  });
  });
})();
</script>
<script>
(function () {
  function paint(el, data) {
    var count = el.querySelector('b');
    if (count) count.textContent = data.likes;
    el.classList.toggle('liked', !!data.liked);
  }
  document.querySelectorAll('[data-like]').forEach(function (el) {
    fetch('/like/' + el.dataset.like + '/status', { headers: { Accept: 'application/json' } })
      .then(function (r) { return r.json(); })
      .then(function (d) { if (d && d.ok) paint(el, d); })
      .catch(function () {});
  });
  document.addEventListener('click', function (e) {
    var el = e.target.closest ? e.target.closest('[data-like]') : null;
    if (!el) return;
    e.preventDefault();
    e.stopPropagation();
    fetch('/like/' + el.dataset.like, { method: 'POST', headers: { Accept: 'application/json' } })
      .then(function (r) {
        if (r.status === 401) {
          location.href = '/login?next=' + encodeURIComponent(location.pathname);
          return null;
        }
        return r.json();
      })
      .then(function (d) { if (d && d.ok) paint(el, d); })
      .catch(function () {});
  });
})();
</script>
</body>
</html>`;
}

function authCard(title, subtitle, formHtml, altHtml = "", backHref = "") {
  return `<div class="auth-card">
  ${backHref ? `<a class="back auth-back" href="${h(backHref)}">  Orqaga</a>`: ""}
  <h1>${h(title)}</h1>
  <p class="muted">${subtitle}</p>
  ${formHtml}
  ${altHtml}
  </div>`;
}

function alertBox(message, type = "error") {
  if (!message) return "";
  return `<div class="alert ${type}">${h(message)}</div>`;
}

function typeBadge(type) {
  return `<span class="badge type-${h(type)}">${TYPE_LABEL[type] || h(type)}</span>`;
}

function videoEmbed(url) {
  const m = String(url).match(
  /(?:youtu\.be\/|youtube\.com\/(?:watch\?v=|embed\/|shorts\/|live\/))([A-Za-z0-9_-]{6,})/
  );
  if (m) {
  return `<div class="video"><iframe src="https://www.youtube.com/embed/${h(
  m[1]
  )}" title="Video" allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture" allowfullscreen></iframe></div>`;
  }
  return `<video class="video" controls src="${h(url)}"></video>`;
}

/* ------------------------------------------------------------- form parser */
async function readRaw(req, limit) {
  return new Promise((resolve, reject) => {
  let size = 0;
  const chunks = [];
  req.on("data", (chunk) => {
  size += chunk.length;
  if (size > limit) {
  reject(new Error("too_large"));
  req.destroy();
  return;
  }
  chunks.push(chunk);
  });
  req.on("end", () => resolve(Buffer.concat(chunks)));
  req.on("error", reject);
  });
}

async function readForm(req) {
  const ct = String(req.headers["content-type"] || "").toLowerCase();

  if (ct.includes("application/x-www-form-urlencoded")) {
  const raw = (await readRaw(req, 1024 * 1024)).toString("utf8");
  return { fields: Object.fromEntries(new URLSearchParams(raw)), files: {} };
  }

  if (ct.includes("multipart/form-data")) {
  const declared = Number(req.headers["content-length"] || 0);
  if (declared && declared > MAX_UPLOAD) throw new Error("too_large");

  const request = new Request("http://localhost/upload", {
  method: "POST",
  headers: { "content-type": req.headers["content-type"] },
  body: Readable.toWeb(req),
  duplex: "half"
  });

  const fd = await request.formData();
  const fields = {};
  const files = {};
  for (const [key, value] of fd.entries()) {
  if (typeof value === "string") {
  fields[key] = value;
  } else {
  files[key] = {
  name: value.name || "file",
  type: value.type || "",
  size: value.size || 0,
  buffer: Buffer.from(await value.arrayBuffer())
  };
  }
  }
  return { fields, files };
  }

  return { fields: {}, files: {} };
}

/* --------------------------------------------------------------- queries */
function courseProgress(userId, courseId) {
  const row = db
.prepare(
  `SELECT
  (SELECT COUNT(*) FROM lessons WHERE course_id = ?) AS total,
  (SELECT COUNT(*) FROM progress p JOIN lessons l ON l.id = p.lesson_id
  WHERE l.course_id = ? AND p.user_id = ?) AS done`
  )
.get(courseId, courseId, userId);
  return { total: row.total || 0, done: row.done || 0 };
}

function progressBar(done, total) {
  const percent = total ? Math.round((done / total) * 100): 0;
  return `<div class="progress"><span style="width:${percent}%"></span></div>
  <div class="progress-meta"><span>${percent}% tugatilgan</span><span>${done}/${total} dars</span></div>`;
}

function publicCourseCard(course, user) {
  const href = user ? `/course/${course.id}`: "/login";
  return `<a class="card course-card" href="${href}">
  <div class="course-top">
  <div class="course-ico">${icon("layers")}</div>
  <span class="badge">${course.lesson_count || 0} dars</span>
  </div>
  <h3>${h(course.title)}</h3>
  <p class="muted">${h(course.description || "Kurs tavsifi yo'q")}</p>
  <span class="card-link">Ochish   </span>
  </a>`;
}

/* ------------------------------------------------------------ test cards */
function formatDuration(min) {
  const total = Math.max(0, Number(min) || 0);
  const hours = Math.floor(total / 60);
  const minutes = total % 60;
  if (hours && minutes) return `${hours} soat ${minutes} daqiqa`;
  if (hours) return `${hours} soat`;
  return `${minutes} daqiqa`;
}

const formatSum = (value) => String(Number(value) || 0).replace(/\B(?=(\d{3})+(?!\d))/g, " ");

/* --------------------------------------------------------------------- AI */
function testOwned(userId, lessonId) {
  return !!db.prepare("SELECT 1 FROM purchases WHERE user_id = ? AND lesson_id = ?").get(userId, lessonId);
}

function moduleHref(lesson) {
  const course = db.prepare("SELECT category FROM courses WHERE id = ?").get(lesson.course_id);
  return course && course.category === "tkt" ? "/tkt": "/attestation";
}

function testCard(test, owned = false) {
  const isPro = Number(test.price) > 0;
  const count = Number(test.question_count) || Number(test.qcount) || 0;
  const score = Number(test.max_score) || 0;
  const priceLabel = owned ? "Ochilgan": isPro ? `${formatSum(test.price)} so'm`: "Bepul";
  return `<a class="test-card ${isPro ? "pro": "free"}" href="/test/${test.id}">
  <span class="test-flag">${isPro ? "PRO": "FREE"}</span>
  <h3>${h(test.title)}</h3>
  <div class="test-params">
  <div><span>Ajratilgan vaqt:</span><b>${formatDuration(test.duration_min)}</b></div>
  <div><span>Savollar soni:</span><b>${count} ta</b></div>
  <div><span>Eng yuqori ball:</span><b>${score} ballik</b></div>
  </div>
  <div class="test-engagement">
  <span class="like-btn" data-like="${test.id}" role="button" tabindex="0" title="Yoqdi">${icon("heart")} <b>${Number(test.likes) || 0}</b></span>
  <span>${icon("eye")} ${Number(test.views) || 0}</span>
  </div>
  <span class="test-price">${priceLabel}</span>
  </a>`;
}

function formatSize(bytes) {
  const size = Number(bytes) || 0;
  if (size >= 1024 * 1024) return `${(size / 1024 / 1024).toFixed(1)} MB`;
  if (size >= 1024) return `${Math.round(size / 1024)} KB`;
  return `${size} B`;
}

async function notifyTelegram(text, keyboard = null) {
  if (config.notifyOnFinish === false) return false;
  const token = config.telegramBotToken || process.env.TELEGRAM_BOT_TOKEN;
  const chatId = config.telegramChatId || process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return false;
  try {
  const payload = {
  chat_id: chatId,
  text,
  parse_mode: "HTML",
  disable_web_page_preview: true
  };
  if (keyboard) payload.reply_markup = keyboard;
  const res = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload),
  signal: AbortSignal.timeout(8000)
  });
  if (!res.ok) {
  console.error("[telegram] send failed", res.status, (await res.text()).slice(0, 200));
  return false;
  }
  console.log("[telegram] xabar yuborildi");
  return true;
  } catch (e) {
  console.error("[telegram]", e.message);
  return false;
  }
}

function platformPublicUrl() {
  try {
  const file = path.join(DATA_DIR, "public-url.txt");
  if (fs.existsSync(file)) {
  const value = fs.readFileSync(file, "utf8").trim();
  if (/^https?:\/\//i.test(value)) return value.replace(/\/+$/, "");
  }
  } catch (e) {}
  return String(config.appUrl || "").replace(/\/+$/, "");
}

/* ---------------------------------------------------- public tunnel manager */
const CLOUDFLARED_BIN = process.env.CLOUDFLARED_BIN || "C:\\Users\\i7TechStore\\cloudflared.exe";
let tunnelChild = null;
let tunnelTask = null;
let tunnelUrl = "";

function savePublicUrl(url) {
  const clean = String(url || "").replace(/\/+$/, "");
  if (!/^https?:\/\//i.test(clean)) return "";
  tunnelUrl = clean;
  try {
  fs.writeFileSync(path.join(DATA_DIR, "public-url.txt"), clean, "utf8");
  } catch (e) {}
  try {
  const file = path.join(__dirname, "config.json");
  const data = JSON.parse(fs.readFileSync(file, "utf8").replace(/^\uFEFF/, ""));
  data.appUrl = clean;
  fs.writeFileSync(file, JSON.stringify(data, null, 2), "utf8");
  config.appUrl = clean;
  } catch (e) {}
  return clean;
}

async function publicUrlAlive(url) {
  if (!url) return false;
  try {
  const res = await fetch(url.replace(/\/+$/, "") + "/", { signal: AbortSignal.timeout(8000) });
  return res.status < 500;
  } catch (e) {
  return false;
  }
}

function startTunnelProcess() {
  return new Promise((resolve) => {
  let done = false;
  const finish = (url) => {
  if (done) return;
  done = true;
  resolve(url || "");
  };
  let child;
  try {
  child = spawn(
  CLOUDFLARED_BIN,
  ["tunnel", "--url", `http://127.0.0.1:${PORT}`, "--no-autoupdate", "--protocol", "http2"],
  { windowsHide: true }
  );
  } catch (e) {
  finish("");
  return;
  }
  tunnelChild = child;
  let buffer = "";
  const onData = (chunk) => {
  buffer = (buffer + String(chunk)).slice(-30000);
  const match = buffer.match(/https:\/\/[a-z0-9-]+\.trycloudflare\.com/i);
  if (match) {
  savePublicUrl(match[0]);
  finish(match[0]);
  }
  };
  child.stdout.on("data", onData);
  child.stderr.on("data", onData);
  child.on("error", () => finish(""));
  child.on("exit", () => {
  tunnelChild = null;
  finish("");
  });
  setTimeout(() => finish(tunnelUrl || ""), 30000);
  });
}

async function ensurePublicTunnel() {
  const current = platformPublicUrl();
  if (current && (await publicUrlAlive(current))) return current;
  if (tunnelTask) return tunnelTask;
  tunnelTask = (async () => {
  try {
  if (tunnelChild) {
  try {
  tunnelChild.kill();
  } catch (e) {}
  tunnelChild = null;
  }
  const url = await startTunnelProcess();
  if (url && url !== current) {
  telegramApi("sendMessage", {
  chat_id: config.telegramChatId,
  text: `" Platforma manzili yangilandi:\n${url}`,
  disable_web_page_preview: true,
  reply_markup: botKeyboard()
  }).catch(() => {});
  }
  return url || platformPublicUrl();
  } finally {
  tunnelTask = null;
  }
  })();
  return tunnelTask;
}

function startTunnelWatchdog() {
  ensurePublicTunnel().catch(() => {});
  setInterval(() => {
  ensurePublicTunnel().catch(() => {});
  }, 120000);
}

async function telegramApi(method, payload) {
  const token = config.telegramBotToken || "";
  if (!token) return null;
  try {
  const res = await fetch(`https://api.telegram.org/bot${token}/${method}`, {
  method: "POST",
  headers: { "Content-Type": "application/json" },
  body: JSON.stringify(payload || {}),
  signal: AbortSignal.timeout(35000)
  });
  return await res.json().catch(() => null);
  } catch (e) {
  console.error("[bot]", e.message);
  return null;
  }
}

function telegramDuelKeyboard(path, label = "Duelni ochish") {
  const base = platformPublicUrl();
  if (!base) return null;
  const url = base + path;
  return {
  inline_keyboard: [
  [{ text: `a  ${label}`, web_app: { url } }],
  [{ text: "xR Brauzerda ochish", url }]
  ]
  };
}

async function sendUserMessage(userId, text, path, label = "Duelni ochish") {
  const user = db.prepare("SELECT telegram_id FROM users WHERE id = ?").get(userId);
  if (!user || !user.telegram_id) return false;
  const keyboard = telegramDuelKeyboard(path, label);
  const payload = {
  chat_id: user.telegram_id,
  text,
  parse_mode: "HTML",
  disable_web_page_preview: true
  };
  if (keyboard) payload.reply_markup = keyboard;
  let data = await telegramApi("sendMessage", payload);
  if (keyboard && data && !data.ok) {
  const base = platformPublicUrl();
  if (base) {
  payload.reply_markup = { inline_keyboard: [[{ text: `a  ${label}`, url: base + path }]] };
  data = await telegramApi("sendMessage", payload);
  }
  }
  return !!(data && data.ok);
}

async function notifyTournamentMatchPlayers(tournamentId, round) {
  const tournament = db.prepare("SELECT * FROM tournaments WHERE id = ?").get(tournamentId);
  if (!tournament) return;
  const matches = db
.prepare(
  `SELECT m.*, u1.name AS p1name, u2.name AS p2name
  FROM tournament_matches m
  LEFT JOIN users u1 ON u1.id = m.p1
  LEFT JOIN users u2 ON u2.id = m.p2
  WHERE m.tournament_id = ? AND m.round = ? AND m.status = 'ready'`
  )
.all(tournamentId, round);
  for (const match of matches) {
  const label = tournamentRoundName(tournament.size, round);
  for (const playerId of [match.p1, match.p2]) {
  if (!playerId) continue;
  const flag = `tour_ready_${match.id}_${playerId}`;
  if (metaGet(flag, "") === "1") continue;
  metaSet(flag, "1");
  const opponent = playerId === match.p1 ? match.p2name: match.p1name;
  await sendUserMessage(
  playerId,
  `—  <b>${label} boshlandi</b>\nRaqibingiz: <b>${h(opponent || "?")}</b>\n15 ta aralash savol. Har savolga 60 soniya. Ilovani oching.`,
  `/duel/tournament/match/${match.id}`,
  "Duelni ochish"
  );
  }
  }
}

function botKeyboard() {
  const url = platformPublicUrl();
  if (!url) return null;
  const rows = [];
  rows.push([{ text: "xa Platformaga kirish", web_app: { url } }]);
  rows.push([{ text: "xR Brauzerda ochish", url }]);
  return { inline_keyboard: rows };
}

async function sendBotWelcome(chatId, name) {
  const url = platformPublicUrl();
  if (!url) {
  await telegramApi("sendMessage", {
  chat_id: chatId,
  text: "Platforma manzili hali sozlanmagan. Administrator bilan bog'laning."
  });
  return;
  }
  await telegramApi("sendMessage", {
  chat_id: chatId,
  text: `Assalomu alaykum${name ? `, ${name}`: ""}! x 9\n\nHabiba teacher   ingliz tili o'qituvchilarini attestatsiyaga tayyorlov platformasi.\n\nPastdagi tugma orqali platformaga kiring.`,
  parse_mode: "HTML",
  disable_web_page_preview: true,
  reply_markup: botKeyboard()
  });
}

async function handleBotUpdate(update) {
  const message = update.message || update.edited_message;
  if (!message) return;
  const chatId = message.chat?.id;
  const text = String(message.text || "").trim();
  const name = message.from?.first_name || "";
  if (!chatId) return;
  const cmd = text.split(/\s+/)[0].toLowerCase().replace(/@.*$/, "");

  if (cmd === "/start" || cmd === "/platform" || cmd === "/kirish") {
  if (!(await publicUrlAlive(platformPublicUrl()))) {
  try {
  fs.writeFileSync(path.join(DATA_DIR, "restart-tunnel.flag"), "1", "utf8");
  } catch (e) {}
  for (let i = 0; i < 10; i += 1) {
  await new Promise((resolve) => setTimeout(resolve, 2000));
  if (await publicUrlAlive(platformPublicUrl())) break;
  }
  }
  await sendBotWelcome(chatId, name);
  return;
  }
  if (cmd === "/myid") {
  await telegramApi("sendMessage", {
  chat_id: chatId,
  text: `Sizning Telegram ID: ${chatId}`
  });
  return;
  }
  if (cmd === "/help") {
  await telegramApi("sendMessage", {
  chat_id: chatId,
  text: "Buyruqlar:\n/start   platformaga kirish\n/myid   Telegram ID\n/help   yordam"
  });
  return;
  }
  await sendBotWelcome(chatId, name);
}

function startPlatformBot() {
  if (!config.telegramBotToken) return;
  let offset = Number(metaGet("bot_offset", "0")) || 0;
  const loop = async () => {
  while (true) {
  try {
  const res = await fetch(
  `https://api.telegram.org/bot${config.telegramBotToken}/getUpdates?timeout=25&offset=${offset}`,
  { signal: AbortSignal.timeout(35000) }
  );
  const data = await res.json().catch(() => null);
  if (data && data.ok && Array.isArray(data.result)) {
  for (const update of data.result) {
  offset = update.update_id + 1;
  metaSet("bot_offset", offset);
  await handleBotUpdate(update);
  }
  }
  } catch (e) {
  console.error("[bot]", e.message);
  }
  await new Promise((resolve) => setTimeout(resolve, 1500));
  }
  };
  loop();
  console.log("[bot] @HabibateacherBot ishga tushdi");
}

function testResultStats(lessonId) {
  const rows = db
.prepare("SELECT score FROM progress WHERE lesson_id = ? AND score IS NOT NULL")
.all(lessonId);
  const buckets = [
  { label: "70% va yuqori", min: 70, max: 100 },
  { label: "51-70%", min: 51, max: 69 },
  { label: "31-50%", min: 31, max: 50 },
  { label: "11-30%", min: 11, max: 30 },
  { label: "0-10%", min: 0, max: 10 }
  ].map((b) => ({...b, count: rows.filter((r) => r.score >= b.min && r.score <= b.max).length }));
  const top = db
.prepare(
  `SELECT u.id, u.name, p.score
  FROM progress p JOIN users u ON u.id = p.user_id
  WHERE p.lesson_id = ? AND p.score IS NOT NULL
  ORDER BY p.score DESC, p.completed_at ASC LIMIT 10`
  )
.all(lessonId);
  return { buckets, top, total: rows.length };
}

function materialRows(materials) {
  const labels = { pdf: "PDF", link: "Havola", text: "Matn" };
  const icons = { pdf: "file", link: "link", text: "book" };
  return materials
.map(
  (m) => `<a class="material-row" href="/materials/${m.id}"${
  m.type === "link" ? ` target="_blank" rel="noopener"`: ""
  }>
  <span class="material-ico">${icon(icons[m.type] || "file")}</span>
  <span class="material-main"><b>${h(m.title)}</b><small>${labels[m.type] || "Fayl"}${
  m.file_size ? `. ${formatSize(m.file_size)}`: ""
  }</small></span>
  <span class="material-open">Ochish   </span>
  </a>`
  )
.join("");
}

function testLanding(lesson, { user, admin, owned }) {
  const course = db.prepare("SELECT title, category FROM courses WHERE id = ?").get(lesson.course_id);
  const cat = course && course.category === "tkt" ? "TKT": "Attestatsiya";
  const price = Number(lesson.price) || 0;
  const isPro = price > 0;
  const qcount =
  Number(lesson.question_count) ||
  db.prepare("SELECT COUNT(*) AS n FROM questions WHERE lesson_id = ?").get(lesson.id).n;
  const maxScore = Number(lesson.max_score) || 0;
  const about =
  String(lesson.about || "").trim() ||
  `${course ? course.title: "Testlar"} bo'limidagi test. Jami savollar ${qcount} ta, ajratilgan vaqt   ${formatDuration(
  lesson.duration_min
  )}. Natija test yakunlangach avtomatik hisoblanadi va reytingga qo'shiladi.`;
  const stats = testResultStats(lesson.id);
  const maxCount = Math.max(1,...stats.buckets.map((b) => b.count));
  const progressRow = user
  ? db.prepare("SELECT score FROM progress WHERE user_id = ? AND lesson_id = ?").get(user.id, lesson.id)
: null;
  const materials = db.prepare("SELECT * FROM materials WHERE lesson_id = ? ORDER BY id").all(lesson.id);
  const canSeeMaterials = !!admin || !isPro || !!owned;
  const startHref = `/test/${lesson.id}?start=1`;
  const loginHref = `/login?next=${encodeURIComponent(startHref)}`;

  let action;
  if (!user) {
  action = `<p class="muted small">Testga kirish uchun tizimga kiring</p>
  <a class="btn btn-primary" href="${loginHref}">Kirish</a>`;
  } else if (owned) {
  action = `<a class="btn btn-primary" href="${startHref}">${progressRow ? "Qayta topshirish": "Testni boshlash"}</a>
  ${
  progressRow
  ? `<p class="muted small">Sizning natijangiz: <b>${progressRow.score}%</b></p>`
: `<p class="muted small">Tayyor bo'lsangiz, testni boshlang.</p>`
  }`;
  } else {
  action = `<p class="muted small">Test pullik. To'lovdan so'ng admin uni hisobingizga ochadi.</p>
  <a class="btn btn-primary" href="${h(config.telegram || "#")}" target="_blank" rel="noopener">Telegram orqali sotib olish</a>`;
  }

  const distRows = stats.buckets
.map(
  (b) => `<div class="dist-row">
  <span>${b.label}</span>
  <div class="dist-bar"><i style="width:${Math.round((b.count / maxCount) * 100)}%"></i></div>
  <b>${b.count}</b>
  </div>`
  )
.join("");

  const topRows = stats.top.length
  ? stats.top
.map((r, i) => {
  const shown = maxScore > 0 ? `${Math.round((r.score / 100) * maxScore)} / ${maxScore}`: `${r.score}%`;
  return `<div class="top-row${user && user.id === r.id ? " me": ""}">
  <span class="top-rank${i < 3 ? " top": ""}">${i + 1}</span>
  <b>${h(r.name)}</b>
  <span class="top-score">${shown}</span>
  </div>`;
  })
.join("")
: `<p class="muted small">Hozircha natijalar yo'q. Birinchi bo'lib topshiring.</p>`;

  const materialCard =
  canSeeMaterials && (materials.length || admin)
  ? `<article class="card test-materials">
  <div class="card-head">
  <h2>Materiallar</h2>
  ${admin ? `<a class="btn btn-sm" href="/admin/lesson/${lesson.id}/materials">Boshqarish</a>`: ""}
  </div>
  ${
  materials.length
  ? `<div class="material-list">${materialRows(materials)}</div>`
: `<p class="muted small">Hozircha material yo'q. Admin panelda qo'shishingiz mumkin.</p>`
  }
  </article>`
: isPro && !owned
  ? `<article class="card test-materials">
  <div class="card-head"><h2>Materiallar</h2></div>
  <p class="muted small">Materiallar test ochilgach ko'rinadi.</p>
  </article>`
: "";

  return `<section class="test-detail">
  <div class="wrap">
  <a class="back" href="${moduleHref(lesson)}">  ${cat}</a>
  <div class="test-detail-grid">
  <div class="test-detail-main">
  <article class="card test-info">
  <span class="pill">${isPro ? "Narx": "Bepul"}</span>
  <h1>${h(lesson.title)}</h1>
  <div class="test-social">
  <span class="like-btn" data-like="${lesson.id}" role="button" tabindex="0" title="Yoqdi">${icon("heart")} <b>${Number(lesson.likes) || 0}</b></span>
  <span>${icon("eye")} ${Number(lesson.views) || 0} Ko'rishlar</span>
  </div>
  <div class="test-meta4">
  <div>${icon("clock")}<span>Ajratilgan vaqt</span><b>${formatDuration(lesson.duration_min)}</b></div>
  <div>${icon("list")}<span>Savollar soni</span><b>${qcount} ta</b></div>
  <div>${icon("star")}<span>Eng yuqori ball</span><b>${maxScore} ball</b></div>
  <div>${icon("tag")}<span>Narx</span><b>${isPro ? `${formatSum(price)} so'm`: "Bepul"}</b></div>
  </div>
  <div class="test-about">
  <h2>Test haqida</h2>
  <div class="prose">${nl2br(about)}</div>
  ${admin ? `<a class="card-link" href="/admin/lesson/${lesson.id}/materials">Tavsif va materiallarni tahrirlash   </a>`: ""}
  </div>
  </article>
  ${materialCard}
  <article class="card test-distribution">
  <h2>Natijalar taqsimoti</h2>
  <p class="muted small">Har bir ishtirokchining eng yaxshi natijasi asosida</p>
  <div class="dist-list">${distRows}</div>
  <p class="muted small">Jami qatnashganlar: ${stats.total} ta</p>
  </article>
  </div>
  <aside class="test-detail-side">
  <div class="card test-buy">
  <div class="test-buy-price">${isPro ? `${formatSum(price)} so'm`: "Bepul"}</div>
  ${action}
  ${
  isPro
  ? `<div class="test-plan">
  <b>Bu testni tarif bilan oching</b>
  <p class="muted small">Bitta tarif   barcha pullik testlar uchun.</p>
  <div class="test-plan-price">299 000 so'm <span>/ 3 oy</span></div>
  <a class="card-link" href="/plans">Tarifni ko'rish   </a>
  </div>`
: ""
  }
  <p class="muted small">Savollar uchun: ${h(config.phone || "")}</p>
  </div>
  <div class="card test-top">
  <h2>Eng yaxshi 10 ishtirokchi</h2>
  <div class="top-list">${topRows}</div>
  </div>
  </aside>
  </div>
  </div>
  </section>`;
}

function duelCode() {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let code = "";
  for (let i = 0; i < 6; i += 1) code += chars[Math.floor(Math.random() * chars.length)];
  return code;
}

function getDuel(code) {
  return db
.prepare(
  `SELECT d.*, COALESCE(NULLIF(d.title, ''), l.title) AS lesson_title, l.course_id, l.duration_min,
  (SELECT COUNT(*) FROM duel_questions dq WHERE dq.duel_id = d.id) AS total_questions,
  uc.name AS creator_name, uo.name AS opponent_name
  FROM duels d
  JOIN lessons l ON l.id = d.lesson_id
  JOIN users uc ON uc.id = d.creator_id
  LEFT JOIN users uo ON uo.id = d.opponent_id
  WHERE d.code = ?`
  )
.get(code);
}

function duelPlays(duelId) {
  return Object.fromEntries(
  db
.prepare("SELECT * FROM duel_plays WHERE duel_id = ?")
.all(duelId)
.map((row) => [row.user_id, row])
  );
}

function duelInitial(name) {
  return String(name || "?").trim().charAt(0).toUpperCase() || "?";
}

function duelPlayerCard(duel, userId, name, play, isMe) {
  const seconds = play ? Math.max(0, Math.round(play.elapsed_ms / 1000)): 0;
  return `<div class="duel-player${isMe ? " me": ""}${!name ? " empty": ""}">
  <span class="duel-avatar">${name ? h(duelInitial(name)): "?"}</span>
  <b>${name ? h(name): "Raqib kutilmoqda"}</b>
  <small>${
  play
  ? `${play.correct}/${play.total} to'g'ri. ${seconds} soniya`
: name
  ? "Hali o'ynamadi"
: "Kodni do'stingizga yuboring"
  }</small>
  </div>`;
}

function duelRoomPage(duel, user) {
  const isCreator = duel.creator_id === user.id;
  const opponentId = isCreator ? duel.opponent_id: duel.creator_id;
  if (!isCreator && duel.opponent_id !== user.id) {
  return `<section class="page-hero center"><h1>Bu duel sizga tegishli emas</h1><p class="lead">Maxsus kod bilan yangi duelga qo'shiling.</p><a class="btn btn-primary" href="/duel">Duel sahifasi</a></section>`;
  }

  const plays = duelPlays(duel.id);
  const myPlay = plays[user.id];
  const oppPlay = opponentId ? plays[opponentId]: null;
  const creatorPlay = plays[duel.creator_id];
  const opponentPlay = duel.opponent_id ? plays[duel.opponent_id]: null;
  let winner = null;
  if (creatorPlay && opponentPlay) {
  if (creatorPlay.correct !== opponentPlay.correct) {
  winner = creatorPlay.correct > opponentPlay.correct ? duel.creator_id: duel.opponent_id;
  } else if (creatorPlay.elapsed_ms !== opponentPlay.elapsed_ms) {
  winner = creatorPlay.elapsed_ms < opponentPlay.elapsed_ms ? duel.creator_id: duel.opponent_id;
  }
  }

  const creatorCard = duelPlayerCard(duel, duel.creator_id, duel.creator_name, creatorPlay, user.id === duel.creator_id);
  const opponentCard = duelPlayerCard(
  duel,
  duel.opponent_id,
  duel.opponent_name,
  opponentPlay,
  user.id === duel.opponent_id
  );

  let action = "";
  if (duel.status === "waiting" || !duel.opponent_id) {
  action = `<div class="duel-invite card">
  <span class="eyebrow">Taklif kodi</span>
  <div class="duel-code">
  <b>${h(duel.code)}</b>
  <button class="btn btn-sm" type="button" data-copy="${h(duel.code)}">Nusxalash</button>
  <button class="btn btn-sm btn-primary" type="button" data-share="Duel kodi: ${h(
  duel.code
  )}   Habiba teacher platformasida duelga qo'shiling!">Do'stga yuborish</button>
  </div>
  <p class="muted small">Do'stingiz <b>/duel</b> sahifasida shu kodni kiritib qo'shiladi.</p>
  ${
  isCreator
  ? `<form method="post" action="/duel/${h(duel.code)}/delete" onsubmit="return confirm('Duel bekor qilinsinmi?')">
  <button class="btn btn-sm btn-danger" type="submit">Duelni bekor qilish</button>
  </form>`
: ""
  }
  </div>`;
  } else if (duel.status === "finished" || (creatorPlay && opponentPlay)) {
  const verdict =
  winner === null
  ? "Durang!"
: winner === user.id
  ? "G'alaba!"
: "Mag'lubiyat";
  action = `<div class="duel-result ${winner === user.id ? "win": winner ? "lose": "draw"}">
  <span class="duel-result-ico">${winner === user.id ? "x ": winner ? "x ": "x"}</span>
  <h2>${verdict}</h2>
  <p class="muted">${
  winner ? `G'olib: <b>${h(winner === duel.creator_id ? duel.creator_name: duel.opponent_name)}</b>`: "Ikkalangiz teng natija ko'rsatdingiz."
  }</p>
  <div class="actions">
  <a class="btn btn-primary" href="/duel">Yangi duel</a>
  <a class="btn btn-ghost" href="/attestation">Testlarga o'tish</a>
  </div>
  </div>`;
  } else if (myPlay) {
  action = `<div class="duel-wait">
  <span class="duel-spinner"></span>
  <h2>Raqib natijasi kutilmoqda</h2>
  <p class="muted">Sizning natijangiz: <b>${myPlay.correct}/${myPlay.total}</b>. ${Math.round(
  myPlay.elapsed_ms / 1000
  )} soniya</p>
  <a class="btn btn-ghost" href="/duel">Duel sahifasi</a>
  </div>`;
  } else {
  action = `<div class="duel-start">
  <h2>Tayyormisiz?</h2>
  <p class="muted">${Math.min(10, Number(duel.total_questions) || 10)} savol. har biriga 60 soniya. natija vaqti ham hisobga olinadi.</p>
  <a class="btn btn-primary btn-lg" href="/duel/${h(duel.code)}/start">Duelni boshlash a </a>
  </div>`;
  }

  return `<section class="duel-hero">
  <div class="wrap">
  <a class="back" href="/duel">  Duel</a>
  <span class="eyebrow">1 vs 1. ${h(duel.lesson_title)}</span>
  <h1>Duel xonasi</h1>
  <p class="lead">Kod: <b>${h(duel.code)}</b>. ${
  duel.status === "waiting" ? "Raqib kutilmoqda": duel.status === "finished" ? "Yakunlangan": "Jonli"
  }</p>
  </div>
  </section>
  <section class="section tight">
  <div class="wrap">
  <div class="duel-vs">
  ${creatorCard}
  <div class="vs-badge">VS</div>
  ${opponentCard}
  </div>
  ${action}
  </div>
  </section>`;
}

function todayKey() {
  return new Date(Date.now() + 5 * 3600 * 1000).toISOString().slice(0, 10);
}

function tournamentTest() {
  return db
.prepare(
  `SELECT l.id FROM lessons l JOIN courses c ON c.id = l.course_id
  WHERE l.type = 'test' AND l.price = 0 AND c.is_published = 1
  AND (SELECT COUNT(*) FROM questions q WHERE q.lesson_id = l.id) > 0
  ORDER BY l.id LIMIT 1`
  )
.get();
}

const TOURNAMENT_CAP = 16;
const TOURNAMENT_QUESTIONS = 15;

function tournamentQuestions(tournamentId) {
  return db
    .prepare(
      "SELECT q.* FROM tournament_questions tq JOIN questions q ON q.id = tq.question_id WHERE tq.tournament_id = ? ORDER BY tq.position"
    )
    .all(tournamentId);
}

function prepareTournamentQuestions(tournamentId) {
  db.prepare("DELETE FROM tournament_questions WHERE tournament_id = ?").run(tournamentId);
  const picked = db
    .prepare("SELECT id FROM questions ORDER BY RANDOM() LIMIT ?")
    .all(TOURNAMENT_QUESTIONS);
  const insert = db.prepare(
    "INSERT OR IGNORE INTO tournament_questions (tournament_id, question_id, position) VALUES (?, ?, ?)"
  );
  picked.forEach((q, i) => insert.run(tournamentId, q.id, i + 1));
  return picked.length;
}

function ensureOpenTournament() {
  const day = todayKey();
  const open = db
.prepare(
  `SELECT t.* FROM tournaments t
  WHERE t.day = ? AND t.status = 'open'
  AND (SELECT COUNT(*) FROM tournament_entries e WHERE e.tournament_id = t.id) < 16
  ORDER BY t.group_no LIMIT 1`
  )
.get(day);
  if (open) return open;
  const last = db.prepare("SELECT COALESCE(MAX(group_no), 0) AS n FROM tournaments WHERE day = ?").get(day).n;
  const test = tournamentTest();
  const info = db
.prepare(
  "INSERT INTO tournaments (day, group_no, test_id, status, size, created_at) VALUES (?, ?, ?, 'open', 16, ?)"
  )
.run(day, Number(last) + 1, test ? test.id: 0, nowISO());
  return db.prepare("SELECT * FROM tournaments WHERE id = ?").get(Number(info.lastInsertRowid));
}

function ensureTournament() {
  const day = todayKey();
  const latest = db
.prepare("SELECT * FROM tournaments WHERE day = ? ORDER BY group_no DESC LIMIT 1")
.get(day);
  return latest || ensureOpenTournament();
}

function tournamentGroups(day = todayKey()) {
  return db.prepare("SELECT * FROM tournaments WHERE day = ? ORDER BY group_no").all(day);
}

function ensureJoinableTournament() {
  for (const tournament of tournamentGroups()) {
  const entries = tournamentEntries(tournament.id);
  if (entries.length >= TOURNAMENT_CAP) continue;
  const matches = tournamentMatches(tournament.id);
  const hasScores = matches.some((m) => m.s1 != null || m.s2 != null);
  if (tournament.status === "open" || (tournament.status === "live" && !hasScores)) return tournament;
  }
  return ensureOpenTournament();
}

function tournamentEntries(tid) {
  return db
.prepare(
  `SELECT e.*, u.name FROM tournament_entries e JOIN users u ON u.id = e.user_id
  WHERE e.tournament_id = ? ORDER BY e.seed`
  )
.all(tid);
}

function autoEnrollTournament(tournament) {
  if (!tournament || tournament.status !== "open") return tournamentEntries(tournament ? tournament.id : 0);
  const entries = tournamentEntries(tournament.id);
  if (entries.length >= TOURNAMENT_CAP) return entries;
  const enrolledToday = new Set(
    db
      .prepare(
        "SELECT e.user_id FROM tournament_entries e JOIN tournaments t ON t.id = e.tournament_id WHERE t.day = ?"
      )
      .all(tournament.day)
      .map((r) => r.user_id)
  );
  const users = db
    .prepare("SELECT id FROM users ORDER BY id")
    .all()
    .filter((u) => !enrolledToday.has(u.id));
  for (let i = users.length - 1; i > 0; i -= 1) {
    const j = Math.floor(Math.random() * (i + 1));
    [users[i], users[j]] = [users[j], users[i]];
  }
  const insert = db.prepare(
    "INSERT OR IGNORE INTO tournament_entries (tournament_id, user_id, seed, joined_at) VALUES (?, ?, ?, ?)"
  );
  let seed = entries.length;
  for (const u of users) {
    if (seed >= TOURNAMENT_CAP) break;
    seed += 1;
    insert.run(tournament.id, u.id, seed, nowISO());
  }
  const fresh = tournamentEntries(tournament.id);
  if (fresh.length !== entries.length) {
    db.prepare("UPDATE tournaments SET size = ? WHERE id = ?").run(16, tournament.id);
  }
  return fresh;
}

function autoEnrollAll() {
  if (tashkentClock().minutes >= 1080) return;
  const day = todayKey();
  const enrolledToday = new Set(
    db
      .prepare(
        "SELECT e.user_id FROM tournament_entries e JOIN tournaments t ON t.id = e.tournament_id WHERE t.day = ?"
      )
      .all(day)
      .map((r) => r.user_id)
  );
  const pending = db.prepare("SELECT id FROM users").all().filter((u) => !enrolledToday.has(u.id));
  if (!pending.length) return;
  for (let i = 0; i < 20; i += 1) {
    const groups = tournamentGroups();
    let target = groups.find(
      (g) => g.status === "open" && tournamentEntries(g.id).length < TOURNAMENT_CAP
    );
    if (!target) {
      const hasOpen = groups.some((g) => g.status === "open");
      if (!hasOpen) {
        target = ensureOpenTournament();
      } else {
        const created = ensureOpenTournament();
        if (!created || tournamentEntries(created.id).length >= TOURNAMENT_CAP) break;
        target = created;
      }
    }
    if (!target) break;
    const before = tournamentEntries(target.id).length;
    autoEnrollTournament(target);
    if (tournamentEntries(target.id).length === before) break;
  }
}

function tournamentMatches(tid) {
  return db
.prepare("SELECT * FROM tournament_matches WHERE tournament_id = ? ORDER BY round, slot")
.all(tid);
}

function tournamentRoundName(size, round) {
  const rounds = Math.log2(size);
  if (round === rounds) return "FINAL";
  const left = size / 2 ** round;
  if (left === 2) return "1/2 FINAL";
  if (left === 4) return "1/4 FINAL";
  return `1/${left}`;
}

function bracketRoundTimes(size) {
  const rounds = Math.log2(size);
  const first = 10 * 60;
  const last = 16 * 60;
  const step = rounds > 1 ? (last - first) / (rounds - 1): 0;
  return Array.from({ length: rounds }, (_, i) => {
  const total = Math.round(first + step * i);
  return `${String(Math.floor(total / 60)).padStart(2, "0")}:${String(total % 60).padStart(2, "0")}`;
  });
}

function propagateTournament(tid) {
  const tournament = db.prepare("SELECT * FROM tournaments WHERE id = ?").get(tid);
  if (!tournament) return;
  const matches = tournamentMatches(tid);
  const byKey = new Map(matches.map((m) => [`${m.round}:${m.slot}`, m]));
  const rounds = Math.log2(tournament.size);
  for (let r = 1; r < rounds; r += 1) {
  for (const m of matches.filter((x) => x.round === r)) {
  if (!m.winner) continue;
  const next = byKey.get(`${r + 1}:${Math.floor(m.slot / 2)}`);
  if (!next) continue;
  const field = m.slot % 2 === 0 ? "p1": "p2";
  if (!next[field]) {
  db.prepare(`UPDATE tournament_matches SET ${field} = ? WHERE id = ?`).run(m.winner, next.id);
  next[field] = m.winner;
  }
  }
  for (const m of matches.filter((x) => x.round === r + 1)) {
  const a = byKey.get(`${r}:${m.slot * 2}`);
  const b = byKey.get(`${r}:${m.slot * 2 + 1}`);
  if (m.p1 && !m.p2 && b && !b.p1 && !b.p2 && !b.winner) {
  db.prepare("UPDATE tournament_matches SET winner = ?, status = 'bye', finished_at = ? WHERE id = ?").run(
  m.p1,
  nowISO(),
  m.id
  );
  m.winner = m.p1;
  m.status = "bye";
  } else if (m.p2 && !m.p1 && a && !a.p1 && !a.p2 && !a.winner) {
  db.prepare("UPDATE tournament_matches SET winner = ?, status = 'bye', finished_at = ? WHERE id = ?").run(
  m.p2,
  nowISO(),
  m.id
  );
  m.winner = m.p2;
  m.status = "bye";
  } else if (m.p1 && m.p2 && m.status === "pending") {
  db.prepare("UPDATE tournament_matches SET status = 'ready' WHERE id = ?").run(m.id);
  m.status = "ready";
  notifyTournamentMatchPlayers(tid, r + 1).catch(() => {});
  }
  }
  }
  const final = matches.find((m) => m.round === rounds);
  const finalNow = db
.prepare("SELECT * FROM tournament_matches WHERE tournament_id = ? AND round = ?")
.get(tid, rounds);
  if (finalNow && finalNow.winner) {
  db.prepare("UPDATE tournaments SET status = 'finished', finished_at = ? WHERE id = ? AND status != 'finished'").run(
  nowISO(),
  tid
  );
  }
}

function nextPowerOfTwo(count) {
  let size = 8;
  while (size < count && size < 128) size *= 2;
  return size;
}

function seedOrder(size) {
  let order = [0];
  while (order.length < size) {
  const n = order.length * 2;
  const next = [];
  for (const value of order) {
  next.push(value, n - 1 - value);
  }
  order = next;
  }
  return order;
}

function startTournament(tid) {
  const tournament = db.prepare("SELECT * FROM tournaments WHERE id = ?").get(tid);
  const entries = tournamentEntries(tid);
  if (!tournament || tournament.status !== "open" || entries.length < 2) return false;
  const size = Math.max(16, nextPowerOfTwo(entries.length));
  const order = seedOrder(size);
  const slots = new Array(size).fill(null);
  entries.slice(0, size).forEach((e, i) => {
  slots[order[i]] = e.user_id;
  });
  db.prepare("UPDATE tournaments SET status = 'live', size = ?, started_at = ? WHERE id = ?").run(
  size,
  nowISO(),
  tid
  );
  prepareTournamentQuestions(tid);
  db.prepare("DELETE FROM tournament_matches WHERE tournament_id = ?").run(tid);
  const rounds = Math.log2(size);
  for (let r = 1; r <= rounds; r += 1) {
  const count = size / 2 ** r;
  for (let s = 0; s < count; s += 1) {
  let p1 = null;
  let p2 = null;
  let status = "pending";
  let winner = null;
  if (r === 1) {
  p1 = slots[s * 2];
  p2 = slots[s * 2 + 1];
  if (p1 && p2) status = "ready";
  else if (p1) {
  status = "bye";
  winner = p1;
  } else if (p2) {
  status = "bye";
  winner = p2;
  }
  }
  db.prepare(
  "INSERT INTO tournament_matches (tournament_id, round, slot, p1, p2, winner, status, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  ).run(tid, r, s, p1, p2, winner, status, nowISO());
  }
  }
  propagateTournament(tid);
  notifyTournamentMatchPlayers(tid, 1).catch(() => {});
  return true;
}

function bracketMatchCard(match, names, user) {
  const p1 = match.p1 ? names[match.p1]: null;
  const p2 = match.p2 ? names[match.p2]: null;
  const score = (id, s) => (id && s != null ? `<em>${s}</em>`: "");
  const canPlay =
  match.status === "ready" &&
  user &&
  (match.p1 === user.id || match.p2 === user.id) &&
  (match.p1 !== user.id || match.s1 == null) &&
  (match.p2 !== user.id || match.s2 == null);
  return `<div class="bracket-match ${match.status}${match.winner ? " done": ""}">
  <div class="bracket-player${match.winner === match.p1 && match.p1 ? " win": ""}">
  <span>${p1 ? h(p1): " "}</span>${score(match.p1, match.s1)}
  </div>
  <div class="bracket-player${match.winner === match.p2 && match.p2 ? " win": ""}">
  <span>${p2 ? h(p2): " "}</span>${score(match.p2, match.s2)}
  </div>
  ${canPlay ? `<a class="bracket-play" href="/duel/tournament/match/${match.id}">O'ynash</a>`: ""}
  ${match.status === "bye" ? `<span class="bracket-tag">BYE</span>`: ""}
  ${match.status === "ready" && !canPlay ? `<span class="bracket-tag live">Kutilmoqda</span>`: ""}
  </div>`;
}

function bracketPreview(size = 8) {
  const card = `<div class="bracket-match"><div class="bracket-player"><span> </span></div><div class="bracket-player"><span> </span></div></div>`;
  const rounds = Math.log2(size);
  const times = bracketRoundTimes(size);
  const columns = [];
  for (let r = 1; r <= rounds; r += 1) {
  const count = size / 2 ** r;
  columns.push(`<div class="bracket-round"><div class="bracket-title${r === rounds ? " final": ""}">${tournamentRoundName(
  size,
  r
  )}${r === rounds ? ` <span class="bracket-cup">x </span>`: ""}</div><div class="bracket-time"> ${times[r - 1]}</div><div class="bracket-list">${card.repeat(
  count
  )}</div></div>`);
  }
  columns.push(`<div class="bracket-round winner-round"><div class="bracket-title final">G'OLIB</div><div class="bracket-time">x </div><div class="bracket-list"><div class="bracket-winner"><span class="bracket-trophy">x </span><b> </b><small>G'olib shu yerda</small></div></div></div>`);
  return `<div class="bracket-scroll"><div class="bracket">${columns.join("")}</div></div>`;
}

function tournamentPage(tournament, user, admin, groups = []) {
  const entries = tournamentEntries(tournament.id);
  const matches = tournamentMatches(tournament.id);
  const names = Object.fromEntries(
  db.prepare("SELECT id, name FROM users").all().map((u) => [u.id, u.name])
  );
  const joined = user && entries.some((e) => e.user_id === user.id);
  const hasScores = matches.some((m) => m.s1 != null || m.s2 != null);
  const lateOpen = tournament.status === "open" || (tournament.status === "live" && !hasScores);
  const testLabel = `Aralash test · ${TOURNAMENT_QUESTIONS} savol`;
  const rounds = tournament.status === "open" ? 0: Math.log2(tournament.size);
  const champion = matches.find((m) => m.round === rounds && m.winner);

  let banner = "";
  if (admin && tournament.status === "open") {
  banner = `<div class="card tour-join">
  <div><b>Turnirni boshqarish</b><p class="muted small">${entries.length} ishtirokchi. Boshlash uchun kamida 2 ishtirokchi kerak.</p></div>
  <form method="post" action="/duel/tournament/start"><button class="btn btn-primary" type="submit" ${
  entries.length >= 2 ? "": "disabled"
  }>Turnirni boshlash</button></form>
  </div>`;
  } else if (!user) {
  banner = `<div class="card empty"><b>Turnirda qatnashish uchun tizimga kiring.</b><div class="actions" style="justify-content:center;margin-top:12px"><a class="btn btn-primary" href="/login?next=/duel/tournament">Kirish</a></div></div>`;
  } else if (lateOpen && !joined) {
  banner = `<div class="card empty"><b>Siz bugungi turnirda qatnashmayapsiz.</b><p class="muted small">${entries.length} ishtirokchi. Turnir 09:00 da avtomatik boshlanadi.</p></div>`;
  } else if (lateOpen) {
  banner = `<div class="card tour-join"><div><b>Siz avtomatik qatnashasiz S&</b><p class="muted small">${entries.length} ishtirokchi. Turnir 09:00 da avtomatik boshlanadi   qo'shilish tugmasini bosish shart emas.</p></div>${
  admin
  ? `<form method="post" action="/duel/tournament/start"><button class="btn btn-primary" type="submit" ${
  entries.length >= 2 ? "": "disabled"
  }>Turnirni boshlash</button></form>`
: ""
  }</div>`;
  } else if (tournament.status === "finished") {
  banner = `<div class="card tour-champion"><span class="tour-cup">x </span><div><span class="eyebrow">Kunlik duel g'olibi</span><h2>${h(
  champion ? names[champion.winner] || "G'olib": "Aniqlanmadi"
  )}</h2><p class="muted small">${h(tournament.day)}. ${h(testLabel)}</p></div></div>`;
  }

  const columns = [];
  if (rounds) {
  const times = bracketRoundTimes(tournament.size);
  for (let r = 1; r <= rounds; r += 1) {
  const list = matches.filter((m) => m.round === r).sort((a, b) => a.slot - b.slot);
  columns.push(`<div class="bracket-round">
  <div class="bracket-title${r === rounds ? " final": ""}">${tournamentRoundName(tournament.size, r)}${
  r === rounds ? ` <span class="bracket-cup">x </span>`: ""
  }</div>
  <div class="bracket-time"> ${times[r - 1]}</div>
  <div class="bracket-list">${list.map((m) => bracketMatchCard(m, names, user)).join("")}</div>
  </div>`);
  }
  const winnerName = champion ? names[champion.winner] || "G'olib": "";
  columns.push(`<div class="bracket-round winner-round">
  <div class="bracket-title final">G'OLIB</div>
  <div class="bracket-time">x  ${champion ? "Aniqlangan": "Kutilmoqda"}</div>
  <div class="bracket-list"><div class="bracket-winner${winnerName ? " done": ""}">
  <span class="bracket-trophy">x </span>
  <b>${winnerName ? h(winnerName): " "}</b>
  <small>${winnerName ? "Turnir g'olibi": "G'olib shu yerda"}</small>
  </div></div>
  </div>`);
  }

  const participants = entries.length
  ? entries
.map(
  (e, i) => `<span class="tour-chip"><b>${i + 1}</b> ${h(e.name)}${e.user_id === (user && user.id) ? ". siz": ""}</span>`
  )
.join("")
: `<span class="muted">Hozircha ishtirokchilar yo'q.</span>`;

  return `<section class="duel-hero tour-hero">
  <div class="wrap">
  <a class="back" href="/duel">  Duel</a>
  <span class="eyebrow">Kunlik pley-off. ${h(tournament.day)}</span>
  <h1>Kunlik duel${groups.length > 1 ? `. ${tournament.group_no}-guruh`: ""}</h1>
  <p class="lead">${h(testLabel)}. ${entries.length} ishtirokchi. finalga qadar sxema.</p>
  </div>
  </section>
  ${
  groups.length > 1
  ? `<div class="wrap tour-tabs">${groups
.map(
  (g) =>
  `<a class="tour-tab${g.id === tournament.id ? " active": ""}" href="/duel/tournament?g=${
  g.group_no
  }">${g.group_no}-guruh</a>`
  )
.join("")}</div>`
: ""
  }
  <section class="section tight">
  <div class="wrap">
  ${banner}
  <div class="tour-participants">${participants}</div>
  ${
  tournament.status === "open"
  ? `${bracketPreview(nextPowerOfTwo(Math.max(16, entries.length)))}<p class="muted small center">Barcha ro'yxatdan o'tgan a'zolar avtomatik qo'shiladi. Turnir 09:00 da boshlanadi.</p>`
: `<div class="bracket-scroll"><div class="bracket">${columns.join("")}</div></div>`
  }
  <p class="muted small center" style="margin-top:16px">Har bir match ${TOURNAMENT_QUESTIONS} ta aralash savol. Har savolga 60 soniya. ko'proq to'g'ri javob, teng bo'lsa tezroq o'yinchi yutadi.</p>
  </div>
  </section>`;
}

function tournamentMatchPage(match, tournament, questions, user) {
  const total = questions.length;
  const limit = Math.max(1, total) * 60;
  const names = Object.fromEntries(
  db.prepare("SELECT id, name FROM users WHERE id IN (?, ?)").all(match.p1, match.p2).map((u) => [u.id, u.name])
  );
  const slides = questions
.map(
  (q, i) => `<section class="q-slide${i === 0 ? " is-active": ""}" data-i="${i}">
  <div class="q-label">${i + 1}-savol</div>
  <h2 class="q-title">${h(q.text)}</h2>
  <div class="q-options">
  ${[1, 2, 3, 4]
.map(
  (n) => `<label class="q-opt"><input type="radio" name="q${q.id}" value="${n}"><span class="q-letter">${"ABCD"[n - 1]}</span><span class="q-text">${h(q["o" + n])}</span></label>`
  )
.join("")}
  </div>
  </section>`
  )
.join("");
  const body = `
  <header class="test-header">
  <a class="test-brand" href="/duel/tournament"><span class="mark">H</span><b>Kunlik duel</b></a>
  <div class="test-mid"><b>${h(names[match.p1] || "?")} vs ${h(names[match.p2] || "?")}</b><span id="qCounter">1 / ${total} savol</span></div>
  <div class="test-tools"><span class="duel-live">${tournamentRoundName(tournament.size, match.round)}</span><a class="test-exit" href="/duel/tournament">Chiqish</a><div class="test-timer" id="timer">--:--</div></div>
  </header>
  <main class="test-main single">
  <section class="test-pane">
  <form method="post" action="/duel/tournament/match/${match.id}/submit" id="tourForm">
  <input type="hidden" name="tour_total" value="${total}">
  ${slides}
  <div class="test-nav">
  <button type="button" class="tbtn" id="prevBtn">  Oldingi</button>
  <div class="q-dots" id="dots"></div>
  <button type="button" class="tbtn primary" id="nextBtn">Keyingi   </button>
  <button type="submit" class="tbtn primary" id="finishBtn" hidden>Yakunlash</button>
  </div>
  </form>
  </section>
  </main>
  <script>
  (function () {
  var slides = Array.prototype.slice.call(document.querySelectorAll('.q-slide'));
  var counter = document.getElementById('qCounter');
  var prev = document.getElementById('prevBtn');
  var next = document.getElementById('nextBtn');
  var finish = document.getElementById('finishBtn');
  var form = document.getElementById('tourForm');
  var dots = document.getElementById('dots');
  var index = 0;
  slides.forEach(function (s, i) { var d = document.createElement('span'); d.className = 'q-dot' + (i === 0 ? ' active': ''); dots.appendChild(d); });
  var dotEls = Array.prototype.slice.call(dots.children);
  function refresh() {
  counter.textContent = (index + 1) + ' / ' + slides.length + ' savol';
  prev.disabled = index === 0;
  next.hidden = index === slides.length - 1;
  finish.hidden = index !== slides.length - 1;
  dotEls.forEach(function (d, i) { d.classList.toggle('active', i === index); d.classList.toggle('answered', !!slides[i].querySelector('input:checked')); });
  }
  function show(n) { index = Math.max(0, Math.min(slides.length - 1, n)); slides.forEach(function (s, i) { s.classList.toggle('is-active', i === index); }); refresh(); }
  prev.addEventListener('click', function () { show(index - 1); });
  next.addEventListener('click', function () { show(index + 1); });
  document.querySelectorAll('.q-opt input').forEach(function (i) { i.addEventListener('change', refresh); });
  form.addEventListener('submit', function (e) {
  var unanswered = slides.filter(function (s) { return !s.querySelector('input:checked'); }).length;
  if (unanswered && !confirm(unanswered + ' ta savol javobsiz. Baribir yakunlaysizmi?')) e.preventDefault();
  });
  var left = ${limit};
  var timer = document.getElementById('timer');
  function tick() {
  var m = Math.floor(left / 60);
  var s = left % 60;
  timer.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  if (left <= 0) { form.submit(); return; }
  left -= 1;
  }
  tick();
  setInterval(tick, 1000);
  })();
  </script>`;
  return testDocument({ title: "Kunlik duel", body });
}

function tashkentClock() {
  const d = new Date(Date.now() + 5 * 3600000);
  return {
  day: d.toISOString().slice(0, 10),
  minutes: d.getUTCHours() * 60 + d.getUTCMinutes()
  };
}

function tournamentPairingLines(tournamentId, round) {
  const rows = db
.prepare(
  `SELECT m.slot, m.p1, m.p2, m.winner, m.status,
  u1.name AS p1name, u1.phone AS p1phone,
  u2.name AS p2name, u2.phone AS p2phone
  FROM tournament_matches m
  LEFT JOIN users u1 ON u1.id = m.p1
  LEFT JOIN users u2 ON u2.id = m.p2
  WHERE m.tournament_id = ? AND m.round = ?
  ORDER BY m.slot`
  )
.all(tournamentId, round);
  if (!rows.length) return "Juftliklar hali tayyor emas.";
  return rows
.map((m, i) => {
  const a = m.p1name ? `${h(m.p1name)}${m.p1phone ? ` (${h(m.p1phone)})`: ""}`: " ";
  const b = m.p2name ? `${h(m.p2name)}${m.p2phone ? ` (${h(m.p2phone)})`: ""}`: "raqib yo'q";
  return `${i + 1}. ${a} vs ${b}${m.winner ? " S&": ""}`;
  })
.join("\n");
}

async function sendTournamentSchedule(tournament) {
  const entries = tournamentEntries(tournament.id);
  const text = `x  <b>Bugungi duel kubogi</b>
x & ${h(tournament.day)}
x} Aralash test · ${TOURNAMENT_QUESTIONS} savol
x  ${entries.length} ishtirokchi

 <b>Kun jadvali</b>
09:00   start
10:00   1/8 final
12:00   1/4 final
14:00   1/2 final
16:00   final
17:15   g'olib
18:00   yakun

a  <b>${tournamentRoundName(tournament.size, 1)} final juftliklari</b>
${tournamentPairingLines(tournament.id, 1)}

Duelni ochish: /duel/tournament`;
  await notifyTelegram(
  text,
  telegramDuelKeyboard(`/duel/tournament?g=${tournament.group_no}`, "Turnirni ochish")
  );
}

async function sendTournamentRound(tournament, round) {
  const label = tournamentRoundName(tournament.size, round);
  const text = `a  <b>${label} boshlandi</b>
x & ${h(tournament.day)}

${tournamentPairingLines(tournament.id, round)}

Duelni ochish: /duel/tournament`;
  await notifyTelegram(
  text,
  telegramDuelKeyboard(`/duel/tournament?g=${tournament.group_no}`, "Turnirni ochish")
  );
}

async function sendTournamentWinner(tournament) {
  const rounds = Math.log2(tournament.size);
  const final = db
.prepare("SELECT * FROM tournament_matches WHERE tournament_id = ? AND round = ?")
.get(tournament.id, rounds);
  if (!final || !final.winner) {
  await notifyTelegram(`x  <b>Bugungi duel kubogi</b>\nFinal hali yakunlanmagan. 18:00 gacha davom etadi.`);
  return;
  }
  const winner = db.prepare("SELECT name, phone FROM users WHERE id = ?").get(final.winner);
  await notifyTelegram(`x  <b>Bugungi duel kubogi g'olibi   ${h(winner?.name || "?")}!</b>
x ~ ${h(winner?.phone || "")}
x & ${h(tournament.day)}

Tabriklaymiz! Keyingi kubok   keyingi ish kuni, juftlar 09:00 da, duellar 10:00 dan.`);
}

async function closeTournament(tournament) {
  const rounds = Math.log2(tournament.size);
  const final = db
.prepare("SELECT * FROM tournament_matches WHERE tournament_id = ? AND round = ?")
.get(tournament.id, rounds);
  db.prepare("UPDATE tournaments SET status = 'finished', finished_at = ? WHERE id = ?").run(
  nowISO(),
  tournament.id
  );
  return final ? final.winner: null;
}

async function tournamentTick() {
  const clock = tashkentClock();
  let groups = tournamentGroups(clock.day);
  if (!groups.length) {
  ensureOpenTournament();
  groups = tournamentGroups(clock.day);
  }

  for (const tournament of groups) {
  const flag = (key) => `tour_${tournament.day}_${tournament.group_no}_${key}`;
  const label = tournament.group_no > 1 ? ` (${tournament.group_no}-guruh)`: "";

  if (tournament.status === "open") autoEnrollAll();

  if (tournament.status === "open" && clock.minutes >= 540 && clock.minutes < 1080) {
  const entries = tournamentEntries(tournament.id);
  if (entries.length >= 2) {
  if (startTournament(tournament.id)) {
  const fresh = db.prepare("SELECT * FROM tournaments WHERE id = ?").get(tournament.id);
  if (metaGet(flag("start")) !== "1") {
  metaSet(flag("start"), "1");
  await sendTournamentSchedule(fresh);
  }
  }
  } else if (metaGet(flag("need")) !== "1") {
  metaSet(flag("need"), "1");
  await notifyTelegram(
  `x  <b>Bugungi duel kubogi${label}</b>\nTurnir 09:00 da boshlanishi kerak edi, lekin hozircha ${entries.length} ishtirokchi bor.\nKamida 2 ishtirokchi kerak. /duel/tournament`
  );
  }
  }

  if (tournament.status === "live") {
  const rounds = Math.log2(tournament.size);
  const roundTimes = [600, 720, 840, 960, 990, 1020, 1035];
  for (let r = 1; r <= Math.min(rounds, roundTimes.length); r += 1) {
  const key = `r${r}`;
  if (clock.minutes >= roundTimes[r - 1] && metaGet(flag(key)) !== "1") {
  metaSet(flag(key), "1");
  await sendTournamentRound(tournament, r);
  }
  }
  if (clock.minutes >= 1035 && metaGet(flag("winner")) !== "1") {
  metaSet(flag("winner"), "1");
  await sendTournamentWinner(tournament);
  }
  }

  if (clock.minutes >= 1080 && tournament.status !== "finished") {
  const winnerId = await closeTournament(tournament);
  metaSet(flag("closed"), "1");
  if (winnerId) {
  const winner = db.prepare("SELECT name FROM users WHERE id = ?").get(winnerId);
  await notifyTelegram(
  `x  <b>Kunlik duel yakunlandi${label}</b>\nG'olib: <b>${h(
  winner?.name || "?"
  )}</b>\n18:00   turnir yopildi.`
  );
  } else {
  await notifyTelegram(
  `x <b>Kunlik duel yakunlandi${label}</b>\n18:00   turnir yopildi. Bugun g'olib aniqlanmadi.`
  );
  }
  }
  }
}

function startTournamentScheduler() {
  setTimeout(() => {
  tournamentTick().catch((e) => console.error("[tour]", e.message));
  }, 5000);
  setInterval(() => {
  tournamentTick().catch((e) => console.error("[tour]", e.message));
  }, 60 * 1000);
}

/* --------------------------------------------------- daily Telegram reminders */
function dayRange(day) {
  const start = new Date(`${day}T00:00:00+05:00`);
  const end = new Date(start.getTime() + 24 * 3600 * 1000);
  return { start: start.toISOString(), end: end.toISOString() };
}

function activeUserIdsToday(day) {
  const { start, end } = dayRange(day);
  const ids = new Set();
  db.prepare("SELECT DISTINCT user_id FROM progress WHERE completed_at >= ? AND completed_at < ?")
.all(start, end)
.forEach((row) => ids.add(row.user_id));
  db.prepare(
  `SELECT DISTINCT e.user_id FROM tournament_entries e
  JOIN tournaments t ON t.id = e.tournament_id
  WHERE t.day = ? AND EXISTS (
  SELECT 1 FROM tournament_matches m
  WHERE m.tournament_id = t.id AND (m.p1 = e.user_id OR m.p2 = e.user_id)
  AND (m.s1 IS NOT NULL OR m.s2 IS NOT NULL)
  )`
  )
.all(day)
.forEach((row) => ids.add(row.user_id));
  return ids;
}

function tournamentWinnerToday(day) {
  const final = db
.prepare(
  `SELECT m.winner, u.name FROM tournament_matches m
  JOIN tournaments t ON t.id = m.tournament_id
  LEFT JOIN users u ON u.id = m.winner
  WHERE t.day = ? AND m.winner IS NOT NULL
  ORDER BY t.group_no DESC, m.round DESC LIMIT 1`
  )
.get(day);
  return final && final.name ? final.name: "";
}

async function reminderStep(key, at, handler) {
  const clock = tashkentClock();
  if (clock.minutes < at || clock.minutes > at + 90) return;
  const flag = `rem_${clock.day}_${key}`;
  if (metaGet(flag) === "1") return;
  metaSet(flag, "1");
  await handler(clock.day);
}

async function reminderTick() {
  const clock = tashkentClock();
  const day = clock.day;
  const telegramUsers = db
.prepare("SELECT id, name, telegram_id FROM users WHERE telegram_id IS NOT NULL AND telegram_id <> ''")
.all();
  if (!telegramUsers.length) return;

  const send = async (list, textFor, path, label) => {
  for (const user of list) {
  await sendUserMessage(user.id, textFor(user), path, label).catch(() => {});
  await new Promise((resolve) => setTimeout(resolve, 80));
  }
  };

  await reminderStep("09", 540, async () => {
  const active = activeUserIdsToday(day);
  const list = telegramUsers.filter((u) => !active.has(u.id));
  if (!list.length) return;
  await send(
  list,
  (u) => `xR& <b>Assalomu alaykum, ${h(u.name)}!</b>\n\nBugungi bosqich boshlandi va soat <b>18:00</b> gacha davom etadi.\nx  Bugun allaqachon <b>${active.size}</b> kishi qatnashdi.\n\nBosqichni hoziroq boshlang!`,
  "/duel/tournament",
  "Bosqichni boshlash"
  );
  });

  await reminderStep("12", 720, async () => {
  const active = activeUserIdsToday(day);
  const list = telegramUsers.filter((u) => !active.has(u.id));
  if (!list.length) return;
  await send(
  list,
  (u) => `x 9 <b>${h(u.name)}</b>, bugun hali qatnashmadingiz.\n\nBosqich <b>18:00</b> gacha ochiq.\nBugun <b>${active.size}</b> kishi allaqachon bajarib bo'ldi.\n\nVaqtni boy bermang!`,
  "/duel/tournament",
  "Bosqichni ochish"
  );
  });

  await reminderStep("17", 1020, async () => {
  const active = activeUserIdsToday(day);
  const list = telegramUsers.filter((u) => !active.has(u.id));
  if (!list.length) return;
  await send(
  list,
  (u) => ` <b>${h(u.name)}</b>, bugungi bosqich hali bajarilmagan!\n\nBosqich <b>18:00</b> da yopiladi   atigi <b>1 soat</b> qoldi.\nBugun <b>${active.size}</b> kishi qatnashdi.\n\nHoziroq qo'shiling!`,
  "/duel/tournament",
  "Bosqichni ochish"
  );
  });

  await reminderStep("18", 1081, async () => {
  const active = activeUserIdsToday(day);
  const winner = tournamentWinnerToday(day);
  const weekly = new Date(`${day}T12:00:00+05:00`).getUTCDay() === 0;
  await send(
  telegramUsers,
  (u) =>
  `x <b>Kun yakunlandi.</b>\n\nBugun <b>${active.size}</b> kishi qatnashdi.${
  winner ? `\nx  Kun g'olibi: <b>${h(winner)}</b>`: ""
  }\n\n${
  weekly
  ? "x & Hafta yakunlandi. <b>Dushanba 09:00</b> da yangi hafta boshlanadi   qaytib keling! x "
: "xR& Ertaga <b>09:00</b> da yangi bosqich boshlanadi   qaytib keling! x "
  }`,
  "/leaderboard",
  "Natijalarni ko'rish"
  );
  });
}

function startReminderScheduler() {
  setTimeout(() => {
  reminderTick().catch((e) => console.error("[rem]", e.message));
  }, 15000);
  setInterval(() => {
  reminderTick().catch((e) => console.error("[rem]", e.message));
  }, 60 * 1000);
}


function dashboardPage(user) {
  const lessons = db
    .prepare(
      `SELECT l.*, c.title AS course_title, c.category AS course_category
       FROM lessons l JOIN courses c ON c.id = l.course_id
       WHERE c.is_published = 1
       ORDER BY c.id, l.position, l.id`
    )
    .all();
  const doneRows = db.prepare("SELECT lesson_id FROM progress WHERE user_id = ?").all(user.id);
  const done = new Set(doneRows.map((r) => r.lesson_id));
  const total = lessons.length;
  const completed = lessons.filter((l) => done.has(l.id)).length;
  const pct = total ? Math.round((completed / total) * 100) : 0;
  const next = lessons.find((l) => !done.has(l.id));
  const clock = tashkentClock();
  const todayDone = db
    .prepare("SELECT COUNT(*) AS n FROM progress WHERE user_id = ? AND substr(completed_at, 1, 10) = ?")
    .get(user.id, clock.day).n;
  const rankRow = db
    .prepare(
      `SELECT COUNT(*) + 1 AS rank FROM (
         SELECT user_id, COUNT(*) AS c FROM progress GROUP BY user_id
       ) t WHERE t.c > (SELECT COUNT(*) FROM progress WHERE user_id = ?)`
    )
    .get(user.id);
  const rank = Number(rankRow.rank) || 1;
  const achievements = [completed >= 1, completed >= 5, completed >= 10, completed >= 25].filter(Boolean).length;
  const weekStart = new Date(Date.now() - 7 * 86400000).toISOString();
  const weekly = db
    .prepare(
      `SELECT u.name, COUNT(*) AS c FROM progress p JOIN users u ON u.id = p.user_id
       WHERE p.completed_at >= ? GROUP BY p.user_id ORDER BY c DESC, u.name LIMIT 5`
    )
    .all(weekStart);

  const quotes = [
    "Beshikdan to qabrgacha ilm izlang. — Xalq maqoli",
    "Bilim — bu eng yaxshi boylik.",
    "Har kuni bir qadam bo'lsa ham, olg'a intiling.",
    "Mehnat qilgan — murodga yetadi.",
    "O'z ustida ishlash — eng katta sarmoya."
  ];
  const dayIndex = Math.floor(new Date(clock.day + "T00:00:00+05:00").getTime() / 86400000);
  const quote = quotes[((dayIndex % quotes.length) + quotes.length) % quotes.length];

  const nextCard = next
    ? `<a class="dash-hero-card" href="${
        next.type === "test" ? `/test/${next.id}` : `/lesson/${next.id}`
      }">
        <span class="dash-hero-ico"><svg viewBox="0 0 24 24"><path d="m9 7 8 5-8 5z"/></svg></span>
        <span class="dash-hero-copy">
          <small>${h(next.course_title)}</small>
          <b>${h(next.title)}</b>
          <span class="muted">${TYPE_LABEL[next.type] || next.type} | ${
        next.type === "test" ? `${Number(next.duration_min) || 30} daqiqa` : "dars"
      } | ${completed}/${total} tugatilgan</span>
        </span>
        <span class="dash-hero-go">&rarr;</span>
      </a>`
    : `<div class="dash-hero-card done"><span class="dash-hero-ico">âœ“</span><span class="dash-hero-copy"><b>Barcha darslar tugatilgan!</b><span class="muted">Tabriklaymiz, siz barcha materiallarni o'zlashtirdingiz.</span></span></div>`;

  const lessonCards = lessons
    .map((l, i) => {
      const isDone = done.has(l.id);
      const href = l.type === "test" ? `/test/${l.id}` : `/lesson/${l.id}`;
      const totalNotice = l.type === "test" ? "Test" : `${Number(l.duration_min) || 0} daq`;
      return `<a class="dl-card${isDone ? " done" : ""}" href="${href}" data-title="${h(
        (l.title + " " + l.course_title).toLowerCase()
      )}">
        <span class="dl-top">
          <span class="dl-ico">${isDone ? "&#10003;" : i + 1}</span>
          <span class="dl-status${isDone ? " done" : ""}">${isDone ? "Tugatildi" : l.type === "test" ? "Test" : "Ochish"}</span>
        </span>
        <span class="dl-module">${h(l.course_title)}</span>
        <b class="dl-title">${h(l.title)}</b>
        <span class="dl-sub">${h(l.course_title)}</span>
        <span class="dl-foot">
          <span class="dl-time">${totalNotice}</span>
          <span class="dl-arrow">&rarr;</span>
        </span>
      </a>`;
    })
    .join("");

  const weeklyRows = weekly.length
    ? weekly
        .map(
          (w, i) => `<div class="dash-rank-row">
            <span class="dash-rank-num">${i + 1}</span>
            <b>${h(w.name)}</b>
            <span class="muted">${w.c} dars</span>
          </div>`
        )
        .join("")
    : `<p class="muted small">Bu hafta hali hech kim dars tugatmadi. Birinchi bo'ling!</p>`;

  return `<section class="dash-hero">
    <div class="wrap">
      <span class="eyebrow">Xush kelibsiz</span>
      <h1>Salom, ${h(user.name.split(" ")[0])}!</h1>
      <p class="lead">O'rganishni davom eting va maqsadingizga erishing!</p>
      <div class="dash-quote">${h(quote)}</div>
    </div>
  </section>
  <section class="section tight">
    <div class="wrap">
      <div class="dash-top">
        <div class="dash-stat"><b>${todayDone}</b><span>Bugun tugatilgan</span></div>
        <div class="dash-stat"><b>${completed}/${total}</b><span>Darslar</span></div>
        <div class="dash-stat"><b>${pct}%</b><span>Kurs jarayoni</span></div>
        <div class="dash-stat"><b>${rank}</b><span>Reytingdagi o'rningiz</span></div>
        <div class="dash-stat"><b>${achievements}/4</b><span>Yutuqlar</span></div>
      </div>

      ${nextCard}

      <div class="dash-cols">
        <div class="card dash-rank">
          <div class="card-head"><h2>Haftalik reyting</h2><span class="badge">7 kun</span></div>
          ${weeklyRows}
        </div>
        <div class="card dash-ach">
          <div class="card-head"><h2>Yutuqlar</h2></div>
          <div class="dash-badges">
            <span class="dash-badge${completed >= 1 ? " on" : ""}">1 dars</span>
            <span class="dash-badge${completed >= 5 ? " on" : ""}">5 dars</span>
            <span class="dash-badge${completed >= 10 ? " on" : ""}">10 dars</span>
            <span class="dash-badge${completed >= 25 ? " on" : ""}">25 dars</span>
          </div>
          <div class="dash-ring" style="--p:${pct}">
            <span>${pct}%</span>
          </div>
          <p class="muted small center">Kurs jarayoni</p>
        </div>
      </div>

      <div class="card dash-all">
        <div class="card-head dash-all-head">
          <div><h2>Barcha darslar</h2><p class="muted small">${total} ta dars</p></div>
          <div class="dl-tools">
            <input id="dlSearch" class="dl-search" placeholder="Darslarni qidirish..." aria-label="Darslarni qidirish">
            <button type="button" class="dl-view active" data-view="grid" aria-label="Katak ko'rinishi">&#9638;</button>
            <button type="button" class="dl-view" data-view="list" aria-label="Ro'yxat ko'rinishi">&#9776;</button>
          </div>
        </div>
        <div class="dl-grid" id="dlGrid">${lessonCards || `<p class="muted">Hozircha darslar yo'q.</p>`}</div>
        <div class="dl-pager" id="dlPager"></div>
      </div>
      <script>
      (function () {
        var grid = document.getElementById('dlGrid');
        var pager = document.getElementById('dlPager');
        var search = document.getElementById('dlSearch');
        if (!grid || !pager) return;
        var cards = Array.prototype.slice.call(grid.children);
        var per = 6;
        var page = 1;
        function filtered() {
          var q = (search && search.value ? search.value : '').toLowerCase().trim();
          return cards.filter(function (c) {
            return !q || (c.dataset && c.dataset.title && c.dataset.title.indexOf(q) !== -1);
          });
        }
        function render() {
          var list = filtered();
          var pages = Math.max(1, Math.ceil(list.length / per));
          if (page > pages) page = pages;
          cards.forEach(function (c) { c.hidden = true; });
          list.slice((page - 1) * per, page * per).forEach(function (c) { c.hidden = false; });
          pager.innerHTML = '';
          function add(label, target, disabled, active) {
            var b = document.createElement('button');
            b.type = 'button';
            b.className = 'dl-page' + (active ? ' active' : '');
            b.textContent = label;
            b.disabled = !!disabled;
            b.addEventListener('click', function () { page = target; render(); });
            pager.appendChild(b);
          }
          add('Â«', 1, page === 1);
          add('‹', page - 1, page === 1);
          for (var i = 1; i <= pages; i += 1) add(String(i), i, false, i === page);
          add('›', page + 1, page === pages);
          add('Â»', pages, page === pages);
          var info = document.createElement('span');
          info.className = 'dl-pageinfo';
          info.textContent = 'Sahifa ' + page + ' / ' + pages + ' | ' + list.length + ' ta dars';
          pager.appendChild(info);
        }
        if (search) search.addEventListener('input', function () { page = 1; render(); });
        Array.prototype.forEach.call(document.querySelectorAll('.dl-view'), function (b) {
          b.addEventListener('click', function () {
            Array.prototype.forEach.call(document.querySelectorAll('.dl-view'), function (x) {
              x.classList.remove('active');
            });
            b.classList.add('active');
            grid.classList.toggle('list', b.getAttribute('data-view') === 'list');
          });
        });
        render();
      })();
      </script>
    </div>
  </section>`;
}

function duelDashboardPage(user) {
  if (!user) {
  return `<section class="duel-hero">
  <div class="wrap">
  <span class="eyebrow">1 vs 1</span>
  <h1>Duel   kim kuchli?</h1>
  <p class="lead">Do'stingiz bilan bir testda kuch sinashing. Kod yarating, do'stingiz qo'shilsin va eng ko'p to'g'ri javob bergan yutsin.</p>
  <div class="actions"><a class="btn btn-primary" href="/login?next=/duel">Kirish</a><a class="btn btn-ghost" href="/register?next=/duel">Ro'yxatdan o'tish</a></div>
  </div>
  </section>`;
  }

  const poolCount = db.prepare("SELECT COUNT(*) AS n FROM questions").get().n;

  const rows = db
.prepare(
  `SELECT d.*, COALESCE(NULLIF(d.title, ''), l.title) AS lesson_title,
  uc.name AS creator_name, uo.name AS opponent_name
  FROM duels d
  JOIN lessons l ON l.id = d.lesson_id
  JOIN users uc ON uc.id = d.creator_id
  LEFT JOIN users uo ON uo.id = d.opponent_id
  WHERE d.creator_id = ? OR d.opponent_id = ?
  ORDER BY d.id DESC LIMIT 40`
  )
.all(user.id, user.id);

  const active = rows.filter((d) => d.status !== "finished");
  const finished = rows.filter((d) => d.status === "finished");
  const tournament = ensureTournament();
  autoEnrollAll();
  const tourEntries = tournamentEntries(tournament.id);

  const activeCards = active.length
  ? active
.map((d) => {
  const opponent = d.creator_id === user.id ? d.opponent_name: d.creator_name;
  return `<a class="duel-card" href="/duel/${h(d.code)}">
  <div class="duel-card-head"><span class="duel-code-pill">${h(d.code)}</span><span class="badge">${
  d.status === "waiting" ? "Kutilmoqda": "Jonli"
  }</span></div>
  <h3>${h(d.lesson_title)}</h3>
  <p class="muted">${opponent ? `vs ${h(opponent)}`: "Raqib kutilmoqda"}</p>
  <span class="card-link">Xonaga kirish   </span>
  </a>`;
  })
.join("")
: `<div class="card empty">Hozircha faol duel yo'q. Yangi duel yarating.</div>`;

  const finishedRows = finished.length
  ? finished
.slice(0, 12)
.map((d) => {
  const plays = duelPlays(d.id);
  const mine = plays[user.id];
  const otherId = d.creator_id === user.id ? d.opponent_id: d.creator_id;
  const other = otherId ? plays[otherId]: null;
  let verdict = " ";
  if (mine && other) {
  if (mine.correct > other.correct) verdict = "G'alaba";
  else if (mine.correct < other.correct) verdict = "Mag'lubiyat";
  else if (mine.elapsed_ms < other.elapsed_ms) verdict = "G'alaba";
  else if (mine.elapsed_ms > other.elapsed_ms) verdict = "Mag'lubiyat";
  else verdict = "Durang";
  }
  return `<tr>
  <td><a href="/duel/${h(d.code)}"><b>${h(d.code)}</b></a></td>
  <td>${h(d.lesson_title)}</td>
  <td>${mine ? `${mine.correct}/${mine.total}`: " "}</td>
  <td><span class="duel-verdict ${verdict === "G'alaba" ? "win": verdict === "Mag'lubiyat" ? "lose": ""}">${verdict}</span></td>
  </tr>`;
  })
.join("")
: `<tr><td colspan="4" class="muted">Hozircha yakunlangan duel yo'q.</td></tr>`;

  return `<section class="duel-hero">
  <div class="wrap">
  <span class="eyebrow">1 vs 1</span>
  <h1>Duel   kim kuchli?</h1>
  <p class="lead">Test tanlang, kod yarating va do'stingizni chaqiring. Eng ko'p to'g'ri javob bergan   g'olib.</p>
  </div>
  </section>
  <section class="section tight">
  <div class="wrap">
  <div class="duel-actions">
  <div class="card duel-create">
  <h2>Yangi duel</h2>
  <p class="muted small">10 ta aralash savol. Barcha test va mavzulardan tasodifiy tanlanadi.</p>
  <form method="post" action="/duel/create" class="form">
  <div class="field"><div class="duel-pool">Savollar bazasi: <b>${poolCount}</b> ta · duelda <b>10</b> ta</div></div>
  <button class="btn btn-primary" type="submit" ${poolCount ? "": "disabled"}>Duel yaratish ⚔</button>
  </form>
  </div>
  <div class="card duel-join">
  <h2>Kod bilan kirish</h2>
  <p class="muted small">Do'stingiz bergan 6 xonali kodni kiriting.</p>
  <form method="post" action="/duel/join" class="form">
  <div class="field"><input name="code" maxlength="6" placeholder="A1B2C3" required style="text-transform:uppercase;letter-spacing:.18em;font-weight:700"></div>
  <button class="btn btn-ghost" type="submit">Qo'shilish</button>
  </form>
  </div>
  </div>

  <a class="tour-banner" href="/duel/tournament">
  <span class="tour-banner-ico">x </span>
  <span class="tour-banner-copy">
  <span class="eyebrow">Kunlik pley-off</span>
  <b>Kunlik duel   finalga qadar sxema</b>
  <small class="muted">Pley-off: ishtirokchilar ko'paysa 1/16, 1/32, 1/64 avtomatik qo'shiladi. Bugun ${tourEntries.length} ishtirokchi.</small>
  </span>
  <span class="tour-banner-arrow">Sxemani ko'rish   </span>
  </a>

  <div class="section-head" style="margin-top:34px"><h2>Faol duellar</h2><p class="muted">${active.length} ta</p></div>
  <div class="duel-list">${activeCards}</div>

  <div class="section-head" style="margin-top:34px"><h2>Duel tarixi</h2></div>
  <div class="card">
  <div class="table-wrap">
  <table>
  <thead><tr><th>Kod</th><th>Test</th><th>Natija</th><th>Holat</th></tr></thead>
  <tbody>${finishedRows}</tbody>
  </table>
  </div>
  </div>
  </div>
  </section>`;
}

function duelPlayPage(duel, lesson, questions) {
  const total = questions.length;
  const limit = Math.max(1, total) * 60;
  const slides = questions
.map(
  (q, i) => `<section class="q-slide${i === 0 ? " is-active": ""}" data-i="${i}">
  <div class="q-label">${i + 1}-savol</div>
  <h2 class="q-title">${h(q.text)}</h2>
  <div class="q-options">
  ${[1, 2, 3, 4]
.map(
  (n) => `<label class="q-opt">
  <input type="radio" name="q${q.id}" value="${n}">
  <span class="q-letter">${"ABCD"[n - 1]}</span>
  <span class="q-text">${h(q["o" + n])}</span>
  </label>`
  )
.join("")}
  </div>
  </section>`
  )
.join("");
  const hasPassage = !!String(lesson.content || "").trim();

  const body = `
  <header class="test-header">
  <a class="test-brand" href="/duel/${h(duel.code)}"><span class="mark">H</span><b>Duel</b></a>
  <div class="test-mid">
  <b>${h(lesson.title)}</b>
  <span id="qCounter">1 / ${total} savol</span>
  </div>
  <div class="test-tools">
  <span class="duel-live">a  1 vs 1</span>
  <a class="test-exit" href="/duel/${h(duel.code)}">Chiqish</a>
  <div class="test-timer" id="timer">--:--</div>
  </div>
  </header>
  <main class="test-main${hasPassage ? "": " single"}">
  ${hasPassage ? `<aside class="passage"><div class="passage-inner" id="passage">${nl2br(lesson.content)}</div></aside>`: ""}
  <section class="test-pane">
  <form method="post" action="/duel/${h(duel.code)}/submit" id="duelForm">
  <input type="hidden" name="duel_total" value="${total}">
  ${slides}
  <div class="test-nav">
  <button type="button" class="tbtn" id="prevBtn">  Oldingi</button>
  <div class="q-dots" id="dots"></div>
  <button type="button" class="tbtn primary" id="nextBtn">Keyingi   </button>
  <button type="submit" class="tbtn primary" id="finishBtn" hidden>Yakunlash</button>
  </div>
  </form>
  </section>
  </main>
  <script>
  (function () {
  var slides = Array.prototype.slice.call(document.querySelectorAll('.q-slide'));
  var counter = document.getElementById('qCounter');
  var prev = document.getElementById('prevBtn');
  var next = document.getElementById('nextBtn');
  var finish = document.getElementById('finishBtn');
  var form = document.getElementById('duelForm');
  var dots = document.getElementById('dots');
  var index = 0;
  slides.forEach(function (s, i) {
  var dot = document.createElement('span');
  dot.className = 'q-dot' + (i === 0 ? ' active': '');
  dots.appendChild(dot);
  });
  var dotEls = Array.prototype.slice.call(dots.children);
  function refresh() {
  counter.textContent = (index + 1) + ' / ' + slides.length + ' savol';
  prev.disabled = index === 0;
  next.hidden = index === slides.length - 1;
  finish.hidden = index !== slides.length - 1;
  dotEls.forEach(function (d, i) {
  d.classList.toggle('active', i === index);
  d.classList.toggle('answered', !!slides[i].querySelector('input:checked'));
  });
  }
  function show(nextIndex) {
  index = Math.max(0, Math.min(slides.length - 1, nextIndex));
  slides.forEach(function (s, i) { s.classList.toggle('is-active', i === index); });
  refresh();
  }
  prev.addEventListener('click', function () { show(index - 1); });
  next.addEventListener('click', function () { show(index + 1); });
  document.querySelectorAll('.q-opt input').forEach(function (input) {
  input.addEventListener('change', refresh);
  });
  form.addEventListener('submit', function (e) {
  var unanswered = slides.filter(function (s) { return !s.querySelector('input:checked'); }).length;
  if (unanswered && !confirm(unanswered + ' ta savol javobsiz. Baribir yakunlaysizmi?')) {
  e.preventDefault();
  }
  });
  var left = ${limit};
  var timer = document.getElementById('timer');
  function tick() {
  var m = Math.floor(left / 60);
  var s = left % 60;
  timer.textContent = String(m).padStart(2, '0') + ':' + String(s).padStart(2, '0');
  if (left <= 0) { form.submit(); return; }
  left -= 1;
  }
  tick();
  setInterval(tick, 1000);
  document.addEventListener('keydown', function (e) {
  if (e.key === 'ArrowRight') show(index + 1);
  if (e.key === 'ArrowLeft') show(index - 1);
  });
  })();
  </script>`;
  return testDocument({ title: `Duel   ${lesson.title}`, body });
}

function testDocument({ title, body }) {  return `<!DOCTYPE html>
<html lang="uz">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="theme-color" content="#f4f7fb">
<title>${h(title)}   ${h(config.siteName)}</title>
<link rel="icon" href="data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 32 32'%3E%3Crect width='32' height='32' rx='9' fill='%231e40af'/%3E%3Ctext x='16' y='22' font-family='Arial' font-size='18' font-weight='bold' text-anchor='middle' fill='white'%3EH%3C/text%3E%3C/svg%3E">
<script async src="https://telegram.org/js/telegram-web-app.js"></script>
<script>try{if(localStorage.getItem('ht_theme')==='light')document.documentElement.dataset.theme='light';}catch(e){}</script>
<link rel="stylesheet" href="/assets/platform.css?v=20261114h">
</head>
<body class="test-body">
${body}
</body>
</html>`;
}

function testPage(lesson, questions, testSections = []) {
  const duration = Number(lesson.duration_min || 30);
  const total = questions.length;

  const storedSections = (testSections || [])
.slice()
.sort((a, b) => (Number(a.position) || 0) - (Number(b.position) || 0) || a.id - b.id)
.map((s) => ({
  title: String(s.title || "").trim() || "Bo'lim",
  from: Math.max(1, Number(s.from_no) || 1),
  to: Number(s.to_no) > 0 ? Number(s.to_no): total,
  passage: String(s.passage || "")
  }))
.filter((s) => s.from <= Math.min(total, s.to));

  const sectionFor = (no) => storedSections.find((s) => no >= s.from && no <= Math.min(total, s.to));

  const lessonText = String(lesson.content || "").trim();
  const passages = questions.map((q, i) => {
  const own = String(q.passage || "").trim();
  if (own) return own;
  const section = sectionFor(i + 1);
  if (section && section.passage.trim()) return section.passage.trim();
  if (!storedSections.length && i < 15 && lessonText) return lessonText;
  return "";
  });
  const hasPassage = passages.some(Boolean);

  const slides = questions
.map(
  (q, i) => `<section class="q-slide${i === 0 ? " is-active": ""}" data-i="${i}">
  <div class="q-passage-data" hidden>${nl2br(passages[i])}</div>
  <div class="q-head">${i + 1}-savol</div>
  <h2 class="q-title">${h(q.text)}</h2>
  <div class="q-options">
  ${[1, 2, 3, 4]
.map(
  (n) => `<label class="q-opt">
  <input type="radio" name="q${q.id}" value="${n}">
  <span class="q-letter">${"ABCD"[n - 1]}</span>
  <span class="q-text">${h(q["o" + n])}</span>
  </label>`
  )
.join("")}
  </div>
  </section>`
  )
.join("");

  const sections = [];
  if (storedSections.length) {
  let cursor = 1;
  for (const s of storedSections) {
  const from = Math.max(cursor, s.from);
  const to = Math.min(total, s.to);
  if (from > cursor) sections.push({ title: "Savollar", from: cursor, to: from - 1 });
  if (to >= from) {
  sections.push({ title: s.title, from, to });
  cursor = to + 1;
  }
  if (cursor > total) break;
  }
  if (cursor <= total) sections.push({ title: "Savollar", from: cursor, to: total });
  } else if (total > 35) {
  sections.push({ title: "1-bosqich. Mutaxassislik fani", from: 1, to: 35 });
  sections.push({ title: "2-bosqich. Kasbiy Standartlar", from: 36, to: total });
  } else {
  sections.push({ title: "1-bosqich. Test savollari", from: 1, to: total });
  }

  const palette = sections
.map((section) => {
  const buttons = [];
  for (let n = section.from; n <= section.to; n += 1) {
  buttons.push(
  `<button type="button" class="pal${n === 1 ? " current": ""}" data-index="${n - 1}">${n}</button>`
  );
  }
  return `<div class="step-block">
  <div class="step-title">${h(section.title)}</div>
  <div class="palette">${buttons.join("")}</div>
  </div>`;
  })
.join("");

  const body = `
  <div class="solve" style="--fs:1;--fs-reading:1">
  <header class="solve-topbar">
  <div class="solve-inner">
  <a class="solve-brand" href="/courses"><span class="mark">H</span><b>${h(config.siteName)}</b></a>
  <div class="solve-head">
  <div class="solve-titles">
  <b>${h(lesson.title)}</b>
  <span id="qCounter">1 / ${total} savol</span>
  </div>
  ${
  hasPassage
  ? `<div class="fs-group">
  <span>MATN</span>
  <button type="button" data-fs="reading:-1" aria-label="Matn shriftini kichraytirish">A </button>
  <button type="button" class="fs-value" data-fs="reading:0" data-fs-value="reading">100%</button>
  <button type="button" data-fs="reading:1" aria-label="Matn shriftini kattalashtirish">A+</button>
  </div>`
: ""
  }
  <div class="fs-group">
  <span>SAVOL</span>
  <button type="button" data-fs="question:-1" aria-label="Savol shriftini kichraytirish">A </button>
  <button type="button" class="fs-value" data-fs="question:0" data-fs-value="question">100%</button>
  <button type="button" data-fs="question:1" aria-label="Savol shriftini kattalashtirish">A+</button>
  </div>
  <a class="solve-exit" href="${moduleHref(lesson)}">Saytga o'tish</a>
  </div>
  <div class="solve-right">
  <button type="button" class="solve-icon" id="fsToggle" aria-label="To'liq ekran">
  <svg viewBox="0 0 24 24"><path d="M8 3H3v5M16 3h5v5M8 21H3v-5M16 21h5v-5"/></svg>
  </button>
  <div class="solve-timer">
  <svg viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"/><path d="M12 7v5l3 2"/></svg>
  <span id="timer">--:--</span>
  </div>
  </div>
  </div>
  <div class="solve-progress"><span id="progressFill"></span></div>
  </header>

  <main class="solve-wrap">
  <div class="solve-stack">
  <form method="post" action="/test/${lesson.id}/submit" id="testForm">
  <div class="q-row${hasPassage ? "": " single"}">
  ${
  hasPassage
  ? `<aside class="q-reading-pane"><div class="q-reading" id="readingContent">${nl2br(
  passages[0] || ""
  )}</div></aside>
  <div class="q-resizer" id="qResizer" aria-hidden="true"><span></span></div>`
: ""
  }
  <section class="q-panel">${slides}</section>
  </div>

  <div class="q-nav-row">
  <button type="button" class="nav-pill" id="prevBtn">  Oldingi</button>
  <button type="button" class="nav-pill" id="nextBtn">Keyingi   </button>
  </div>

  <div class="aside-card">
  ${palette}
  <div class="solve-legend">
  <div class="legend-item done"><i></i> Javob berilgan (<span id="answeredCount">0</span>)</div>
  <div class="legend-item current"><i></i> Hozirgi savol</div>
  </div>
  <button type="button" class="btn-finish" id="finishBtn">Tugatish</button>
  </div>
  </form>
  </div>
  </main>

  <div class="solve-overlay" id="finishOverlay" hidden>
  <div class="solve-confirm">
  <div class="solve-warn">!</div>
  <p>Testni tugatishni tasdiqlaysizmi?</p>
  <p class="muted small" id="unansweredHint"></p>
  <div class="solve-confirm-actions">
  <button type="button" class="btn btn-ghost" id="cancelFinish">Bekor qilish</button>
  <button type="button" class="btn btn-primary" id="confirmFinish">Ha</button>
  </div>
  </div>
  </div>
  </div>

  <script>
  (function () {
  var solve = document.querySelector('.solve');
  var slides = Array.prototype.slice.call(document.querySelectorAll('.q-slide'));
  var counter = document.getElementById('qCounter');
  var prev = document.getElementById('prevBtn');
  var next = document.getElementById('nextBtn');
  var form = document.getElementById('testForm');
  var palette = Array.prototype.slice.call(document.querySelectorAll('.pal'));
  var answeredCount = document.getElementById('answeredCount');
  var progressFill = document.getElementById('progressFill');
  var overlay = document.getElementById('finishOverlay');
  var hint = document.getElementById('unansweredHint');
  var reading = document.getElementById('readingContent');
  var qRow = document.querySelector('.q-row');
  var index = 0;

  function answered() {
  return slides.filter(function (s) { return !!s.querySelector('input:checked'); }).length;
  }

  function refresh() {
  counter.textContent = (index + 1) + ' / ' + slides.length + ' savol';
  prev.disabled = index === 0;
  next.disabled = index === slides.length - 1;
  palette.forEach(function (btn, i) {
  btn.classList.toggle('current', i === index);
  btn.classList.toggle('done', !!slides[i].querySelector('input:checked'));
  });
  var count = answered();
  answeredCount.textContent = count;
  progressFill.style.width = (slides.length ? Math.round((count / slides.length) * 100): 0) + '%';
  if (hint) {
  var left = slides.length - count;
  hint.textContent = left ? left + ' ta savol javobsiz.': 'Barcha savollarga javob berilgan.';
  }
  }

  function syncReading(i) {
  if (!reading || !qRow) return;
  var src = slides[i] ? slides[i].querySelector('.q-passage-data'): null;
  var html = src ? src.innerHTML.trim(): '';
  qRow.classList.toggle('no-read', !html);
  if (html) {
  reading.innerHTML = html;
  reading.scrollTop = 0;
  }
  }

  function show(nextIndex) {
  index = Math.max(0, Math.min(slides.length - 1, nextIndex));
  slides.forEach(function (s, i) { s.classList.toggle('is-active', i === index); });
  var panel = document.querySelector('.q-panel');
  if (panel) panel.scrollTop = 0;
  syncReading(index);
  refresh();
  }

  prev.addEventListener('click', function () { show(index - 1); });
  next.addEventListener('click', function () { show(index + 1); });
  palette.forEach(function (btn) {
  btn.addEventListener('click', function () { show(Number(btn.getAttribute('data-index'))); });
  });

  document.querySelectorAll('.q-opt input').forEach(function (input) {
  input.addEventListener('change', function () {
  var slide = input.closest('.q-slide');
  slide.querySelectorAll('.q-opt').forEach(function (label) {
  label.classList.toggle('selected', !!label.querySelector('input:checked'));
  });
  refresh();
  });
  });

  document.getElementById('finishBtn').addEventListener('click', function () {
  refresh();
  overlay.hidden = false;
  });
  document.getElementById('cancelFinish').addEventListener('click', function () {
  overlay.hidden = true;
  });
  document.getElementById('confirmFinish').addEventListener('click', function () {
  form.submit();
  });

  var sizes = { reading: 100, question: 100 };
  function applySizes() {
  solve.style.setProperty('--fs-reading', sizes.reading / 100);
  solve.style.setProperty('--fs', sizes.question / 100);
  document.querySelectorAll('[data-fs-value]').forEach(function (el) {
  el.textContent = sizes[el.getAttribute('data-fs-value')] + '%';
  });
  }
  document.querySelectorAll('[data-fs]').forEach(function (btn) {
  btn.addEventListener('click', function () {
  var parts = btn.getAttribute('data-fs').split(':');
  var target = parts[0];
  var step = Number(parts[1]);
  sizes[target] = step === 0 ? 100: Math.max(80, Math.min(160, sizes[target] + step * 10));
  applySizes();
  });
  });

  var fsToggle = document.getElementById('fsToggle');
  fsToggle.addEventListener('click', function () {
  if (!document.fullscreenElement) {
  document.documentElement.requestFullscreen().catch(function () {});
  } else {
  document.exitFullscreen().catch(function () {});
  }
  });

  var resizer = document.getElementById('qResizer');
  var row = document.querySelector('.q-row');
  if (resizer && row) {
  resizer.addEventListener('pointerdown', function (event) {
  event.preventDefault();
  var rect = row.getBoundingClientRect();
  function move(e) {
  var pct = ((e.clientX - rect.left) / rect.width) * 100;
  pct = Math.max(30, Math.min(70, pct));
  row.style.setProperty('--split', pct + '%');
  }
  function up() {
  document.removeEventListener('pointermove', move);
  document.removeEventListener('pointerup', up);
  }
  document.addEventListener('pointermove', move);
  document.addEventListener('pointerup', up);
  });
  }

  var left = ${duration} * 60;
  var timer = document.getElementById('timer');
  function tick() {
  var h = Math.floor(left / 3600);
  var m = Math.floor((left % 3600) / 60);
  var s = left % 60;
  timer.textContent = [h, m, s].map(function (n) { return String(n).padStart(2, '0'); }).join(':');
  if (left <= 0) { form.submit(); return; }
  left -= 1;
  }
  tick();
  setInterval(tick, 1000);

  document.addEventListener('keydown', function (e) {
  if (e.key === 'ArrowRight') show(index + 1);
  if (e.key === 'ArrowLeft') show(index - 1);
  });

  syncReading(0);
  refresh();
  })();
  </script>`;

  return testDocument({ title: lesson.title, body });
}

function testResultPage(lesson, questions, score) {
  const total = questions.length;
  const correct = total ? Math.round((score / 100) * total): 0;
  const body = `
  <header class="test-header">
  <a class="test-brand" href="/courses"><span class="mark">H</span><b>${h(config.siteName)}</b></a>
  <div class="test-mid"><b>${h(lesson.title)}</b><span>Yakunlandi</span></div>
  <div class="test-tools"><a class="test-exit" href="${moduleHref(lesson)}">Saytga o'tish</a></div>
  </header>
  <main class="test-result">
  <div class="result-card">
  <span class="pill">Test yakunlandi</span>
  <div class="score-circle">${score}%</div>
  <h1>${score >= 60 ? "Yaxshi natija!": "Yana urinib ko'ring"}</h1>
  <p class="muted">${correct} / ${total} to'g'ri javob</p>
  <div class="actions">
  <a class="btn btn-primary" href="${moduleHref(lesson)}">Testlarga qaytish</a>
  <a class="btn btn-ghost" href="/test/${lesson.id}?start=1">Qayta topshirish</a>
  </div>
  </div>
  </main>`;
  return testDocument({ title: "Natija", body });
}

/* ================================================================ ROUTES */
const server = http.createServer(async (req, res) => {
  try {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  const p = decodeURIComponent(url.pathname);
  const method = req.method;

  const reqHost = String(req.headers.host || "").toLowerCase().split(":")[0];
  if (p === "/health") {
    res.writeHead(200, { "Content-Type": "text/plain; charset=utf-8", "Cache-Control": "no-store" });
    res.end("ok");
    return;
  }
  if (reqHost === "habibatecher.uz" || reqHost === "www.habibatecher.uz") {
    res.writeHead(301, { Location: `https://habibateacher.uz${p}${url.search}` });
    res.end();
    return;
  }
  const user = currentUser(req);
  const admin = isAdmin(req);
  res.lang = detectLang(req);

  /* Admin panelga tashqaridan har kirishda parol so'raladi */
  if (admin && method === "GET" && p.startsWith("/admin") && p !== "/admin/login" && p !== "/admin/logout") {
    let refPath = "";
    try {
      const ref = String(req.headers.referer || "");
      refPath = ref ? new URL(ref).pathname : "";
    } catch (e) {}
    if (!refPath.startsWith("/admin")) {
      const token = parseCookies(req).ht_admin;
      if (token) db.prepare("DELETE FROM admin_sessions WHERE token = ?").run(token);
      res.writeHead(303, {
        Location: `/admin/login?next=${encodeURIComponent(p + url.search)}`,
        "Set-Cookie": "ht_admin=; Path=/; HttpOnly; SameSite=Lax; Max-Age=0"
      });
      res.end();
      return;
    }
  }

  const isStatic =
  p.startsWith("/assets/") ||
  p.startsWith("/img/") ||
  p === "/favicon.ico" ||
  p === "/health" ||
  p === "/access" ||
  p.startsWith("/admin") ||
  p.startsWith("/lang/");

  /* ------------------------------------------------------------- assets */
  if (p === "/assets/platform.css") {
  const css = fs.readFileSync(path.join(PUBLIC_DIR, "platform.css"));
  res.writeHead(200, {
  "Content-Type": "text/css; charset=utf-8",
  "Cache-Control": "no-cache"
  });
  res.end(css);
  return;
  }

  /* ---------------------------------------------------------- static images */
  if (p.startsWith("/img/") && method === "GET") {
  const name = path.basename(p);
  const file = path.join(PUBLIC_DIR, "img", name);
  if (!fs.existsSync(file)) return notFound(res, null, false);
  const types = {
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".png": "image/png",
  ".webp": "image/webp",
  ".svg": "image/svg+xml",
  ".avif": "image/avif"
  };
  res.writeHead(200, {
  "Content-Type": types[path.extname(name).toLowerCase()] || "application/octet-stream",
  "Cache-Control": "public, max-age=86400"
  });
  fs.createReadStream(file).pipe(res);
  return;
  }

  /* ------------------------------------------------------------- language */
  const langMatch = p.match(/^\/lang\/(uz|ru|en)$/);
  if (langMatch && method === "GET") {
  let back = "/";
  const ref = req.headers.referer || "";
  if (ref) {
  try {
  const parsed = new URL(ref);
  back = parsed.pathname + parsed.search;
  } catch (e) {}
  }
  if (!back.startsWith("/") || back.startsWith("//")) back = "/";
  res.writeHead(303, {
  Location: back,
  "Set-Cookie": cookie("ht_lang", langMatch[1], 365 * 24 * 60 * 60, req)
  });
  res.end();
  return;
  }

  if (p === "/contract/accept" && method === "POST") {
  if (!user) return redirect(res, "/login");
  db.prepare("UPDATE users SET contract_accepted_at = ? WHERE id = ?").run(nowISO(), user.id);
  let back = "/courses";
  try {
  const ref = String(req.headers.referer || "");
  if (ref) {
  const refUrl = new URL(ref);
  if (refUrl.host === req.headers.host) back = refUrl.pathname + refUrl.search;
  }
  } catch (e) {}
  return redirect(res, back || "/courses");
  }

  /* --------------------------------------------------------------- likes */
  const likeMatch = p.match(/^\/like\/(\d+)(\/status)?$/);
  if (likeMatch) {
  const lessonId = Number(likeMatch[1]);
  const lesson = db.prepare("SELECT id, likes FROM lessons WHERE id = ?").get(lessonId);
  if (!lesson) {
  res.writeHead(404, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ ok: false }));
  return;
  }
  const wantsJson = String(req.headers.accept || "").includes("application/json");
  const liked = !!user && !!db.prepare("SELECT 1 FROM likes WHERE user_id = ? AND lesson_id = ?").get(user.id, lessonId);
  if (likeMatch[2] === "/status" && method === "GET") {
  res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ ok: true, liked, likes: Number(lesson.likes) || 0 }));
  return;
  }
  if (method === "POST") {
  if (!user) {
  if (wantsJson) {
  res.writeHead(401, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ ok: false, login: true }));
  } else {
  redirect(res, `/login?next=${encodeURIComponent(`/test/${lessonId}`)}`);
  }
  return;
  }
  let newLiked;
  if (liked) {
  db.prepare("DELETE FROM likes WHERE user_id = ? AND lesson_id = ?").run(user.id, lessonId);
  db.prepare("UPDATE lessons SET likes = MAX(0, likes - 1) WHERE id = ?").run(lessonId);
  newLiked = false;
  } else {
  db.prepare("INSERT OR IGNORE INTO likes (user_id, lesson_id, created_at) VALUES (?, ?, ?)").run(
  user.id,
  lessonId,
  nowISO()
  );
  db.prepare("UPDATE lessons SET likes = likes + 1 WHERE id = ?").run(lessonId);
  newLiked = true;
  }
  const fresh = db.prepare("SELECT likes FROM lessons WHERE id = ?").get(lessonId);
  if (wantsJson) {
  res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ ok: true, liked: newLiked, likes: Number(fresh.likes) || 0 }));
  } else {
  redirect(res, req.headers.referer || `/test/${lessonId}`);
  }
  return;
  }
  }

  /* ------------------------------------------------------------- access */
  if (p === "/access") {
  let accessFields = {};
  if (method === "POST") {
  try {
  accessFields = (await readForm(req)).fields || {};
  } catch (e) {
  accessFields = {};
  }
  }
  const next = safeNext(url.searchParams.get("next") || accessFields.next || "/");
  if (method === "GET") {
  const body = authCard(
  "Platformaga kirish",
  "Kirish kodini kiriting.",
  `<form method="post" action="/access" class="form">
  <input type="hidden" name="next" value="${h(next)}">
  <div class="field"><label>Kirish kodi</label><input name="code" type="password" inputmode="numeric" required autofocus placeholder=""></div>
  <button class="btn btn-primary" type="submit">Kirish</button>
  </form>`
  );
  send(res, 200, layout({ title: "Kirish kodi", body }));
  return;
  }
  if (method === "POST") {
  const ip = clientIp(req);
  const lock = lockedFor(ip);
  if (lock) {
  send(
  res,
  429,
  layout({
  title: "Kutish",
  body: alertBox(`Juda ko'p urinish. ${lock} soniyadan keyin qayta urinib ko'ring.`)
  })
  );
  return;
  }
  if (String(accessFields.code || "").trim() !== accessCode()) {
  noteFailure(ip);
  const body = authCard(
  "Platformaga kirish",
  "Kod noto'g'ri.",
  `${alertBox("Kirish kodi noto'g'ri.")}
  <form method="post" action="/access" class="form">
  <input type="hidden" name="next" value="${h(next)}">
  <div class="field"><label>Kirish kodi</label><input name="code" type="password" inputmode="numeric" required autofocus></div>
  <button class="btn btn-primary" type="submit">Kirish</button>
  </form>`
  );
  send(res, 401, layout({ title: "Kirish kodi", body }));
  return;
  }
  clearFailures(clientIp(req));
  res.writeHead(303, {
  Location: next || "/",
  "Set-Cookie": cookie("ht_access", accessToken(accessCode()), 365 * 24 * 60 * 60, req)
  });
  res.end();
  return;
  }
  }

  if (p === "/favicon.ico") {
  res.writeHead(204).end();
  return;
  }

  let form = { fields: {}, files: {} };
  if (method === "POST") {
  if (!sameOrigin(req)) {
  send(res, 403, layout({ title: "Taqiqlangan", body: `<div class="card">So'rov rad etildi.</div>`, user, admin }));
  return;
  }
  try {
  form = await readForm(req);
  } catch (e) {
  const msg = e.message === "too_large" ? "Fayl hajmi juda katta.": "Formani o'qishda xatolik.";
  send(res, 413, layout({ title: "Xatolik", body: alertBox(msg), user, admin }));
  return;
  }
  }

  const fields = form.fields;
  const files = form.files;

  /* --------------------------------------------------------------- home */
  if (p === "/" && method === "GET") {
  const stats = db
.prepare(
  `SELECT
  (SELECT COUNT(*) FROM users) AS users,
  (SELECT COUNT(*) FROM courses WHERE is_published = 1 AND is_test_group = 0) AS courses,
  (SELECT COUNT(*) FROM lessons) AS lessons,
  (SELECT COUNT(*) FROM progress) AS done`
  )
.get();

  const courses = db
.prepare(
  `SELECT c.*, (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id) AS lesson_count
  FROM courses c WHERE c.is_published = 1 AND c.is_test_group = 0 ORDER BY c.id DESC LIMIT 6`
  )
.all();

  const courseCards = courses.length
  ? courses.map((c) => publicCourseCard(c, user)).join("")
: `<div class="card empty" style="grid-column:1/-1">Kurslar tez orada qo'shiladi.</div>`;

  const body = `
  <section class="home-hero">
  <div class="wrap hero-grid">
  <div class="hero-copy">
  <span class="pill">Onlayn o'quv platformasi</span>
  <h1>Habiba teacher</h1>
  <p class="lead">Ingliz tili o'qituvchilari uchun atestatsiyaga tayyorlov: testlar, metodika, demo dars va portfolio.</p>
  <div class="actions">
  <a class="btn btn-primary" href="/register">Hoziroq boshlash</a>
  <a class="btn btn-ghost" href="${user ? "/courses": "/login"}">Platformadan foydalanish</a>
  </div>
  <div class="socials">
  <a href="${h(config.telegram || "#")}" target="_blank" rel="noopener">Telegram</a>
  <a href="tel:${h(String(config.phone || "").replace(/[^\d+]/g, ""))}">${h(config.phone || "")}</a>
  </div>
  </div>
  <div class="hero-art">
  <div class="hero-card hero-cta-card">
  <h2>Atestatsiyaga bugun tayyorlanishni boshlang</h2>
  <p>Ro'yxatdan o'ting yoki Telegram orqali bog'laning.</p>
  <div class="hero-cta-actions">
  <a class="btn btn-primary" href="/register">Ro'yxatdan o'tish</a>
  <a class="btn btn-ghost" href="${h(config.telegram || "#")}" target="_blank" rel="noopener">Telegram</a>
  </div>
  </div>
  </div>
  </div>
  <div class="wrap">
  <div class="hero-collage two">
  <figure class="hero-collage-main">
  <img src="/img/habiba-stage.jpg" alt="Habiba teacher sahnada">
  <figcaption>
  <span class="eyebrow">Habiba teacher</span>
  <b>Amaliyotchi o'qituvchi</b>
  <p>Har bir dars   hayotdagi haqiqiy vaziyatlar uchun.</p>
  </figcaption>
  </figure>
  <figure class="hero-collage-wide">
  <img src="/img/teachers-group.jpg" alt="Attestatsiyaga tayyorlanayotgan o'qituvchilar" loading="lazy">
  <figcaption>
  <b>Birgalikda   natijaga</b>
  </figcaption>
  </figure>
  </div>
  </div>
  </section>

  <section class="section tight">
  <div class="wrap">
  <div class="section-head center">
  <span class="eyebrow">Yo'nalishni tanlang</span>
  <h2>Yo'nalishni tanlang</h2>
  <p class="muted">Attestatsiya yoki TKT   o'zingizga kerakli yo'nalishdan boshlang.</p>
  </div>
  <div class="grid two directions">
  <a class="direction-card" href="/attestation">
  <span class="badge">Attestatsiya</span>
  <h3>Attestatsiya</h3>
  <p class="muted">Ingliz tili fani o'qituvchilari uchun testlar, metodika va demo dars.</p>
  <span class="card-link">Ochish   </span>
  </a>
  <a class="direction-card" href="/tkt">
  <span class="badge">TKT</span>
  <h3>TKT</h3>
  <p class="muted">Teaching Knowledge Test formatidagi metodika va sinf boshqaruvi testlari.</p>
  <span class="card-link">Ochish   </span>
  </a>
  </div>
  </div>
  </section>

  <section class="section" id="courses">
  <div class="wrap">
  <div class="section-head center">
  <span class="eyebrow">Kurslar</span>
  <h2>Barcha kurslar</h2>
  <p class="muted">Atestatsiyaga tayyorlov, metodika, demo dars va testlar   barchasi bir joyda.</p>
  </div>
  <div class="grid three">${courseCards}</div>
  <div class="center-actions"><a class="btn btn-ghost" href="/courses">Barcha kurslar</a></div>
  </div>
  </section>

  <section class="section about" id="about">
  <div class="wrap about-grid">
  <div>
  <span class="eyebrow">Biz haqimizda</span>
  <h2>O'qituvchilar uchun amaliy tayyorlov</h2>
  <p class="muted">Habiba teacher   ingliz tili fani o'qituvchilarini atestatsiyaga tayyorlaydigan onlayn platforma. Testlar, metodika, demo dars va portfolio bo'yicha tizimli materiallar.</p>
  <ul class="check-list">
  <li>Haqiqiy formatdagi mock testlar</li>
  <li>PDF darslik va qo'llanmalar</li>
  <li>Video tushuntirishlar</li>
  <li>Progress va natijalar nazorati</li>
  </ul>
  </div>
  <div class="about-art">
  <div class="about-mark">H</div>
  <b>Bilim   amaliyotda kuch.</b>
  <p>Har bir dars sinfdagi haqiqiy vaziyatlarga moslashtirilgan.</p>
  </div>
  </div>
  </section>

  <section class="stats-band">
  <div class="wrap stats">
  <div class="stat"><b>${stats.users}</b><span>O'quvchilar</span></div>
  <div class="stat"><b>${stats.courses}</b><span>Kurslar</span></div>
  <div class="stat"><b>${stats.lessons}</b><span>Darslar</span></div>
  <div class="stat"><b>${stats.done}</b><span>Tugatilgan darslar</span></div>
  </div>
  </section>

  <section class="section">
  <div class="wrap">
  <div class="section-head center">
  <span class="eyebrow">Nega biz</span>
  <h2>Natijaga olib boradigan tayyorlov</h2>
  </div>
  <div class="grid three">
  <div class="card"><div class="ico">${icon("book")}</div><h3>PDF materiallar</h3><p class="muted">Darslik va qo'llanmalarni platformadan ochish yoki yuklab olish.</p></div>
  <div class="card"><div class="ico">${icon("play")}</div><h3>Video darslar</h3><p class="muted">Trener tushuntirishlari va amaliy namunalar.</p></div>
  <div class="card"><div class="ico">${icon("quiz")}</div><h3>Mock testlar</h3><p class="muted">Haqiqiy formatdagi testlar, natija va tahlil.</p></div>
  </div>
  </div>
  </section>`;

  send(res, 200, layout({ title: "Bosh sahifa", body, user, admin }));
  return;
  }

  /* ------------------------------------------------------------- signup */
  if (p === "/register") {
  if (user) return redirect(res, "/courses");

  if (method === "GET") {
  const next = safeNext(url.searchParams.get("next"));
  const body = authCard(
  "Ro'yxatdan o'tish",
  "Ism, telefon va parolni kiriting.",
  `<form method="post" action="/register" class="form">
  ${next ? `<input type="hidden" name="next" value="${h(next)}">`: ""}
  <input type="hidden" name="tg_init_data" value="">
  <div class="field"><label>Ismingiz</label><input name="name" required maxlength="60" placeholder="Habiba"></div>
  <div class="field"><label>Telegram ID</label><input name="telegram_id" required inputmode="numeric" placeholder="Masalan: 1097025987"><small class="muted">Botga <b>/myid</b> yozib ID oling. Bir ID   bitta akkaunt.</small></div>
  <div class="field"><label>Telefon</label><input name="phone" data-phone required inputmode="tel" placeholder="+998 93 568 00 91"></div>
  <div class="field"><label>Parol</label><input name="password" type="password" required minlength="6" placeholder="Kamida 6 belgi"></div>
  <button class="btn btn-primary" type="submit">Ro'yxatdan o'tish</button>
  </form>`,
  `<p class="alt">Akkountingiz bormi? <a href="/login${next ? `?next=${encodeURIComponent(next)}`: ""}">Kirish</a></p>`,
  "/"
  );
  send(res, 200, layout({ title: "Ro'yxatdan o'tish", body }));
  return;
  }

  const next = safeNext(fields.next || url.searchParams.get("next"));
  const name = String(fields.name || "").trim();
  const phone = normalizePhone(fields.phone);
  const password = String(fields.password || "");
  const tgUser = telegramUserFromInitData(fields.tg_init_data);
  const telegramId = String((tgUser && tgUser.id) || fields.telegram_id || "").replace(/\D/g, "");

  let error = "";
  if (!/^[\p{L}\s'-]{2,}$/u.test(name)) error = "Ism faqat harflardan iborat bo'lishi kerak.";
  else if (!validPhone(phone)) error = "Telefon +998 bilan boshlanishi va 9 ta raqamdan iborat bo'lishi kerak.";
  else if (password.length < 6) error = "Parol kamida 6 belgi bo'lishi kerak.";
  else if (!/^\d{5,15}$/.test(telegramId)) error = "Telegram ID kiriting. Botga /myid yozib oling.";
  else if (db.prepare("SELECT 1 FROM users WHERE telegram_id = ?").get(telegramId))
  error = "Bu Telegram ID allaqachon ro'yxatdan o'tgan. Bir ID   bitta akkaunt.";
  else if (db.prepare("SELECT 1 FROM users WHERE phone = ?").get(phone))
  error = "Bu telefon raqam allaqachon ro'yxatdan o'tgan.";

  if (error) {
  const body = authCard(
  "Ro'yxatdan o'tish",
  "Ism, Telegram ID, telefon va parolni kiriting.",
  `${alertBox(error)}
  <form method="post" action="/register" class="form">
  ${next ? `<input type="hidden" name="next" value="${h(next)}">`: ""}
  <input type="hidden" name="tg_init_data" value="">
  <div class="field"><label>Ismingiz</label><input name="name" value="${h(name)}" required></div>
  <div class="field"><label>Telegram ID</label><input name="telegram_id" value="${h(telegramId)}" required inputmode="numeric"></div>
  <div class="field"><label>Telefon</label><input name="phone" data-phone value="${h(fields.phone || "")}" required></div>
  <div class="field"><label>Parol</label><input name="password" type="password" required minlength="6"></div>
  <button class="btn btn-primary" type="submit">Ro'yxatdan o'tish</button>
  </form>`,
  `<p class="alt">Akkountingiz bormi? <a href="/login${next ? `?next=${encodeURIComponent(next)}`: ""}">Kirish</a></p>`,
  "/"
  );
  send(res, 400, layout({ title: "Ro'yxatdan o'tish", body }));
  return;
  }

  const info = db
.prepare("INSERT INTO users (name, phone, pass, telegram_id, created_at) VALUES (?, ?, ?, ?, ?)")
.run(name, phone, hashPassword(password), telegramId, nowISO());
  createUserSession(res, Number(info.lastInsertRowid), req);
  createDeviceSession(res, Number(info.lastInsertRowid), req);
  notifyTelegram(
    `<b>Yangi ro'yxatdan o'tish</b>\nIsm: ${h(name)}\nTelefon: ${h(phone)}\nTelegram ID: ${h(
      telegramId
    )}\nVaqt: ${new Date().toLocaleString("uz-UZ")}`
  ).catch(() => {});
  redirect(res, next || "/dashboard");
  return;
  }

  /* -------------------------------------------------------------- login */
  if (p === "/login/start" && method === "POST") {
  const startNext = safeNext(fields.next || url.searchParams.get("next"));
  const startNextJoin = startNext ? `&next=${encodeURIComponent(startNext)}` : "";
  const phone = normalizePhone(fields.phone);
  const userRow = db.prepare("SELECT id, telegram_id FROM users WHERE phone = ?").get(phone);
  if (!userRow) {
  return redirect(res, `/login?err=notfound&phone=${encodeURIComponent(phone)}${startNextJoin}`);
  }
  if (!userRow.telegram_id) {
  return redirect(res, `/login?err=notelegram&phone=${encodeURIComponent(phone)}${startNextJoin}`);
  }
  const ip = clientIp(req);
  const lock = lockedFor(ip);
  if (lock) {
  return redirect(res, `/login?step=3&phone=${encodeURIComponent(phone)}${startNextJoin}&err=blocked`);
  }
  const code = String(randomInt(100000, 1000000));
  db.prepare(
  `INSERT INTO login_codes (phone, code_hash, expires_at, attempts, created_at)
  VALUES (?, ?, ?, 0, ?)
  ON CONFLICT(phone) DO UPDATE SET code_hash = excluded.code_hash, expires_at = excluded.expires_at, attempts = 0, created_at = excluded.created_at`
  ).run(phone, loginCodeHash(phone, code), Date.now() + 5 * 60 * 1000, nowISO());
  await telegramApi("sendMessage", {
  chat_id: userRow.telegram_id,
  text: `<b>Kirish kodi</b>\n\n<code>${code}</code>\n\nKod 5 daqiqa amal qiladi. Nusxalash uchun kodni bosing.`,
  parse_mode: "HTML",
  reply_markup: { inline_keyboard: [[{ text: "Nusxalash", copy_text: { text: code } }]] }
  });
  return redirect(res, `/login?step=2&phone=${encodeURIComponent(phone)}${startNextJoin}`);
  }

  if (p === "/login/verify" && method === "POST") {
  const verifyNext = safeNext(fields.next);
  const verifyNextJoin = verifyNext ? `&next=${encodeURIComponent(verifyNext)}` : "";
  const phone = normalizePhone(fields.phone);
  const code = String(fields.code || "").replace(/\D/g, "");
  const back = `/login?step=3&phone=${encodeURIComponent(phone)}${verifyNextJoin}`;
  const row = db.prepare("SELECT * FROM login_codes WHERE phone = ?").get(phone);
  if (!row || row.expires_at < Date.now()) {
  if (row) db.prepare("DELETE FROM login_codes WHERE phone = ?").run(phone);
  return redirect(res, `${back}&err=expired`);
  }
  if (row.attempts >= 5) {
  db.prepare("DELETE FROM login_codes WHERE phone = ?").run(phone);
  return redirect(res, `${back}&err=blocked`);
  }
  if (!/^\d{6}$/.test(code) || loginCodeHash(phone, code) !== row.code_hash) {
  db.prepare("UPDATE login_codes SET attempts = attempts + 1 WHERE phone = ?").run(phone);
  return redirect(res, `${back}&err=wrong`);
  }
  db.prepare("DELETE FROM login_codes WHERE phone = ?").run(phone);
  const userRow = db.prepare("SELECT id FROM users WHERE phone = ?").get(phone);
  if (!userRow) return redirect(res, "/login?err=notfound");
  clearFailures(clientIp(req));
  createUserSession(res, userRow.id, req);
  createDeviceSession(res, userRow.id, req);
  return redirect(res, verifyNext || "/dashboard");
  }

  if (p === "/login") {
  const pageNext = safeNext(url.searchParams.get("next"));
  if (!user) {
    const deviceToken = parseCookies(req).ht_device;
    if (deviceToken) {
      const deviceUser = db
        .prepare("SELECT u.id FROM device_sessions d JOIN users u ON u.id = d.user_id WHERE d.token = ?")
        .get(deviceToken);
      if (deviceUser) {
        db.prepare("UPDATE device_sessions SET last_seen = ? WHERE token = ?").run(nowISO(), deviceToken);
        createUserSession(res, deviceUser.id, req);
        return redirect(res, pageNext || "/dashboard");
      }
    }
  }
  if (user) return redirect(res, pageNext || "/courses");

  if (method === "GET") {
  const step = Math.min(3, Math.max(1, Number(url.searchParams.get("step")) || 1));
  const phoneRaw = String(url.searchParams.get("phone") || "");
  const err = String(url.searchParams.get("err") || "");
  const pwMode = url.searchParams.get("pw") === "1";
  const nextQs = pageNext ? `?next=${encodeURIComponent(pageNext)}` : "";
  const nextJoin = pageNext ? `&next=${encodeURIComponent(pageNext)}` : "";
  const nextHidden = pageNext ? `<input type="hidden" name="next" value="${h(pageNext)}">` : "";
  const steps = `
  <div class="login-steps">
  <a class="login-step${step === 1 ? " active" : ""}" href="/login${nextQs}">
  <span class="login-step-ico"><svg viewBox="0 0 24 24"><path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5L17 13l4 1.5v3A2.5 2.5 0 0 1 18.5 20 15.5 15.5 0 0 1 4 5.5 2.5 2.5 0 0 1 6.5 3Z"/></svg></span>
  <b>Telefon</b>
  </a>
  <span class="login-step${step === 2 ? " active" : ""}">
  <span class="login-step-ico"><svg viewBox="0 0 24 24"><path d="M21 4 3 11l5 2 2 6 3-4 5 3z"/></svg></span>
  <b>Telegram</b>
  </span>
  <span class="login-step${step === 3 ? " active" : ""}">
  <span class="login-step-ico"><svg viewBox="0 0 24 24"><circle cx="8" cy="15" r="4"/><path d="m11 12 8-8M16 7l3 3"/></svg></span>
  <b>Kod</b>
  </span>
  </div>`;

  let stepHtml = "";
  if (step === 1) {
  stepHtml = `
  <h1 class="login-title">Kirish</h1>
  <p class="login-sub">Telefon raqamingizni kiriting</p>
  ${err === "notfound" ? alertBox("Bu raqam ro'yxatdan o'tmagan.", "error") : ""}
  ${err === "notelegram" ? alertBox("Bu akkauntga Telegram bog'lanmagan. Parol bilan kiring.", "error") : ""}
  ${pwMode ? `
  <form method="post" action="/login" class="login-form">
  ${nextHidden}
  <div class="phone-wrap">
  <span class="phone-ico"><svg viewBox="0 0 24 24"><path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5L17 13l4 1.5v3A2.5 2.5 0 0 1 18.5 20 15.5 15.5 0 0 1 4 5.5 2.5 2.5 0 0 1 6.5 3Z"/></svg></span>
  <span class="phone-prefix">+998</span><input id="phoneInput" name="phone" value="${h(phoneRaw)}" required inputmode="numeric" maxlength="12" placeholder="90 123 45 67" autocomplete="tel">
  </div>
  <div class="field"><label>Parol</label><input name="password" type="password" required autocomplete="current-password"></div>
  <button class="btn-continue" type="submit">Kirish <span>&rarr;</span></button>
  </form>
  ` : `
  <form method="post" action="/login/start" class="login-form">
  ${nextHidden}
  <div class="phone-wrap">
  <span class="phone-ico"><svg viewBox="0 0 24 24"><path d="M6.5 3h3l1.5 4-2 1.5a12 12 0 0 0 6.5 6.5L17 13l4 1.5v3A2.5 2.5 0 0 1 18.5 20 15.5 15.5 0 0 1 4 5.5 2.5 2.5 0 0 1 6.5 3Z"/></svg></span>
  <span class="phone-prefix">+998</span><input id="phoneInput" name="phone" value="${h(phoneRaw)}" required inputmode="numeric" maxlength="12" placeholder="90 123 45 67" autocomplete="tel">
  </div>
  <button class="btn-continue" type="submit">Davom etish <span>&rarr;</span></button>
  </form>
  `}
  <script>
  (function () {
  var el = document.getElementById('phoneInput');
  if (!el || el.dataset.bound) return;
  el.dataset.bound = '1';
  el.addEventListener('input', function () {
  var d = el.value.replace(/\\D/g, '');
  if (d.indexOf('998') === 0) d = d.slice(3);
  d = d.slice(0, 9);
  var out = '';
  if (d.length) out += d.slice(0, 2);
  if (d.length > 2) out += ' ' + d.slice(2, 5);
  if (d.length > 5) out += ' ' + d.slice(5, 7);
  if (d.length > 7) out += ' ' + d.slice(7, 9);
  el.value = out;
  });
  })();
  </script>`;
  } else if (step === 2) {
  stepHtml = `
  <h1 class="login-title">Botga kelgan kodni kiriting</h1>
  <p class="login-sub"><b>${h(phoneRaw)}</b> raqamiga bog'langan Telegram botga 6 xonali kod yuborildi. Kodni nusxalab, keyingi qadamda kiriting.</p>
  <a class="btn-continue" href="/login?step=3&phone=${encodeURIComponent(phoneRaw)}${nextJoin}">Kodni kiritish &rarr;</a>
  <a class="login-next" href="https://t.me/HabibateacherBot" target="_blank" rel="noopener">Botni ochish</a>
  <form method="post" action="/login/start" class="login-resend">
  <input type="hidden" name="phone" value="${h(phoneRaw)}">
  ${nextHidden}
  <button class="link" type="submit">Kodni qayta yuborish</button>
  </form>`;
  } else {
  stepHtml = `
  <h1 class="login-title">Kodni kiriting</h1>
  <p class="login-sub">Telegramdan kelgan 6 xonali kod</p>
  ${err === "wrong" ? alertBox("Kod noto'g'ri. Qayta urinib ko'ring.", "error") : ""}
  ${err === "expired" ? alertBox("Kod muddati tugagan. Qayta yuboring.", "error") : ""}
  ${err === "blocked" ? alertBox("Juda ko'p urinish. Yangi kod oling.", "error") : ""}
  <form method="post" action="/login/verify" class="login-form">
  <input type="hidden" name="phone" value="${h(phoneRaw)}">
  ${nextHidden}
  <div class="field"><input name="code" inputmode="numeric" pattern="[0-9]{6}" maxlength="6" placeholder="123456" required autocomplete="one-time-code" class="code-input"></div>
  <button class="btn-continue" type="submit">Kirish <span>&rarr;</span></button>
  </form>
  <form method="post" action="/login/start" class="login-resend">
  <input type="hidden" name="phone" value="${h(phoneRaw)}">
  ${nextHidden}
  <button class="link" type="submit">Kodni qayta yuborish</button>
  </form>`;
  }

  const body = `
  <section class="login-modern">
  <div class="login-card">
  ${steps}
  ${stepHtml}
  <p class="login-terms">Davom etish orqali <a href="/plans">foydalanish shartlariga</a> rozilik bildirasiz</p>
  <p class="login-reg">Akkountingiz yo'qmi? <a href="/register${nextQs}">Ro'yxatdan o'tish</a></p>
  <div class="login-admin"><span>Admin sifatida kirish?</span> <a href="/admin/login">Admin panel</a></div>
  </div>
  </section>`;
  send(res, 200, layout({ title: "Kirish", body }));
  return;
  }

  const next = safeNext(fields.next || url.searchParams.get("next"));

  const ip = clientIp(req);
  const lock = lockedFor(ip);
  if (lock) {
  send(res, 429, layout({ title: "Kutish", body: alertBox(`Juda ko'p urinish. ${lock} soniyadan keyin qayta urinib ko'ring.`) }));
  return;
  }

  const phone = normalizePhone(fields.phone);
  const password = String(fields.password || "");
  const row = db.prepare("SELECT * FROM users WHERE phone = ?").get(phone);

  if (!row || !verifyPassword(password, row.pass)) {
  noteFailure(ip);
  const body = authCard(
  "Kirish",
  "Telefon va parolingizni kiriting.",
  `${alertBox("Telefon yoki parol noto'g'ri.")}
  <form method="post" action="/login" class="form">
  ${next ? `<input type="hidden" name="next" value="${h(next)}">`: ""}
  <input type="hidden" name="tg_init_data" value="">
  <div class="field"><label>Telefon</label><input name="phone" data-phone value="${h(fields.phone || "")}" required></div>
  <div class="field"><label>Parol</label><input name="password" type="password" required></div>
  <button class="btn btn-primary" type="submit">Kirish</button>
  </form>`,
  `<p class="alt">Akkountingiz yo'qmi? <a href="/register${next ? `?next=${encodeURIComponent(next)}`: ""}">Ro'yxatdan o'tish</a></p>`,
  "/"
  );
  send(res, 401, layout({ title: "Kirish", body }));
  return;
  }

  const tgUser = telegramUserFromInitData(fields.tg_init_data);
  if (tgUser && tgUser.id) {
  const telegramId = String(tgUser.id);
  if (row.telegram_id && String(row.telegram_id) !== telegramId) {
  send(
  res,
  403,
  layout({
  title: "Kirish",
  body: authCard(
  "Kirish",
  "Telegram ID mos kelmadi.",
  `${alertBox("Bu akkaunt boshqa Telegram ID ga bog'langan.")}<a class="btn btn-primary" href="/login">Qayta kirish</a>`
  )
  })
  );
  return;
  }
  if (!row.telegram_id) {
  const taken = db.prepare("SELECT 1 FROM users WHERE telegram_id = ? AND id != ?").get(telegramId, row.id);
  if (taken) {
  send(
  res,
  403,
  layout({
  title: "Kirish",
  body: authCard(
  "Kirish",
  "Telegram ID band.",
  `${alertBox("Bu Telegram ID boshqa akkauntga bog'langan. Bir ID   bitta akkaunt.")}<a class="btn btn-primary" href="/login">Qayta kirish</a>`
  )
  })
  );
  return;
  }
  db.prepare("UPDATE users SET telegram_id = ? WHERE id = ?").run(telegramId, row.id);
  row.telegram_id = telegramId;
  }
  }

  clearFailures(ip);
  createUserSession(res, row.id, req);
  createDeviceSession(res, row.id, req);
  redirect(res, next || "/dashboard");
  return;
  }

  if (p === "/logout" && method === "POST") {
  const token = parseCookies(req).ht_session;
  const deviceToken = parseCookies(req).ht_device;
  if (token) db.prepare("DELETE FROM sessions WHERE token = ?").run(token);
  if (deviceToken) db.prepare("DELETE FROM device_sessions WHERE token = ?").run(deviceToken);
  clearCookie(res, "ht_session");
  clearCookie(res, "ht_device");
  redirect(res, "/");
  return;
  }

  /* ------------------------------------------------------------ courses */
  if (p === "/courses" && method === "GET") {
  if (!user) {
  const courses = db
.prepare(
  `SELECT c.*, (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id) AS lesson_count
  FROM courses c WHERE c.is_published = 1 AND c.is_test_group = 0 ORDER BY c.id DESC`
  )
.all();
  const cards = courses.length
  ? courses.map((c) => publicCourseCard(c, null)).join("")
: `<div class="card empty" style="grid-column:1/-1">Kurslar tez orada qo'shiladi.</div>`;
  const body = `
  <section class="page-hero center">
  <span class="eyebrow">Katalog</span>
  <h1>Kurslar</h1>
  <p class="lead">Atestatsiyaga tayyorlov kurslari. Kursni ochish uchun tizimga kiring.</p>
  </section>
  <section class="section tight">
  <div class="wrap">
  <div class="grid three">${cards}</div>
  <div class="center-actions"><a class="btn btn-primary" href="/register">Ro'yxatdan o'tish</a></div>
  </div>
  </section>`;
  send(res, 200, layout({ title: "Kurslar", body, user, admin }));
  return;
  }

  const courses = db
.prepare(
  `SELECT c.*,
  (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id) AS lesson_count,
  (SELECT COUNT(*) FROM progress pr JOIN lessons l ON l.id = pr.lesson_id
  WHERE l.course_id = c.id AND pr.user_id = ?) AS done_count
  FROM courses c WHERE c.is_published = 1 AND c.is_test_group = 0 ORDER BY c.id DESC`
  )
.all(user.id);

  const cards = courses.length
  ? courses
.map((c) => {
  const percent = c.lesson_count ? Math.round((c.done_count / c.lesson_count) * 100): 0;
  return `<a class="card course-card" href="/course/${c.id}">
  <div class="course-ico">${icon("layers")}</div>
  <h3>${h(c.title)}</h3>
  <p class="muted">${h(c.description || "Kurs tavsifi yo'q")}</p>
  <div class="progress"><span style="width:${percent}%"></span></div>
  <div class="progress-meta"><span>${c.done_count}/${c.lesson_count} dars</span><span>${percent}%</span></div>
  </a>`;
  })
.join("")
: `<div class="card empty">Hozircha kurslar yo'q. Tez orada qo'shiladi.</div>`;

  const body = `
  <div class="page-head">
  <div><h1>Kurslar</h1><p class="muted">Salom, ${h(user.name)}! O'zingizga kerakli kursni tanlang.</p></div>
  </div>
  <div class="grid three">${cards}</div>`;
  send(res, 200, layout({ title: "Kurslar", body, user, admin }));
  return;
  }

  /* -------------------------------------------------------------- plans */
  if (p === "/plans" && method === "GET") {
  const body = `
  <section class="page-hero center">
  <span class="eyebrow">Tariflar</span>
  <h1>Tariflar</h1>
  <p class="lead">Bitta to'lov bilan barcha kurs va materiallarga kirish.</p>
  </section>
  <section class="section tight">
  <div class="wrap plans-wrap">
  <div class="plan-card">
  <span class="plan-badge">Tavsiya etiladi</span>
  <h2>To'liq kirish</h2>
  <p class="muted">Barcha kurslar, PDF materiallar, testlar va yangilanishlar.</p>
  <div class="plan-price"><s>399 000 so'm</s><b>299 000 so'm</b><span>/ 3 oy</span></div>
  <ul class="check-list">
  <li>Barcha kurslarga kirish</li>
  <li>PDF darslik va qo'llanmalar</li>
  <li>Mock testlar va natijalar</li>
  <li>Yangi materiallar bepul</li>
  </ul>
  <a class="btn btn-orange" href="${h(config.telegram || "#")}" target="_blank" rel="noopener">Sotib olish</a>
  </div>
  <p class="muted small center">To'lov Telegram orqali amalga oshiriladi. Savollar uchun: ${h(config.phone || "")}</p>
  </div>
  </section>`;
  send(res, 200, layout({ title: "Tariflar", body, user, admin }));
  return;
  }

  /* ---------------------------------------------------------- categories */
  if ((p === "/attestation" || p === "/tkt") && method === "GET") {
  const cat = p.slice(1);
  const meta =
  cat === "attestation"
  ? {
  h1: "Attestatsiya",
  title: "Attestatsiya testlari",
  lead: "O'qituvchilar uchun toifa attestatsiyasiga tayyorgarlik   sinov testlari, natijalar va javoblar."
  }
: {
  h1: "TKT",
  title: "TKT testlari",
  lead: "Teaching Knowledge Test (TKT) uchun tayyorgarlik   imtihon uslubidagi modul sinov testlari."
  };

  const courses = db
.prepare(
  `SELECT c.*, (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id) AS lesson_count
  FROM courses c WHERE c.category = ? AND c.is_published = 1 ORDER BY c.id`
  )
.all(cat);

  const tests = db
.prepare(
  `SELECT l.*, c.title AS course_title,
  (SELECT COUNT(*) FROM questions q WHERE q.lesson_id = l.id) AS qcount
  FROM lessons l JOIN courses c ON c.id = l.course_id
  WHERE l.type = 'test' AND c.category = ? AND c.is_published = 1
  ORDER BY l.course_id, l.position, l.id`
  )
.all(cat);

  const ownedIds = new Set(
  user
  ? db
.prepare("SELECT lesson_id FROM purchases WHERE user_id = ?")
.all(user.id)
.map((r) => r.lesson_id)
: []
  );

  const byCourse = new Map();
  for (const test of tests) {
  if (!byCourse.has(test.course_id)) byCourse.set(test.course_id, []);
  byCourse.get(test.course_id).push(test);
  }

  const sections = courses
.map((course) => {
  const list = byCourse.get(course.id) || [];
  if (!list.length) return "";
  const hasPaid = list.some((t) => Number(t.price) > 0);
  const addCard = admin
  ? `<a class="test-card test-add" href="/admin/course/${course.id}#new-lesson">
  <span class="test-add-plus">+</span>
  <b>Yangi test qo'shish</b>
  <small>${h(course.title)} guruhiga</small>
  </a>`
: "";
  return `<section class="test-group">
  <div class="test-group-head">
  <div>
  <h2>${h(course.title)}</h2>
  </div>
  </div>
  ${
  hasPaid && list.length > 1
  ? `<div class="plan-banner">
  <div>
  <b>Bu testlarni birma-bir sotib olish shart emas</b>
  <p class="muted">Bitta tarif bilan barcha pullik testlarni oching   ancha tejamkor.</p>
  </div>
  <a class="btn btn-ghost btn-sm" href="/plans">Tarifni ko'rish   </a>
  </div>`
: ""
  }
  <div class="grid test-grid">${list.map((t) => testCard(t, ownedIds.has(t.id))).join("")}${addCard}</div>
  </section>`;
  })
.filter(Boolean)
.join("");

  const body = `
  <section class="page-hero">
  <a class="back" href="/">  Barcha yo'nalishlar</a>
  <h1>${h(meta.h1)}</h1>
  <p class="lead">${h(meta.lead)}</p>
  </section>
  <section class="section tight">
  <div class="wrap">
  <div class="tests-head">
  <span class="eyebrow">O'qituvchlar uchun mock testlar</span>
  <h2>${h(meta.title)}</h2>
  </div>
  ${sections || `<div class="card empty">Bu yo'nalishda testlar tez orada qo'shiladi.</div>`}
  </div>
  </section>`;
  send(res, 200, layout({ title: meta.title, body, user, admin }));
  return;
  }

  /* --------------------------------------------------------- leaderboard */
  if (p === "/leaderboard" && method === "GET") {
  const rows = db
.prepare(
  `SELECT u.id, u.name,
  (SELECT COUNT(*) FROM progress p WHERE p.user_id = u.id) AS done,
  COALESCE((SELECT ROUND(AVG(p.score)) FROM progress p WHERE p.user_id = u.id AND p.score IS NOT NULL), 0) AS avg
  FROM users u ORDER BY done DESC, avg DESC, u.id ASC LIMIT 50`
  )
.all();

  const list = rows.length
  ? rows
.map(
  (u, i) => `<tr>
  <td><span class="rank${i < 3 ? " rank-top": ""}">${i + 1}</span></td>
  <td><b>${h(u.name)}</b></td>
  <td>${u.done}</td>
  <td>${u.avg ? u.avg + "%": " "}</td>
  </tr>`
  )
.join("")
: `<tr><td colspan="4" class="muted">Hozircha natijalar yo'q.</td></tr>`;

  const body = `
  <section class="page-hero center">
  <span class="eyebrow">Reyting</span>
  <h1>Eng faol o'quvchilar</h1>
  <p class="lead">Tugatilgan darslar va o'rtacha test natijasi bo'yicha.</p>
  </section>
  <section class="section tight">
  <div class="wrap">
  <div class="card">
  <div class="table-wrap">
  <table>
  <thead><tr><th>#</th><th>O'quvchi</th><th>Tugatgan darslari</th><th>O'rtacha natija</th></tr></thead>
  <tbody>${list}</tbody>
  </table>
  </div>
  </div>
  </div>
  </section>`;
  send(res, 200, layout({ title: "Reyting", body, user, admin }));
  return;
  }

  /* --------------------------------------------------------------- duel */
  if (p === "/dashboard" && method === "GET") {
  if (!user) return redirect(res, "/login?next=/dashboard");
  send(res, 200, layout({ title: "Kabinet", body: dashboardPage(user), user }));
  return;
  }

  if (p === "/duel" && method === "GET") {
  send(res, 200, layout({ title: "Duel", body: duelDashboardPage(user), user, admin }));
  return;
  }

  if (p === "/duel/create" && method === "POST") {
  if (!user) return redirect(res, "/login?next=/duel");
  const picked = db.prepare("SELECT id, lesson_id FROM questions ORDER BY RANDOM() LIMIT 10").all();
  if (!picked.length) {
    redirect(res, "/duel?err=test");
    return;
  }
  const lessonId = picked[0].lesson_id;
  let code = duelCode();
  while (db.prepare("SELECT 1 FROM duels WHERE code = ?").get(code)) code = duelCode();
  const info = db
    .prepare(
      "INSERT INTO duels (code, lesson_id, creator_id, status, created_at, title) VALUES (?, ?, ?, 'waiting', ?, ?)"
    )
    .run(code, lessonId, user.id, nowISO(), "Aralash test · 10 savol");
  const duelId = Number(info.lastInsertRowid);
  const insertQ = db.prepare(
    "INSERT OR IGNORE INTO duel_questions (duel_id, question_id, position) VALUES (?, ?, ?)"
  );
  picked.forEach((q, i) => insertQ.run(duelId, q.id, i + 1));
  sendUserMessage(
    user.id,
    `⚔️ <b>Duel yaratildi</b>\nTest: Aralash test · 10 savol\nKod: <b>${code}</b>\nDo'stingizga kodni yuboring yoki havolani ulashing.`,
    `/duel/${code}`,
    "Duelni ochish"
  ).catch(() => {});
  redirect(res, `/duel/${code}`);
  return;
  }

  if (p === "/duel/join" && method === "POST") {
  if (!user) return redirect(res, "/login?next=/duel");
  const code = String(fields.code || "")
.trim()
.toUpperCase()
.replace(/[^A-Z0-9]/g, "")
.slice(0, 6);
  const duel = getDuel(code);
  if (!duel) {
  redirect(res, "/duel?err=notfound");
  return;
  }
  if (duel.creator_id !== user.id && !duel.opponent_id && duel.status === "waiting") {
  db.prepare("UPDATE duels SET opponent_id = ?, status = 'active' WHERE id = ?").run(user.id, duel.id);
  for (const playerId of [duel.creator_id, user.id]) {
  sendUserMessage(
  playerId,
  `—  <b>Duel boshlandi</b>\nTest: ${h(duel.lesson_title)}\nKod: <b>${duel.code}</b>\n10 ta aralash savol. Har savolga 60 soniya.`,
  `/duel/${duel.code}`,
  "Duelni ochish"
  ).catch(() => {});
  }
  }
  redirect(res, `/duel/${duel.code}`);
  return;
  }

  if (p === "/duel/tournament" && method === "GET") {
  let groups = tournamentGroups();
  if (!groups.length) {
  ensureTournament();
  groups = tournamentGroups();
  }
  autoEnrollAll();
  groups = tournamentGroups();
  const requested = Number(url.searchParams.get("g"));
  const tournament =
  groups.find((g) => g.group_no === requested) ||
  groups
  .slice()
  .reverse()
  .find((g) => tournamentEntries(g.id).length > 0) ||
  groups[groups.length - 1];
  send(
  res,
  200,
  layout({
  title: "Kunlik duel",
  body: tournamentPage(tournament, user, admin, groups),
  user,
  admin
  })
  );
  return;
  }

  if (p === "/duel/tournament/join" && method === "POST") {
  if (!user) return redirect(res, "/login?next=/duel/tournament");
  const tournament = ensureJoinableTournament();
  const matches = tournamentMatches(tournament.id);
  const hasScores = matches.some((m) => m.s1 != null || m.s2 != null);
  const lateOpen = tournament.status === "open" || (tournament.status === "live" && !hasScores);
  if (!lateOpen) {
  redirect(res, "/duel/tournament?err=late");
  return;
  }
  const entries = tournamentEntries(tournament.id);
  if (!entries.some((e) => e.user_id === user.id) && entries.length < 128) {
  const wasLive = tournament.status === "live";
  if (wasLive) {
  db.prepare("UPDATE tournaments SET status = 'open', started_at = NULL WHERE id = ?").run(tournament.id);
  }
  db.prepare(
  "INSERT INTO tournament_entries (tournament_id, user_id, seed, joined_at) VALUES (?, ?, ?, ?)"
  ).run(tournament.id, user.id, entries.length + 1, nowISO());
  if (tournament.status === "open") {
  db.prepare("UPDATE tournaments SET size = ? WHERE id = ?").run(
  nextPowerOfTwo(entries.length + 1),
  tournament.id
  );
  }
  if (wasLive) startTournament(tournament.id);
  }
  redirect(res, `/duel/tournament?g=${tournament.group_no}`);
  return;
  }

  if (p === "/duel/tournament/start" && method === "POST") {
  if (!admin) return redirect(res, "/duel/tournament");
  const tournament = ensureTournament();
  startTournament(tournament.id);
  redirect(res, "/duel/tournament");
  return;
  }

  const tourMatch = p.match(/^\/duel\/tournament\/match\/(\d+)(\/submit)?$/);
  if (tourMatch) {
  if (!user) return redirect(res, `/login?next=${encodeURIComponent(p)}`);
  const match = db.prepare("SELECT * FROM tournament_matches WHERE id = ?").get(Number(tourMatch[1]));
  if (!match) return notFound(res, user, admin);
  const tournament = db.prepare("SELECT * FROM tournaments WHERE id = ?").get(match.tournament_id);
  if (!tournament) return notFound(res, user, admin);
  const isP1 = match.p1 === user.id;
  const isP2 = match.p2 === user.id;
  if (!isP1 && !isP2) {
  redirect(res, "/duel/tournament");
  return;
  }
  const already = isP1 ? match.s1: match.s2;
  if (already != null) {
  redirect(res, "/duel/tournament");
  return;
  }

  if (tourMatch[2] === "/submit" && method === "POST") {
  if (match.status !== "ready") {
  redirect(res, "/duel/tournament");
  return;
  }
  let questions = tournamentQuestions(tournament.id);
  if (!questions.length) {
    prepareTournamentQuestions(tournament.id);
    questions = tournamentQuestions(tournament.id);
  }
  let correct = 0;
  questions.forEach((q) => {
  if (String(fields[`q${q.id}`]) === String(q.correct)) correct += 1;
  });
  const total = Math.max(1, questions.length);
  const start = db
.prepare("SELECT started_at FROM tournament_starts WHERE match_id = ? AND user_id = ?")
.get(match.id, user.id);
  const elapsed = Math.min(
  1800000,
  Math.max(1000, Date.now() - (start ? Date.parse(start.started_at): Date.now()))
  );
  const fieldScore = isP1 ? "s1": "s2";
  const fieldTime = isP1 ? "t1": "t2";
  db.prepare(`UPDATE tournament_matches SET ${fieldScore} = ?, ${fieldTime} = ? WHERE id = ?`).run(
  correct,
  elapsed,
  match.id
  );
  db.prepare("DELETE FROM tournament_starts WHERE match_id = ? AND user_id = ?").run(match.id, user.id);
  const updated = db.prepare("SELECT * FROM tournament_matches WHERE id = ?").get(match.id);
  if (updated.s1 != null && updated.s2 != null) {
  const winner =
  updated.s1 > updated.s2
  ? updated.p1
: updated.s2 > updated.s1
  ? updated.p2
: updated.t1 <= updated.t2
  ? updated.p1
: updated.p2;
  db.prepare(
  "UPDATE tournament_matches SET winner = ?, status = 'finished', finished_at = ? WHERE id = ?"
  ).run(winner, nowISO(), match.id);
  propagateTournament(tournament.id);
  const winnerName = db.prepare("SELECT name FROM users WHERE id = ?").get(winner)?.name || "?";
  notifyTelegram(
  `x  <b>Kunlik duel</b>\n${h(tournament.day)}. ${tournamentRoundName(
  tournament.size,
  match.round
  )}\nG'olib: <b>${h(winnerName)}</b> (${updated.s1}:${updated.s2})`
  ).catch(() => {});
  }
  redirect(res, "/duel/tournament");
  return;
  }

  if (method === "GET") {
  if (match.status !== "ready") {
  redirect(res, "/duel/tournament");
  return;
  }
  const start = db
.prepare("SELECT started_at FROM tournament_starts WHERE match_id = ? AND user_id = ?")
.get(match.id, user.id);
  const startMs = start ? Date.parse(start.started_at): 0;
  if (!start || Date.now() - startMs > 2 * 60 * 60 * 1000) {
  db.prepare(
  "INSERT INTO tournament_starts (match_id, user_id, started_at) VALUES (?, ?, ?) ON CONFLICT(match_id, user_id) DO UPDATE SET started_at = excluded.started_at"
  ).run(match.id, user.id, nowISO());
  }
  let questions = tournamentQuestions(tournament.id);
  if (!questions.length) {
    prepareTournamentQuestions(tournament.id);
    questions = tournamentQuestions(tournament.id);
  }
  if (!questions.length) {
  redirect(res, "/duel/tournament");
  return;
  }
  send(res, 200, tournamentMatchPage(match, tournament, questions, user));
  return;
  }
  }

  const duelMatch = p.match(/^\/duel\/([A-Z0-9]{6})(\/start|\/submit|\/delete)?$/i);
  if (duelMatch) {
  if (!user) return redirect(res, `/login?next=${encodeURIComponent(p)}`);
  const code = duelMatch[1].toUpperCase();
  const duel = getDuel(code);
  if (!duel) return notFound(res, user, admin);
  const action = duelMatch[2];
  const isCreator = duel.creator_id === user.id;
  const isOpponent = duel.opponent_id === user.id;
  const participant = isCreator || isOpponent;

  if (action === "/delete" && method === "POST") {
  if (!isCreator || duel.status !== "waiting") {
  redirect(res, `/duel/${code}`);
  return;
  }
  db.prepare("DELETE FROM duel_plays WHERE duel_id = ?").run(duel.id);
  db.prepare("DELETE FROM duel_starts WHERE duel_id = ?").run(duel.id);
  db.prepare("DELETE FROM duels WHERE id = ?").run(duel.id);
  redirect(res, "/duel");
  return;
  }

  if (action === "/start" && method === "GET") {
  if (!participant) {
  send(res, 200, layout({ title: "Duel", body: duelRoomPage(duel, user), user }));
  return;
  }
  if (duel.status === "waiting" || duel.status === "finished") {
  redirect(res, `/duel/${code}`);
  return;
  }
  if (db.prepare("SELECT 1 FROM duel_plays WHERE duel_id = ? AND user_id = ?").get(duel.id, user.id)) {
  redirect(res, `/duel/${code}`);
  return;
  }
  const start = db
.prepare("SELECT started_at FROM duel_starts WHERE duel_id = ? AND user_id = ?")
.get(duel.id, user.id);
  const startMs = start ? Date.parse(start.started_at): 0;
  if (!start || Date.now() - startMs > 2 * 60 * 60 * 1000) {
  db.prepare(
  "INSERT INTO duel_starts (duel_id, user_id, started_at) VALUES (?, ?, ?) ON CONFLICT(duel_id, user_id) DO UPDATE SET started_at = excluded.started_at"
  ).run(duel.id, user.id, nowISO());
  }
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(duel.lesson_id);
  let questions = db
    .prepare(
      "SELECT q.* FROM duel_questions dq JOIN questions q ON q.id = dq.question_id WHERE dq.duel_id = ? ORDER BY dq.position"
    )
    .all(duel.id);
  if (!questions.length) {
    questions = db.prepare("SELECT * FROM questions WHERE lesson_id = ? ORDER BY RANDOM() LIMIT 10").all(duel.lesson_id);
  }
  if (!lesson || !questions.length) {
  redirect(res, `/duel/${code}`);
  return;
  }
  send(res, 200, duelPlayPage(duel, lesson, questions));
  return;
  }

  if (action === "/submit" && method === "POST") {
  if (!participant || duel.status !== "active") {
  redirect(res, `/duel/${code}`);
  return;
  }
  if (db.prepare("SELECT 1 FROM duel_plays WHERE duel_id = ? AND user_id = ?").get(duel.id, user.id)) {
  redirect(res, `/duel/${code}`);
  return;
  }
  let allQuestions = db
    .prepare(
      "SELECT q.* FROM duel_questions dq JOIN questions q ON q.id = dq.question_id WHERE dq.duel_id = ? ORDER BY dq.position"
    )
    .all(duel.id);
  if (!allQuestions.length) {
    allQuestions = db.prepare("SELECT * FROM questions WHERE lesson_id = ?").all(duel.lesson_id);
  }
  let correct = 0;
  allQuestions.forEach((q) => {
  if (String(fields[`q${q.id}`]) === String(q.correct)) correct += 1;
  });
  const total = Math.max(1, allQuestions.length);
  const start = db
.prepare("SELECT started_at FROM duel_starts WHERE duel_id = ? AND user_id = ?")
.get(duel.id, user.id);
  const elapsed = Math.min(
  3600000,
  Math.max(1000, Date.now() - (start ? Date.parse(start.started_at): Date.now()))
  );
  db.prepare(
  "INSERT INTO duel_plays (duel_id, user_id, score, correct, total, elapsed_ms, finished_at) VALUES (?, ?, ?, ?, ?, ?, ?)"
  ).run(duel.id, user.id, Math.round((correct / total) * 100), correct, total, elapsed, nowISO());
  db.prepare("DELETE FROM duel_starts WHERE duel_id = ? AND user_id = ?").run(duel.id, user.id);

  const plays = duelPlays(duel.id);
  if (duel.opponent_id && plays[duel.creator_id] && plays[duel.opponent_id]) {
  db.prepare("UPDATE duels SET status = 'finished', finished_at = ? WHERE id = ?").run(nowISO(), duel.id);
  const creatorPlay = plays[duel.creator_id];
  const opponentPlay = plays[duel.opponent_id];
  const creatorName = db.prepare("SELECT name FROM users WHERE id = ?").get(duel.creator_id).name;
  const opponentName = db.prepare("SELECT name FROM users WHERE id = ?").get(duel.opponent_id).name;
  notifyTelegram(
  `a  <b>Duel yakunlandi</b>\n${h(creatorName)}: ${creatorPlay.correct}/${creatorPlay.total} (${Math.round(
  creatorPlay.elapsed_ms / 1000
  )}s)\n${h(opponentName)}: ${opponentPlay.correct}/${opponentPlay.total} (${Math.round(
  opponentPlay.elapsed_ms / 1000
  )}s)`
  ).catch(() => {});
  }
  redirect(res, `/duel/${code}`);
  return;
  }

  if (method === "GET") {
  send(res, 200, layout({ title: "Duel", body: duelRoomPage(duel, user), user }));
  return;
  }
  }

  const courseMatch = p.match(/^\/course\/(\d+)$/);
  if (courseMatch && method === "GET") {
  if (!user) return redirect(res, "/login");
  const course = db.prepare("SELECT * FROM courses WHERE id = ?").get(Number(courseMatch[1]));
  if (!course) return notFound(res, user, admin);

  db.prepare("INSERT OR IGNORE INTO enrollments (user_id, course_id, created_at) VALUES (?, ?, ?)").run(
  user.id,
  course.id,
  nowISO()
  );

  const lessons = db
.prepare("SELECT * FROM lessons WHERE course_id = ? ORDER BY position, id")
.all(course.id);
  const progress = Object.fromEntries(
  db
.prepare("SELECT lesson_id, score FROM progress WHERE user_id = ?")
.all(user.id)
.map((r) => [r.lesson_id, r.score])
  );
  const { total, done } = courseProgress(user.id, course.id);

  const rows = lessons.length
  ? lessons
.map((l, i) => {
  const finished = Object.prototype.hasOwnProperty.call(progress, l.id);
  return `<a class="lesson-row" href="/lesson/${l.id}">
  <span class="num">${i + 1}</span>
  <span class="lesson-main">
  <b>${h(l.title)}</b>
  <small>${TYPE_LABEL[l.type] || h(l.type)}${
  l.type === "test" ? ". test": ""
  }</small>
  </span>
  ${finished ? `<span class="badge done">Tugatilgan${typeof progress[l.id] === "number" ? `. ${progress[l.id]}%`: ""}</span>`: `<span class="badge">Ochish</span>`}
  </a>`;
  })
.join("")
: `<div class="card empty">Bu kursda hozircha darslar yo'q.</div>`;

  const body = `
  <a class="back" href="/courses">  Kurslar</a>
  <div class="page-head">
  <div><h1>${h(course.title)}</h1><p class="muted">${h(course.description || "")}</p></div>
  </div>
  <div class="card">${progressBar(done, total)}</div>
  <div class="lesson-list">${rows}</div>`;
  send(res, 200, layout({ title: course.title, body, user, admin }));
  return;
  }

  /* --------------------------------------------------------------- test */
  const testMatch = p.match(/^\/test\/(\d+)(\/submit)?$/);
  if (testMatch && (method === "GET" || method === "POST")) {
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(Number(testMatch[1]));
  if (!lesson || lesson.type !== "test") return notFound(res, user, admin);

  const isSubmit = testMatch[2] === "/submit";
  const isStart = url.searchParams.get("start") === "1";
  const price = Number(lesson.price) || 0;
  const owned = !!user && (price === 0 || testOwned(user.id, lesson.id));
  const startHref = `/test/${lesson.id}?start=1`;

  if (method === "GET" && !isSubmit && !isStart && !url.searchParams.has("result")) {
  db.prepare("UPDATE lessons SET views = views + 1 WHERE id = ?").run(lesson.id);
  }

  const questions = db
.prepare("SELECT * FROM questions WHERE lesson_id = ? ORDER BY id")
.all(lesson.id);

  if (isSubmit && method === "POST") {
  if (!user) return redirect(res, `/login?next=${encodeURIComponent(startHref)}`);
  if (!owned) return redirect(res, `/test/${lesson.id}`);

  let correct = 0;
  questions.forEach((q) => {
  if (String(fields[`q${q.id}`]) === String(q.correct)) correct += 1;
  });
  const score = questions.length ? Math.round((correct / questions.length) * 100): 0;
  db.prepare(
  `INSERT INTO progress (user_id, lesson_id, score, completed_at) VALUES (?, ?, ?, ?)
  ON CONFLICT(user_id, lesson_id) DO UPDATE SET score = excluded.score, completed_at = excluded.completed_at`
  ).run(user.id, lesson.id, score, nowISO());

  const maxScore = Number(lesson.max_score) || 0;
  const shown = maxScore > 0 ? `${Math.round((score / 100) * maxScore)} / ${maxScore}`: `${score}%`;
  notifyTelegram(
  `x} <b>Test yakunlandi</b>\nx  ${h(user.name)}. ${h(user.phone)}\nx  ${h(
  lesson.title
  )}\nS& Natija: <b>${score}%</b> (${shown})\nx"  ${new Date().toLocaleString("uz-UZ")}`
  ).catch(() => {});

  redirect(res, `/test/${lesson.id}?result=${score}`);
  return;
  }

  if (isStart) {
  if (!user) return redirect(res, `/login?next=${encodeURIComponent(startHref)}`);
  if (!owned) {
  redirect(res, `/test/${lesson.id}`);
  return;
  }
  if (!questions.length) {
  send(
  res,
  200,
  layout({
  title: lesson.title,
  body: `<a class="back" href="${moduleHref(lesson)}">  Testlar</a><div class="card empty"><h2>Test savollari hali qo'shilmagan</h2><p class="muted">Administrator tez orada savollarni qo'shadi.</p></div>`,
  user
  })
  );
  return;
  }
  const result = url.searchParams.get("result");
  if (result !== null) {
  const score = Math.max(0, Math.min(100, Number(result) || 0));
  send(res, 200, testResultPage(lesson, questions, score));
  } else {
  const testSections = db
.prepare("SELECT * FROM test_sections WHERE lesson_id = ? ORDER BY position, id")
.all(lesson.id);
  send(res, 200, testPage(lesson, questions, testSections));
  }
  return;
  }

  if (url.searchParams.has("result") && user && owned && questions.length) {
  const score = Math.max(0, Math.min(100, Number(url.searchParams.get("result")) || 0));
  send(res, 200, testResultPage(lesson, questions, score));
  return;
  }

  send(res, 200, layout({ title: lesson.title, body: testLanding(lesson, { user, admin, owned }), user, admin }));
  return;
  }

  /* ------------------------------------------------------------- lesson */
  const watchMatch = p.match(/^\/lesson\/(\d+)\/watch$/);
  if (watchMatch && method === "POST") {
  if (!user) {
  res.writeHead(401, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ ok: false, login: true }));
  return;
  }
  const watchedLesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(Number(watchMatch[1]));
  if (!watchedLesson || watchedLesson.type !== "video" || !watchedLesson.file_id) {
  res.writeHead(404, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ ok: false }));
  return;
  }
  const seconds = Math.max(0, Math.min(24 * 3600, Number(fields.seconds) || 0));
  const duration = Math.max(0, Math.min(24 * 3600, Number(fields.duration) || 0));
  db.prepare(
  `INSERT INTO video_watch (user_id, lesson_id, max_seconds, duration, updated_at)
  VALUES (?, ?, ?, ?, ?)
  ON CONFLICT(user_id, lesson_id) DO UPDATE SET
  max_seconds = MAX(video_watch.max_seconds, excluded.max_seconds),
  duration = CASE WHEN excluded.duration > 0 THEN excluded.duration ELSE video_watch.duration END,
  updated_at = excluded.updated_at`
  ).run(user.id, watchedLesson.id, seconds, duration, nowISO());
  const saved = db.prepare("SELECT max_seconds, duration FROM video_watch WHERE user_id = ? AND lesson_id = ?").get(user.id, watchedLesson.id);
  const pct = saved && saved.duration > 0 ? Math.min(100, Math.round((saved.max_seconds / saved.duration) * 100)) : 0;
  res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ ok: true, pct }));
  return;
  }

  const lessonMatch = p.match(/^\/lesson\/(\d+)(\/complete|\/submit)?$/);
  if (lessonMatch && (method === "GET" || method === "POST")) {
  if (!user) return redirect(res, "/login");
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(Number(lessonMatch[1]));
  if (!lesson) return notFound(res, user, admin);
  if (lesson.type === "test" && !lessonMatch[2]) {
  redirect(res, `/test/${lesson.id}`);
  return;
  }
  const course = db.prepare("SELECT * FROM courses WHERE id = ?").get(lesson.course_id);
  const action = lessonMatch[2];

  if (action === "/complete" && method === "POST") {
  if (lesson.type === "video" && lesson.file_id && !admin) {
  const watched = db
  .prepare("SELECT max_seconds, duration FROM video_watch WHERE user_id = ? AND lesson_id = ?")
  .get(user.id, lesson.id);
  const watchDuration = Number(watched && watched.duration) || 0;
  const watchMax = Number(watched && watched.max_seconds) || 0;
  if (!watched || !watchDuration || watchMax < watchDuration * 0.9) {
  if (String(req.headers.accept || "").includes("application/json")) {
  res.writeHead(400, { "Content-Type": "application/json; charset=utf-8" });
  res.end(JSON.stringify({ ok: false, error: "watch" }));
  return;
  }
  redirect(res, `/lesson/${lesson.id}?err=watch`);
  return;
  }
  }
  db.prepare(
  `INSERT INTO progress (user_id, lesson_id, score, completed_at) VALUES (?, ?, NULL, ?)
  ON CONFLICT(user_id, lesson_id) DO UPDATE SET completed_at = excluded.completed_at`
  ).run(user.id, lesson.id, nowISO());
  if (String(req.headers.accept || "").includes("application/json")) {
  const nextRow = db
  .prepare(
  "SELECT id, type FROM lessons WHERE course_id = ? AND (position > ? OR (position = ? AND id > ?)) ORDER BY position, id LIMIT 1"
  )
  .get(lesson.course_id, lesson.position, lesson.position, lesson.id);
  const nextUrl = nextRow
  ? nextRow.type === "test"
  ? `/test/${nextRow.id}`
  : `/lesson/${nextRow.id}`
  : `/course/${lesson.course_id}`;
  res.writeHead(200, { "Content-Type": "application/json; charset=utf-8", "Cache-Control": "no-store" });
  res.end(JSON.stringify({ ok: true, next: nextUrl }));
  return;
  }
  redirect(res, `/lesson/${lesson.id}`);
  return;
  }

  if (action === "/submit" && method === "POST") {
  const questions = db.prepare("SELECT * FROM questions WHERE lesson_id = ?").all(lesson.id);
  let correct = 0;
  questions.forEach((q) => {
  if (String(fields[`q${q.id}`]) === String(q.correct)) correct += 1;
  });
  const score = questions.length ? Math.round((correct / questions.length) * 100): 0;
  db.prepare(
  `INSERT INTO progress (user_id, lesson_id, score, completed_at) VALUES (?, ?, ?, ?)
  ON CONFLICT(user_id, lesson_id) DO UPDATE SET score = excluded.score, completed_at = excluded.completed_at`
  ).run(user.id, lesson.id, score, nowISO());
  redirect(res, `/lesson/${lesson.id}?result=${score}`);
  return;
  }

  const progressRow = db
    .prepare("SELECT score FROM progress WHERE user_id = ? AND lesson_id = ?")
    .get(user.id, lesson.id);
  const result = url.searchParams.get("result");
  const completed = !!progressRow;
  const lessonList = db
    .prepare("SELECT id, title, type, position FROM lessons WHERE course_id = ? ORDER BY position, id")
    .all(lesson.course_id);
  const lessonIndex = lessonList.findIndex((l) => l.id === lesson.id);
  const lessonNo = lessonIndex >= 0 ? lessonIndex + 1 : 1;
  const nextLesson = lessonIndex >= 0 ? lessonList[lessonIndex + 1] || null : null;
  const nextHref = nextLesson
    ? nextLesson.type === "test"
      ? `/test/${nextLesson.id}`
      : `/lesson/${nextLesson.id}`
    : `/course/${course.id}`;
  const relatedTest =
    lesson.type === "video"
      ? db
          .prepare(
            "SELECT id, title FROM lessons WHERE course_id = ? AND type = 'test' AND (position > ? OR (position = ? AND id > ?)) ORDER BY position, id LIMIT 1"
          )
          .get(course.id, lesson.position, lesson.position, lesson.id)
      : null;
  const testQuestionCount = relatedTest
    ? db.prepare("SELECT COUNT(*) AS n FROM questions WHERE lesson_id = ?").get(relatedTest.id).n
    : 0;
  const testProgress = relatedTest
    ? db.prepare("SELECT score FROM progress WHERE user_id = ? AND lesson_id = ?").get(user.id, relatedTest.id)
    : null;
  const testDone = !!(testProgress && Number(testProgress.score) >= 60);
  const hasTestStep = !!relatedTest;
  const stepsTotal = hasTestStep ? 3 : 2;
  const stepsDone =
    (completed ? 1 : 0) +
    (hasTestStep && testDone ? 1 : 0) +
    (completed && (!hasTestStep || testDone) && nextLesson ? 1 : 0);
  const materials = db.prepare("SELECT * FROM materials WHERE lesson_id = ? ORDER BY id").all(lesson.id);
  const views = Number(lesson.views) || 0;

  let contentHtml = "";
  let videoFile = false;
  if (lesson.type === "text") {
    contentHtml = `<div class="prose">${nl2br(lesson.content || "")}</div>`;
  } else if (lesson.type === "pdf") {
    contentHtml = `
      <div class="pdf-actions">
        <a class="btn btn-primary" href="/files/${lesson.id}" target="_blank" rel="noopener">PDF ochish</a>
        <a class="btn btn-ghost" href="/files/${lesson.id}?download=1">Yuklab olish</a>
      </div>
      <iframe class="pdf-frame" src="/files/${lesson.id}" title="PDF"></iframe>`;
  } else if (lesson.type === "video") {
    videoFile = !!lesson.file_id;
    contentHtml = lesson.file_id
      ? `<video class="lesson-video" id="lessonVideo" controls preload="metadata" controlsList="nodownload" disablePictureInPicture oncontextmenu="return false" src="/media/${lesson.id}?t=${mediaToken(
          lesson.id,
          user ? user.id : 0
        )}"></video>`
      : lesson.video_url
      ? videoEmbed(lesson.video_url)
      : `<div class="card empty">Video yuklanmagan yoki havola qo'shilmagan.</div>`;
  } else if (lesson.type === "test") {
    const questions = db.prepare("SELECT * FROM questions WHERE lesson_id = ?").all(lesson.id);
    if (!questions.length) {
      contentHtml = `<div class="card empty">Test savollari hali qo'shilmagan.</div>`;
    } else {
      contentHtml = `<form method="post" action="/lesson/${lesson.id}/submit" class="test-form">
        ${questions
          .map(
            (q, i) => `<fieldset class="question">
              <legend>${i + 1}. ${h(q.text)}</legend>
              ${[1, 2, 3, 4]
                .map(
                  (n) => `<label class="opt"><input type="radio" name="q${q.id}" value="${n}" required> <span>${h(
                    q["o" + n]
                  )}</span></label>`
                )
                .join("")}
            </fieldset>`
          )
          .join("")}
        <button class="btn btn-primary" type="submit">Testni yakunlash</button>
      </form>`;
    }
  }

  const resultHtml =
    url.searchParams.get("err") === "watch"
      ? alertBox("Avval videoni to'liq ko'ring — keyin dars tugaydi.", "error")
      : result !== null
      ? alertBox(`Test yakunlandi: ${result}% to'g'ri javob.`, Number(result) >= 60 ? "success" : "error")
      : progressRow && lesson.type === "test"
      ? alertBox(
          `Bu testni tugatgansiz${progressRow.score != null ? ` | natija: ${progressRow.score}%` : ""}.`,
          "success"
        )
      : "";

  const stepOneTitle =
    lesson.type === "video" ? "Videoni ko'ring" : lesson.type === "pdf" ? "PDF bilan tanishing" : "Darsni o'qing";
  const stepOneNote = completed ? "Tugatildi" : lesson.type === "video" ? "0% ko'rildi" : "Tugatilmagan";
  const progressPercent = Math.round((stepsDone / stepsTotal) * 100);
  const canNext = completed && (!hasTestStep || testDone);
  const testStepClass = !completed ? "locked" : testDone ? "done" : "active";
  const testStepIcon = testDone ? "&#10003;" : completed ? "2" : "&#128274;";
  const testStepNote = testDone
    ? "O'tildi"
    : completed
    ? `${testQuestionCount} ta savol | o'tish balli 60%`
    : "Video tugagach ochiladi";
  const nextStepNote = !completed
    ? "Dars tugagach ochiladi"
    : hasTestStep && !testDone
    ? "Testdan o'tgach ochiladi"
    : "Ochiladi";

  const videoHead =
    lesson.type === "video"
      ? `<div class="lvc-head">
          <span class="lvc-title"><span class="lvc-ico"><svg viewBox="0 0 24 24"><rect x="3" y="6" width="13" height="12" rx="2"/><path d="m16 10 5-3v10l-5-3z"/></svg></span> Video dars</span>
          <span class="lvc-meta">${views ? `${views} marta ko'rilgan` : ""}</span>
        </div>`
      : "";

  const completeBlock =
    !completed && lesson.type !== "test"
      ? videoFile
        ? `<button class="btn btn-primary dash-next" type="button" id="completeLesson" data-lesson="${lesson.id}">Darsni tugatdim</button>`
        : `<form method="post" action="/lesson/${lesson.id}/complete" class="js-complete" data-lesson="${lesson.id}">
            <button class="btn btn-primary" type="submit">Darsni tugatdim</button>
          </form>`
      : "";

  const nextBlock = nextLesson
    ? canNext
      ? `<a class="dash-next-link" href="${nextHref}">Keyingi darsga o'tish &rarr;</a>`
      : hasTestStep && completed && !testDone
      ? `<a class="dash-next-link" href="/test/${relatedTest.id}">Testdan o'tish &rarr;</a>`
      : `<span class="dash-next-locked"><span class="lock-ico">&#128274;</span> ${nextStepNote}</span>`
    : `<a class="dash-next-link" href="/course/${course.id}">Kursga qaytish &rarr;</a>`;

  const materialsHtml = materials.length
    ? `<div class="lesson-materials">${materials
        .map(
          (m) =>
            `<a class="lesson-material" href="/materials/${m.id}" ${
              m.type === "link" ? 'target="_blank" rel="noopener"' : ""
            }>
              <span class="lm-ico">${m.type === "file" ? "PDF" : m.type === "link" ? "LINK" : "TXT"}</span>
              <span class="lm-copy"><b>${h(m.title)}</b><small>${h(m.type)}</small></span>
              <span class="lm-go">&rarr;</span>
            </a>`
        )
        .join("")}</div>`
    : `<div class="card empty lesson-empty-materials"><span class="empty-ico">&#128196;</span><p class="muted">Materiallar hali qo'shilmagan</p></div>`;

  const body = `
    <a class="back" href="/course/${course.id}">&larr; ${h(course.title)}</a>
    <div class="lesson-head">
      <div class="lesson-badges">
        <span class="badge">${lessonNo}-dars</span>
        ${
          lesson.type === "video"
            ? `<span class="badge ghost">${Number(lesson.duration_min) || 0} daqiqa</span>`
            : `<span class="badge ghost">${TYPE_LABEL[lesson.type] || lesson.type}</span>`
        }
        ${completed ? `<span class="badge done">Tugatildi</span>` : ""}
      </div>
      <h1>${h(lesson.title)}</h1>
    </div>
    ${resultHtml}
    <div class="lesson-grid">
      <div class="lesson-main">
        <div class="lesson-video-card">
          ${videoHead}
          ${contentHtml}
          ${
            lesson.type === "video"
              ? `<details class="video-help"><summary>Video ochilmayaptimi?</summary><p class="muted small">Internet aloqasini tekshiring yoki sahifani yangilang. Muammo davom etsa, Telegram guruhida yozing.</p></details>`
              : ""
          }
        </div>
        <div class="card lesson-materials-card">
          <div class="card-head"><h2>Dars materiallari</h2></div>
          ${materialsHtml}
        </div>
      </div>
      <aside class="lesson-side">
        <div class="card lesson-steps">
          <div class="card-head"><h2>Dars bosqichlari</h2><span class="muted small">${stepsDone}/${stepsTotal}</span></div>
          <div class="lesson-progress"><span style="width:${progressPercent}%"></span></div>
          <div class="lesson-step ${completed ? "done" : ""}">
            <span class="ls-ico">${completed ? "&#10003;" : "1"}</span>
            <span class="ls-copy"><b>${stepOneTitle}</b><small>${stepOneNote}</small></span>
          </div>
          ${
            hasTestStep
              ? `<div class="lesson-step ${testStepClass}">
                  <span class="ls-ico">${testStepIcon}</span>
                  <span class="ls-copy"><b>Testdan o'ting</b><small>${testStepNote}</small></span>
                </div>${
                  !completed
                    ? '<p class="muted small step-note">Test video oxirigacha ko\'rilgach ochiladi.</p>'
                    : ""
                }`
              : ""
          }
          <div class="lesson-step ${canNext ? "done" : "locked"}">
            <span class="ls-ico">${canNext ? "&#10003;" : "&#128274;"}</span>
            <span class="ls-copy"><b>Keyingi dars</b><small>${nextStepNote}</small></span>
          </div>
          ${completeBlock}
          ${nextBlock}
        </div>
        <a class="card discuss-card" href="${h(config.telegram || "#")}" target="_blank" rel="noopener">
          <span class="dc-ico"><svg viewBox="0 0 24 24"><path d="M21 11.5a8.4 8.4 0 0 1-9 8.4 9 9 0 0 1-3.9-.9L3 20l1-4.1A8.4 8.4 0 0 1 12 3a8.4 8.4 0 0 1 9 8.5Z"/></svg></span>
          <span class="dc-copy"><b>Muhokama guruhi</b><small>Savollaringizga Telegram guruhda javob oling</small></span>
          <span class="dc-go">&#8599;</span>
        </a>
      </aside>
    </div>
    ${
      lesson.type === "video" && videoFile
        ? `<script>
      (function () {
        var v = document.getElementById('lessonVideo');
        var btn = document.getElementById('completeLesson');
        var note = document.querySelector('.lesson-step.done small');
        var next = ${JSON.stringify(nextHref)};
        var lessonId = ${lesson.id};
        var sent = false, maxWatched = 0, duration = 0, lastSync = 0;
        function percent() { return duration > 0 ? Math.min(100, Math.round((maxWatched / duration) * 100)) : 0; }
        function paint() {
          var p = percent();
          if (note) note.textContent = p + "% ko'rildi";
          if (btn) {
            if (p >= 99) { btn.disabled = false; btn.textContent = 'Darsni tugatdim'; }
          }
        }
        function sync(force) {
          if (!duration || (!force && Date.now() - lastSync < 8000)) return;
          lastSync = Date.now();
          var body = new URLSearchParams();
          body.set('seconds', maxWatched.toFixed(1));
          body.set('duration', duration.toFixed(1));
          fetch('/lesson/' + lessonId + '/watch', {
            method: 'POST',
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
            body: body.toString()
          }).catch(function () {});
        }
        function finish() {
          if (sent) return;
          sent = true;
          sync(true);
          fetch('/lesson/' + lessonId + '/complete', { method: 'POST', headers: { Accept: 'application/json' } })
            .then(function (r) { return r.json(); })
            .then(function (d) {
              if (!d || !d.ok) {
                sent = false;
                alert("Video to'liq ko'rilmagan. Iltimos, oxirigacha ko'ring.");
                return;
              }
              location.reload();
            })
            .catch(function () { sent = false; });
        }
        if (v) {
          v.addEventListener('loadedmetadata', function () { duration = Number(v.duration) || 0; paint(); });
          v.addEventListener('timeupdate', function () {
            if (duration > 0 && v.currentTime > maxWatched + 1.5) { v.currentTime = maxWatched; return; }
            if (v.currentTime > maxWatched) maxWatched = v.currentTime;
            paint();
            sync(false);
            if (duration > 0 && maxWatched / duration >= 0.99) finish();
          });
          v.addEventListener('seeking', function () {
            if (v.currentTime > maxWatched + 1) v.currentTime = maxWatched;
          });
          v.addEventListener('ended', finish);
          v.addEventListener('contextmenu', function (e) { e.preventDefault(); });
          v.setAttribute('controlsList', 'nodownload');
        }
        if (btn) { btn.disabled = true; btn.textContent = 'Video tugagach faollashadi'; btn.addEventListener('click', finish); }
      })();
      </script>`
        : ""
    }`;

  send(res, 200, layout({ title: lesson.title, body, user }));
  return;
  }


  /* -------------------------------------------------------- pdf serving */
  const mediaMatch = p.match(/^\/media\/(\d+)$/);
  if (mediaMatch && method === "GET") {
  if (!user && !admin) return redirect(res, "/login");
  const mediaLessonId = Number(mediaMatch[1]);
  const viewerId = user ? user.id : 0;
  if (!mediaTokenValid(mediaLessonId, viewerId, url.searchParams.get("t"))) {
  res.writeHead(403, { "Content-Type": "text/plain; charset=utf-8" });
  res.end("Video faqat platforma ichida ko'riladi.");
  return;
  }
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(mediaLessonId);
  if (!lesson || lesson.type !== "video" || !lesson.file_id) return notFound(res, user, admin);
  if (!admin && Number(lesson.price) > 0 && !testOwned(user.id, lesson.id)) {
  redirect(res, `/test/${lesson.id}`);
  return;
  }
  const videoPath = path.join(STORAGE_DIR, lesson.file_id);
  if (!fs.existsSync(videoPath)) return notFound(res, user, admin);
  const stat = fs.statSync(videoPath);
  const ext = path.extname(lesson.file_id).toLowerCase();
  const types = {
  ".mp4": "video/mp4",
  ".webm": "video/webm",
  ".mov": "video/quicktime",
  ".m4v": "video/x-m4v",
  ".mkv": "video/x-matroska"
  };
  const contentType = types[ext] || "application/octet-stream";
  const range = req.headers.range;
  if (range) {
  const match = /bytes=(\d*)-(\d*)/.exec(range);
  let start = match && match[1] ? Number(match[1]): 0;
  let end = match && match[2] ? Number(match[2]): stat.size - 1;
  if (start >= stat.size) {
  res.writeHead(416, { "Content-Range": `bytes */${stat.size}` });
  res.end();
  return;
  }
  end = Math.min(end, stat.size - 1);
  res.writeHead(206, {
  "Content-Type": contentType,
  "Content-Range": `bytes ${start}-${end}/${stat.size}`,
  "Accept-Ranges": "bytes",
  "Content-Length": end - start + 1,
  "Cache-Control": "private, max-age=600"
  });
  fs.createReadStream(videoPath, { start, end }).pipe(res);
  return;
  }
  res.writeHead(200, {
  "Content-Type": contentType,
  "Content-Length": stat.size,
  "Accept-Ranges": "bytes",
  "Cache-Control": "private, max-age=600"
  });
  fs.createReadStream(videoPath).pipe(res);
  return;
  }

  const fileMatch = p.match(/^\/files\/(\d+)$/);
  if (fileMatch && method === "GET") {
  if (!user && !admin) return redirect(res, "/login");
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(Number(fileMatch[1]));
  if (!lesson || lesson.type !== "pdf" || !lesson.file_id) return notFound(res, user, admin);
  if (!admin && Number(lesson.price) > 0 && !testOwned(user.id, lesson.id)) {
  redirect(res, `/test/${lesson.id}`);
  return;
  }

  const filePath = path.join(STORAGE_DIR, lesson.file_id);
  if (!fs.existsSync(filePath)) return notFound(res, user, admin);

  const download = url.searchParams.get("download") === "1";
  res.writeHead(200, {
  "Content-Type": "application/pdf",
  "Content-Length": fs.statSync(filePath).size,
  "Content-Disposition": `${download ? "attachment": "inline"}; filename*=UTF-8''${encodeURIComponent(
  lesson.file_name || "darslik.pdf"
  )}`,
  "Cache-Control": "private, max-age=600"
  });
  fs.createReadStream(filePath).pipe(res);
  return;
  }

  /* ------------------------------------------------------- materials */
  const materialMatch = p.match(/^\/materials\/(\d+)$/);
  if (materialMatch && method === "GET") {
  if (!user && !admin) return redirect(res, `/login?next=${encodeURIComponent(p)}`);
  const material = db
.prepare(
  `SELECT m.*, l.price AS lesson_price
  FROM materials m JOIN lessons l ON l.id = m.lesson_id
  WHERE m.id = ?`
  )
.get(Number(materialMatch[1]));
  if (!material) return notFound(res, user, admin);
  if (!admin && Number(material.lesson_price) > 0 && !testOwned(user.id, material.lesson_id)) {
  redirect(res, `/test/${material.lesson_id}`);
  return;
  }
  if (material.type === "link") {
  redirect(res, material.url);
  return;
  }
  if (material.type === "text") {
  const body = `
  <a class="back" href="/test/${material.lesson_id}">  Test</a>
  <div class="page-head"><div><h1>${h(material.title)}</h1><p class="muted">Material</p></div></div>
  <div class="card"><div class="prose">${nl2br(material.body || "")}</div></div>`;
  send(res, 200, layout({ title: material.title, body, user, admin }));
  return;
  }
  const filePath = path.join(STORAGE_DIR, material.file_id);
  if (!material.file_id || !fs.existsSync(filePath)) return notFound(res, user, admin);
  res.writeHead(200, {
  "Content-Type": "application/pdf",
  "Content-Length": fs.statSync(filePath).size,
  "Content-Disposition": `inline; filename*=UTF-8''${encodeURIComponent(material.file_name || "material.pdf")}`,
  "Cache-Control": "private, max-age=600"
  });
  fs.createReadStream(filePath).pipe(res);
  return;
  }

  /* --------------------------------------------------------------- admin */
  if (p === "/admin/login") {
  if (admin) return redirect(res, "/admin");

  if (method === "GET") {
  const body = authCard(
  "Admin kirish",
  "Platformani boshqarish uchun parolni kiriting.",
  `<form method="post" action="/admin/login" class="form">
  <div class="field"><label>Parol</label><input name="password" type="password" required autofocus></div>
  <button class="btn btn-primary" type="submit">Kirish</button>
  </form>`
  );
  send(res, 200, layout({ title: "Admin kirish", body }));
  return;
  }

  const ip = clientIp(req);
  const lock = lockedFor(ip);
  if (lock) {
  send(res, 429, layout({ title: "Kutish", body: alertBox(`Juda ko'p urinish. ${lock} soniya kuting.`) }));
  return;
  }

  if (!config.adminPassword || !safeEqual(fields.password || "", config.adminPassword)) {
  noteFailure(ip);
  const body = authCard(
  "Admin kirish",
  "Parol noto'g'ri.",
  `${alertBox("Parol noto'g'ri.")}
  <form method="post" action="/admin/login" class="form">
  <div class="field"><label>Parol</label><input name="password" type="password" required autofocus></div>
  <button class="btn btn-primary" type="submit">Kirish</button>
  </form>`
  );
  send(res, 401, layout({ title: "Admin kirish", body }));
  return;
  }

  clearFailures(ip);
  createAdminSession(res, req);
  redirect(res, "/admin");
  return;
  }

  if (p === "/admin/logout" && method === "POST") {
  const token = parseCookies(req).ht_admin;
  if (token) db.prepare("DELETE FROM admin_sessions WHERE token = ?").run(token);
  clearCookie(res, "ht_admin");
  redirect(res, "/admin/login");
  return;
  }

  if (p === "/admin/template/xlsx" && method === "GET") {
  if (!admin) return redirect(res, "/admin/login");
  const buffer = questionsXlsxTemplate();
  res.writeHead(200, {
  "Content-Type": "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  "Content-Length": buffer.length,
  "Content-Disposition": "attachment; filename*=UTF-8''savollar-namuna.xlsx",
  "Cache-Control": "no-cache"
  });
  res.end(buffer);
  return;
  }

  if (p === "/admin/contract" && method === "GET") {
  if (!admin) return redirect(res, "/admin/login");
  const body = `
  <a class="back" href="/admin">&larr; Admin panel</a>
  <div class="page-head"><div><h1>Ta'lim shartnomasi</h1><p class="muted">Foydalanuvchilar platformaga kirganda ko'radigan matn</p></div></div>
  ${url.searchParams.get("saved") === "1" ? alertBox("Saqlandi.", "success") : ""}
  <div class="card">
  <form method="post" action="/admin/contract" class="form">
  <div class="field"><label>Shartnoma matni</label><textarea name="text" rows="18">${h(contractText())}</textarea></div>
  <button class="btn btn-primary" type="submit">Saqlash</button>
  </form>
  </div>`;
  send(res, 200, layout({ title: "Ta'lim shartnomasi", body, admin }));
  return;
  }

  if (p === "/admin/contract" && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const text = String(fields.text || "").trim().slice(0, 20000);
  metaSet("contract_text", text || DEFAULT_CONTRACT_TEXT);
  return redirect(res, "/admin/contract?saved=1");
  }

  if (p === "/admin" && method === "GET") {
  if (!admin) return redirect(res, "/admin/login");

  const stats = {
  users: db.prepare("SELECT COUNT(*) AS n FROM users").get().n,
  courses: db.prepare("SELECT COUNT(*) AS n FROM courses").get().n,
  lessons: db.prepare("SELECT COUNT(*) AS n FROM lessons").get().n,
  done: db.prepare("SELECT COUNT(*) AS n FROM progress").get().n
  };

  const courses = db
.prepare(
  `SELECT c.*,
  (SELECT COUNT(*) FROM lessons l WHERE l.course_id = c.id) AS lesson_count,
  (SELECT COUNT(DISTINCT e.user_id) FROM enrollments e WHERE e.course_id = c.id) AS student_count
  FROM courses c ORDER BY c.id DESC`
  )
.all();

  const rows = courses.length
  ? courses
.map(
  (c) => `<tr>
  <td><b>${h(c.title)}</b><br><small class="muted">${h(c.description || "")}</small></td>
  <td><span class="badge">${h(CAT_LABEL[c.category] || "Attestatsiya")}</span></td>
  <td>${c.lesson_count}</td>
  <td>${c.student_count}</td>
  <td class="ta-right">
  <a class="btn btn-sm" href="/admin/course/${c.id}#edit-course">Tahrirlash</a>
  <a class="btn btn-sm" href="/admin/course/${c.id}">Darslar</a>
  <form method="post" action="/admin/course/${c.id}/delete" class="inline" onsubmit="return confirm('Kurs va uning barcha darslari ochiriladi. Davom etilsinmi?')">
  <button class="btn btn-sm btn-danger" type="submit">O'chirish</button>
  </form>
  </td>
  </tr>`
  )
.join("")
: `<tr><td colspan="5" class="muted">Hozircha kurslar yo'q.</td></tr>`;

  const body = `
  <div class="page-head"><div><h1>Admin panel</h1><p class="muted">Kurslar, darslar va o'quvchilar boshqaruvi.</p></div><div class="actions"><a class="btn btn-ghost btn-sm" href="/admin/contract">Ta'lim shartnomasi</a></div></div>
  <div class="stats">
  <div class="stat"><b>${stats.users}</b><span>O'quvchilar</span></div>
  <div class="stat"><b>${stats.courses}</b><span>Kurslar</span></div>
  <div class="stat"><b>${stats.lessons}</b><span>Darslar</span></div>
  <div class="stat"><b>${stats.done}</b><span>Tugatilgan darslar</span></div>
  </div>

  <div class="card">
  <h2>Kurslar</h2>
  <div class="table-wrap">
  <table>
  <thead><tr><th>Kurs</th><th>Yo'nalish</th><th>Darslar</th><th>O'quvchilar</th><th></th></tr></thead>
  <tbody>${rows}</tbody>
  </table>
  </div>
  </div>

  <div class="card">
  <h2>Yangi kurs</h2>
  <form method="post" action="/admin/course" class="form">
  <div class="field">
  <label>Yo'nalish</label>
  <select name="category">
  <option value="attestation">Attestatsiya</option>
  <option value="tkt">TKT</option>
  <option value="other">Boshqa</option>
  </select>
  </div>
  <div class="field"><label>Kurs nomi</label><input name="title" required placeholder="Masalan: Atestatsiya testlariga tayyorlov"></div>
  <div class="field"><label>Tavsif</label><textarea name="description" rows="2" placeholder="Qisqacha tavsif"></textarea></div>
  <button class="btn btn-primary" type="submit">Kurs qo'shish</button>
  </form>
  </div>`;
  send(res, 200, layout({ title: "Admin panel", body, admin }));
  return;
  }

  if (p === "/admin/students" && method === "GET") {
  if (!admin) return redirect(res, "/admin/login");
  const students = db
.prepare(
  `SELECT u.id, u.name, u.phone, u.telegram_id, u.created_at,
  (SELECT COUNT(*) FROM progress p WHERE p.user_id = u.id) AS done
  FROM users u ORDER BY u.id DESC`
  )
.all();
  const rows = students.length
  ? students
.map(
  (s) => `<tr>
  <td><b>${h(s.name)}</b></td>
  <td>${h(s.phone)}</td>
  <td>${s.telegram_id ? h(s.telegram_id): " "}</td>
  <td>${s.done}</td>
  <td>${h(String(s.created_at).slice(0, 10))}</td>
  </tr>`
  )
.join("")
: `<tr><td colspan="4" class="muted">Hozircha o'quvchilar yo'q.</td></tr>`;

  const body = `
  <div class="page-head"><div><h1>O'quvchilar</h1><p class="muted">Ro'yxatdan o'tgan foydalanuvchilar.</p></div></div>
  <div class="card">
  <div class="table-wrap">
  <table>
  <thead><tr><th>Ism</th><th>Telefon</th><th>Telegram ID</th><th>Tugatgan darslari</th><th>Ro'yxatdan o'tgan</th></tr></thead>
  <tbody>${rows}</tbody>
  </table>
  </div>
  </div>`;
  send(res, 200, layout({ title: "O'quvchilar", body, admin }));
  return;
  }

  const adminMaterialDelete = p.match(/^\/admin\/material\/(\d+)\/delete$/);
  if (adminMaterialDelete && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const material = db.prepare("SELECT * FROM materials WHERE id = ?").get(Number(adminMaterialDelete[1]));
  if (!material) return redirect(res, "/admin");
  if (material.file_id) {
  try {
  fs.unlinkSync(path.join(STORAGE_DIR, material.file_id));
  } catch (e) {}
  }
  db.prepare("DELETE FROM materials WHERE id = ?").run(material.id);
  redirect(res, `/admin/lesson/${material.lesson_id}/materials`);
  return;
  }

  if (p === "/admin/access-code" && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const code = String(fields.code || "").trim().slice(0, 20);
  if (code.length >= 4) metaSet("access_code", code);
  redirect(res, "/admin");
  return;
  }

  if (p === "/admin/course" && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const title = String(fields.title || "").trim();
  const description = String(fields.description || "").trim();
  const category = ["attestation", "tkt", "other"].includes(fields.category)
  ? fields.category
: "attestation";
  if (!title) return redirect(res, "/admin");
  const info = db
.prepare("INSERT INTO courses (title, description, category, created_at) VALUES (?, ?, ?, ?)")
.run(title, description, category, nowISO());
  redirect(res, `/admin/course/${Number(info.lastInsertRowid)}`);
  return;
  }

  const adminCourseMatch = p.match(/^\/admin\/course\/(\d+)(\/delete)?$/);
  if (adminCourseMatch) {
  if (!admin) return redirect(res, "/admin/login");
  const courseId = Number(adminCourseMatch[1]);
  const course = db.prepare("SELECT * FROM courses WHERE id = ?").get(courseId);
  if (!course) return notFound(res, user, admin);

  if (adminCourseMatch[2] === "/delete" && method === "POST") {  const lessons = db.prepare("SELECT * FROM lessons WHERE course_id = ?").all(courseId);
  lessons.forEach((l) => {
  if (l.file_id) {
  try {
  fs.unlinkSync(path.join(STORAGE_DIR, l.file_id));
  } catch (e) {}
  }
  db.prepare("DELETE FROM questions WHERE lesson_id = ?").run(l.id);
  db.prepare("DELETE FROM progress WHERE lesson_id = ?").run(l.id);
  db.prepare("SELECT file_id FROM materials WHERE lesson_id = ?")
.all(l.id)
.forEach((m) => {
  if (!m.file_id) return;
  try {
  fs.unlinkSync(path.join(STORAGE_DIR, m.file_id));
  } catch (e) {}
  });
  db.prepare("DELETE FROM materials WHERE lesson_id = ?").run(l.id);
  });
  db.prepare("DELETE FROM purchases WHERE lesson_id IN (SELECT id FROM lessons WHERE course_id = ?)").run(courseId);
  db.prepare("DELETE FROM lessons WHERE course_id = ?").run(courseId);
  db.prepare("DELETE FROM enrollments WHERE course_id = ?").run(courseId);
  db.prepare("DELETE FROM courses WHERE id = ?").run(courseId);
  redirect(res, "/admin");
  return;
  }

  if (!adminCourseMatch[2] && method === "POST") {
  const title = String(fields.title || "").trim();
  const description = String(fields.description || "").trim();
  const category = ["attestation", "tkt", "other"].includes(fields.category)
  ? fields.category
: course.category || "attestation";
  if (title) {
  db.prepare("UPDATE courses SET title = ?, description = ?, category = ? WHERE id = ?").run(
  title,
  description,
  category,
  courseId
  );
  }
  redirect(res, `/admin/course/${courseId}?saved=1`);
  return;
  }

  if (method === "GET") {
  const lessons = db
.prepare(
  `SELECT l.*, (SELECT COUNT(*) FROM questions q WHERE q.lesson_id = l.id) AS qcount
  FROM lessons l WHERE l.course_id = ? ORDER BY l.position, l.id`
  )
.all(courseId);

  const rows = lessons.length
  ? lessons
.map(
  (l, i) => `<tr>
  <td>${i + 1}</td>
  <td><b>${h(l.title)}</b><br><small class="muted">${h(
  l.type === "pdf" ? l.file_name || "PDF": l.type === "video" ? l.video_url: ""
  )}</small>${Number(l.price) > 0 ? `<br><small class="muted">${formatSum(l.price)} so'm. PRO</small>`: ""}
  <details class="q-edit">
  <summary>Tahrirlash</summary>
  <form method="post" action="/admin/lesson/${l.id}/update" class="form">
  <div class="field"><label>Nomi</label><input name="title" value="${h(l.title)}" required></div>
  ${
  l.type === "test"
  ? `<div class="grid two">
  <div class="field"><label>Ajratilgan vaqt (daqiqa)</label><input type="number" name="duration_min" min="1" max="180" value="${
  Number(l.duration_min) || 30
  }"></div>
  <div class="field"><label>Savollar soni</label><input type="number" name="question_count" min="0" max="500" value="${
  Number(l.question_count) || 0
  }"><small class="muted">0   haqiqiy savollar soni</small></div>
  <div class="field"><label>Eng yuqori ball</label><input type="number" name="max_score" min="0" max="1000" value="${
  Number(l.max_score) || 100
  }"></div>
  <div class="field"><label>Narx (so'm)</label><input type="number" name="price" min="0" step="1000" value="${
  Number(l.price) || 0
  }"><small class="muted">0   bepul</small></div>
  </div>`
: ""
  }
  <button class="btn btn-sm btn-primary" type="submit">Saqlash</button>
  </form>
  </details>
  </td>
  <td>${typeBadge(l.type)}</td>
  <td>${l.type === "test" ? l.qcount: " "}</td>
  <td class="ta-right">
  ${l.type === "test" ? `<a class="btn btn-sm" href="/admin/lesson/${l.id}/questions">Savollar</a>`: ""}
  ${l.type === "test" ? `<a class="btn btn-sm" href="/admin/lesson/${l.id}/materials">Materiallar</a>`: ""}
  ${l.type === "test" && Number(l.price) > 0 ? `<a class="btn btn-sm" href="/admin/lesson/${l.id}/access">Ruxsat</a>`: ""}
  <form method="post" action="/admin/lesson/${l.id}/delete" class="inline" onsubmit="return confirm('Dars ochirilsinmi?')">
  <button class="btn btn-sm btn-danger" type="submit">O'chirish</button>
  </form>
  </td>
  </tr>`
  )
.join("")
: `<tr><td colspan="5" class="muted">Hozircha darslar yo'q.</td></tr>`;

  const body = `
  <a class="back" href="/admin">  Admin panel</a>
  <div class="page-head">
  <div><h1>${h(course.title)}</h1><p class="muted">${h(course.description || "")}</p></div>
  </div>
  ${url.searchParams.get("saved") === "1" ? alertBox("Saqlandi.", "success"): ""}

  <div class="card" id="edit-course">
  <h2>Kurs nomini tahrirlash</h2>
  <form method="post" action="/admin/course/${course.id}" class="form">
  <div class="field"><label>Kurs nomi</label><input name="title" value="${h(course.title)}" required></div>
  <div class="field"><label>Tavsif</label><textarea name="description" rows="2">${h(
  course.description || ""
  )}</textarea></div>
  <div class="field">
  <label>Yo'nalish</label>
  <select name="category">
  ${[
  ["attestation", "Attestatsiya"],
  ["tkt", "TKT"],
  ["other", "Boshqa"]
  ]
.map(
  ([value, label]) =>
  `<option value="${value}"${(course.category || "attestation") === value ? " selected": ""}>${label}</option>`
  )
.join("")}
  </select>
  </div>
  <button class="btn btn-primary" type="submit">Saqlash</button>
  </form>
  </div>

  <div class="card">
  <h2>Darslar</h2>
  <div class="table-wrap">
  <table>
  <thead><tr><th>#</th><th>Nomi</th><th>Turi</th><th>Savollar</th><th></th></tr></thead>
  <tbody>${rows}</tbody>
  </table>
  </div>
  </div>

  <div class="card" id="new-lesson">
  <h2>Yangi dars</h2>
  <form method="post" action="/admin/lesson" enctype="multipart/form-data" class="form">
  <input type="hidden" name="course_id" value="${course.id}">
  <div class="field"><label>Dars nomi</label><input name="title" required placeholder="Masalan: Modul 1   Metodika"></div>
  <div class="field">
  <label>Dars turi</label>
  <select name="type" id="lessonType">
  <option value="text">Matn</option>
  <option value="pdf">PDF fayl</option>
  <option value="video">Video (havola)</option>
  <option value="test">Test</option>
  </select>
  </div>
  <div class="field" data-for="text,test">
  <label>Matn / o'qish matni</label>
  <textarea name="content" rows="6" placeholder="Dars matni yoki test uchun reading passage..."></textarea>
  </div>
  <div class="field" data-for="pdf">
  <label>PDF fayl (maks. ${config.maxUploadMb} MB)</label>
  <input type="file" name="file" accept="application/pdf,.pdf">
  </div>
  <div class="field" data-for="video">
  <label>Video havolasi</label>
  <input name="video_url" placeholder="https://youtu.be/... yoki https://.../video.mp4">
  <small class="muted">YouTube'da unlisted qilib qo'ying   havola orqali ko'rinadi.</small>
  </div>
  <div class="field" data-for="video">
  <label>Yoki video fayl yuklang (maks. 1 GB)</label>
  <input type="file" name="video" accept="video/mp4,video/webm,video/quicktime,.mp4,.webm,.mov,.m4v,.mkv">
  <small class="muted">MP4 tavsiya etiladi. Videoni faqat admin yuklay oladi.</small>
  </div>
  <div class="field" data-for="test">
  <label>Test davomiyligi (daqiqa)</label>
  <input type="number" name="duration_min" min="1" max="180" value="30">
  <small class="muted">Test yaratilgach, Savollar bo'limida savollarni qo'shasiz.</small>
  </div>
  <div class="field" data-for="test">
  <label>Narx (so'm)</label>
  <input type="number" name="price" min="0" step="1000" value="0">
  <small class="muted">0   bepul. Narx kiritilsa, test PRO bo'ladi va to'lovdan keyin ochiladi.</small>
  </div>
  <div class="field" data-for="test">
  <label>Maksimal ball</label>
  <input type="number" name="max_score" min="0" max="1000" value="100">
  </div>
  <div class="field" data-for="test">
  <label>E'lon qilinadigan savollar soni</label>
  <input type="number" name="question_count" min="0" max="500" value="0">
  <small class="muted">0 bo'lsa, kiritilgan savollar soni ko'rsatiladi.</small>
  </div>
  <button class="btn btn-primary" type="submit">Dars qo'shish</button>
  </form>
  <script>
  (function () {
  var type = document.getElementById('lessonType');
  function sync() {
  document.querySelectorAll('[data-for]').forEach(function (el) {
  el.style.display = el.getAttribute('data-for').split(',').indexOf(type.value) !== -1 ? '': 'none';
  });
  }
  type.addEventListener('change', sync);
  sync();
  })();
  </script>
  </div>`;
  send(res, 200, layout({ title: course.title, body, admin }));
  return;
  }
  }

  if (p === "/admin/lesson" && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const courseId = Number(fields.course_id);
  const course = db.prepare("SELECT * FROM courses WHERE id = ?").get(courseId);
  if (!course) return redirect(res, "/admin");

  const title = String(fields.title || "").trim();
  const type = String(fields.type || "text");
  if (!title || !["text", "pdf", "video", "test"].includes(type)) {
  redirect(res, `/admin/course/${courseId}?err=invalid`);
  return;
  }

  let content = String(fields.content || "").trim();
  let videoUrl = String(fields.video_url || "").trim();
  let fileId = "";
  let fileName = "";
  let fileSize = 0;

  if (type === "pdf") {
  const file = files.file;
  if (!file || !file.size) {
  redirect(res, `/admin/course/${courseId}?err=nofile`);
  return;
  }
  if (file.size > MAX_UPLOAD) {
  redirect(res, `/admin/course/${courseId}?err=big`);
  return;
  }
  const isPdf =
  file.type === "application/pdf" ||
  (file.buffer.length > 4 && file.buffer.slice(0, 4).toString() === "%PDF");
  if (!isPdf) {
  redirect(res, `/admin/course/${courseId}?err=notpdf`);
  return;
  }
  fileId = `${randomBytes(12).toString("hex")}.pdf`;
  fs.writeFileSync(path.join(STORAGE_DIR, fileId), file.buffer);
  fileName = file.name;
  fileSize = file.size;
  }

  if (type === "video") {
  const videoFile = files.video;
  if (videoFile && videoFile.size) {
  const ext = (path.extname(videoFile.name || "") || ".mp4").toLowerCase();
  const allowed = [".mp4", ".webm", ".mov", ".m4v", ".mkv"];
  if (!allowed.includes(ext) || !/^video\//i.test(String(videoFile.type || ""))) {
  redirect(res, `/admin/course/${courseId}?err=notvideo`);
  return;
  }
  if (videoFile.size > 1024 * 1024 * 1024) {
  redirect(res, `/admin/course/${courseId}?err=big`);
  return;
  }
  fileId = `${randomBytes(12).toString("hex")}${ext}`;
  fs.writeFileSync(path.join(STORAGE_DIR, fileId), videoFile.buffer);
  fileName = videoFile.name;
  fileSize = videoFile.size;
  videoUrl = "";
  }
  }

  if (type === "video" && !fileId && videoUrl && !/^https?:\/\//i.test(videoUrl)) {
  redirect(res, `/admin/course/${courseId}?err=badurl`);
  return;
  }

  const position = db
.prepare("SELECT COALESCE(MAX(position), 0) + 1 AS n FROM lessons WHERE course_id = ?")
.get(courseId).n;

  const durationMin = Math.min(180, Math.max(1, Number(fields.duration_min) || 30));
  const price = type === "test" ? Math.max(0, Math.round(Number(fields.price) || 0)): 0;
  const isPro = price > 0 ? 1: 0;
  const maxScore = type === "test" ? Math.min(1000, Math.max(0, Number(fields.max_score) || 100)): 0;
  const questionCount = type === "test" ? Math.min(500, Math.max(0, Number(fields.question_count) || 0)): 0;

  const info = db
.prepare(
  `INSERT INTO lessons
  (course_id, title, type, content, video_url, file_id, file_name, file_size, duration_min, price, is_pro, max_score, question_count, position, created_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
  )
.run(
  courseId,
  title,
  type,
  content,
  videoUrl,
  fileId,
  fileName,
  fileSize,
  durationMin,
  price,
  isPro,
  maxScore,
  questionCount,
  position,
  nowISO()
  );

  const lessonId = Number(info.lastInsertRowid);
  if (type === "test") redirect(res, `/admin/lesson/${lessonId}/questions`);
  else redirect(res, `/admin/course/${courseId}`);
  return;
  }

  const adminLessonMatch = p.match(/^\/admin\/lesson\/(\d+)(\/questions|\/sections|\/rename|\/update|\/delete|\/access|\/materials|\/about)?$/);
  if (adminLessonMatch) {
  if (!admin) return redirect(res, "/admin/login");
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(Number(adminLessonMatch[1]));
  if (!lesson) return notFound(res, user, admin);

  if ((adminLessonMatch[2] === "/rename" || adminLessonMatch[2] === "/update") && method === "POST") {
  const title = String(fields.title || "").trim();
  if (title) db.prepare("UPDATE lessons SET title = ? WHERE id = ?").run(title, lesson.id);
  if (adminLessonMatch[2] === "/update" && lesson.type === "test") {
  const duration = Math.min(180, Math.max(1, Number(fields.duration_min) || lesson.duration_min || 30));
  const qcount = Math.min(500, Math.max(0, Number(fields.question_count) || 0));
  const maxScore = Math.min(1000, Math.max(0, Number(fields.max_score) || 0));
  const price = Math.max(0, Math.round(Number(fields.price) || 0));
  db.prepare(
  "UPDATE lessons SET duration_min = ?, question_count = ?, max_score = ?, price = ?, is_pro = ? WHERE id = ?"
  ).run(duration, qcount, maxScore, price, price > 0 ? 1: 0, lesson.id);
  }
  redirect(res, `/admin/course/${lesson.course_id}?saved=1`);
  return;
  }

  if (adminLessonMatch[2] === "/delete" && method === "POST") {
  if (lesson.file_id) {
  try {
  fs.unlinkSync(path.join(STORAGE_DIR, lesson.file_id));
  } catch (e) {}
  }
  db.prepare("DELETE FROM questions WHERE lesson_id = ?").run(lesson.id);
  db.prepare("DELETE FROM test_sections WHERE lesson_id = ?").run(lesson.id);
  db.prepare("DELETE FROM progress WHERE lesson_id = ?").run(lesson.id);
  db.prepare("DELETE FROM purchases WHERE lesson_id = ?").run(lesson.id);
  db.prepare("SELECT file_id FROM materials WHERE lesson_id = ?")
.all(lesson.id)
.forEach((m) => {
  if (!m.file_id) return;
  try {
  fs.unlinkSync(path.join(STORAGE_DIR, m.file_id));
  } catch (e) {}
  });
  db.prepare("DELETE FROM materials WHERE lesson_id = ?").run(lesson.id);
  db.prepare("DELETE FROM lessons WHERE id = ?").run(lesson.id);
  redirect(res, `/admin/course/${lesson.course_id}`);
  return;
  }

  if (adminLessonMatch[2] === "/about" && method === "POST") {
  const about = String(fields.about || "").trim().slice(0, 5000);
  db.prepare("UPDATE lessons SET about = ? WHERE id = ?").run(about, lesson.id);
  redirect(res, `/admin/lesson/${lesson.id}/materials?saved=1`);
  return;
  }

  if (adminLessonMatch[2] === "/materials" && method === "POST") {
  const title = String(fields.title || "").trim();
  const type = ["pdf", "link", "text"].includes(fields.type) ? fields.type: "link";
  const urlValue = String(fields.url || "").trim();
  const bodyValue = String(fields.body || "").trim();
  let fileId = "";
  let fileName = "";
  let fileSize = 0;

  const fail = (code) => redirect(res, `/admin/lesson/${lesson.id}/materials?err=${code}`);

  if (!title) return fail("title");
  if (type === "pdf") {
  const file = files.file;
  if (!file || !file.size) return fail("nofile");
  if (file.size > MAX_UPLOAD) return fail("big");
  const isPdf =
  file.type === "application/pdf" ||
  (file.buffer.length > 4 && file.buffer.subarray(0, 4).toString() === "%PDF");
  if (!isPdf) return fail("notpdf");
  fileId = `${randomBytes(12).toString("hex")}.pdf`;
  fs.writeFileSync(path.join(STORAGE_DIR, fileId), file.buffer);
  fileName = file.name;
  fileSize = file.size;
  } else if (type === "link") {
  if (!/^https?:\/\//i.test(urlValue)) return fail("badurl");
  } else if (!bodyValue) {
  return fail("body");
  }

  db.prepare(
  `INSERT INTO materials (lesson_id, title, type, url, file_id, file_name, file_size, body, created_at)
  VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`
  ).run(lesson.id, title, type, type === "link" ? urlValue: "", fileId, fileName, fileSize, bodyValue, nowISO());
  redirect(res, `/admin/lesson/${lesson.id}/materials?saved=1`);
  return;
  }

  if (adminLessonMatch[2] === "/materials" && method === "GET") {
  const materials = db.prepare("SELECT * FROM materials WHERE lesson_id = ? ORDER BY id").all(lesson.id);
  const err = url.searchParams.get("err");
  const errText =
  {
  title: "Material sarlavhasini kiriting.",
  nofile: "PDF faylni tanlang.",
  big: "Fayl hajmi juda katta.",
  notpdf: "Faqat PDF fayl yuklash mumkin.",
  badurl: "Havola http:// yoki https:// bilan boshlanishi kerak.",
  body: "Matn kiriting."
  }[err] || "";

  const list = materials.length
  ? materials
.map(
  (m) => `<div class="material-admin-row">
  <span class="material-ico">${icon(m.type === "pdf" ? "file": m.type === "link" ? "link": "book")}</span>
  <div class="material-main">
  <b>${h(m.title)}</b>
  <small class="muted">${m.type === "pdf" ? `PDF. ${formatSize(m.file_size)}`: m.type === "link" ? h(m.url): "Matn"}</small>
  </div>
  <form method="post" action="/admin/material/${m.id}/delete" class="inline" onsubmit="return confirm('Material ochirilsinmi?')">
  <button class="btn btn-sm btn-danger" type="submit">O'chirish</button>
  </form>
  </div>`
  )
.join("")
: `<p class="muted">Hozircha material yo'q.</p>`;

  const body = `
  <a class="back" href="/admin/course/${lesson.course_id}">  Kurs</a>
  <div class="page-head">
  <div><h1>${h(lesson.title)}</h1><p class="muted">Test paneli. tavsif va materiallar</p></div>
  </div>
  ${url.searchParams.get("saved") ? alertBox("Saqlandi.", "success"): ""}
  ${errText ? alertBox(errText): ""}

  <div class="card">
  <h2>Test tavsifi</h2>
  <p class="muted small">Bu matn test sahifasidagi Test haqida bo'limida ko'rinadi.</p>
  <form method="post" action="/admin/lesson/${lesson.id}/about" class="form">
  <div class="field"><textarea name="about" rows="5" placeholder="Test haqida qisqa ma'lumot...">${h(lesson.about || "")}</textarea></div>
  <button class="btn btn-primary" type="submit">Tavsifni saqlash</button>
  </form>
  </div>

  <div class="card">
  <div class="card-head"><h2>Materiallar</h2><a class="btn btn-sm" href="/admin/lesson/${lesson.id}/questions">Savollar</a></div>
  <div class="material-admin-list">${list}</div>

  <h3 style="margin-top:22px">Yangi material</h3>
  <form method="post" action="/admin/lesson/${lesson.id}/materials" enctype="multipart/form-data" class="form">
  <input type="hidden" name="action" value="add">
  <div class="field"><label>Sarlavha</label><input name="title" required placeholder="Masalan: Reading qo'llanma"></div>
  <div class="field">
  <label>Turi</label>
  <select name="type" id="materialType">
  <option value="pdf">PDF fayl</option>
  <option value="link">Havola</option>
  <option value="text">Matn</option>
  </select>
  </div>
  <div class="field" data-mfor="pdf">
  <label>PDF fayl (maks. ${config.maxUploadMb} MB)</label>
  <input type="file" name="file" accept="application/pdf,.pdf">
  </div>
  <div class="field" data-mfor="link">
  <label>Havola</label>
  <input name="url" placeholder="https://...">
  </div>
  <div class="field" data-mfor="text">
  <label>Matn</label>
  <textarea name="body" rows="5" placeholder="Material matni..."></textarea>
  </div>
  <button class="btn btn-primary" type="submit">Material qo'shish</button>
  </form>
  <script>
  (function () {
  var type = document.getElementById('materialType');
  function sync() {
  document.querySelectorAll('[data-mfor]').forEach(function (el) {
  el.style.display = el.getAttribute('data-mfor') === type.value ? '': 'none';
  });
  }
  type.addEventListener('change', sync);
  sync();
  })();
  </script>
  </div>`;
  send(res, 200, layout({ title: "Test paneli", body, admin }));
  return;
  }

  if (adminLessonMatch[2] === "/access" && method === "POST") {
  const userId = Number(fields.user_id);
  if (userId) {
  if (fields.action === "remove") {
  db.prepare("DELETE FROM purchases WHERE user_id = ? AND lesson_id = ?").run(userId, lesson.id);
  } else {
  db.prepare("INSERT OR IGNORE INTO purchases (user_id, lesson_id, created_at) VALUES (?, ?, ?)").run(
  userId,
  lesson.id,
  nowISO()
  );
  }
  }
  redirect(res, `/admin/lesson/${lesson.id}/access`);
  return;
  }

  if (adminLessonMatch[2] === "/access" && method === "GET") {
  const users = db.prepare("SELECT id, name, phone FROM users ORDER BY name").all();
  const owned = new Set(
  db
.prepare("SELECT user_id FROM purchases WHERE lesson_id = ?")
.all(lesson.id)
.map((r) => r.user_id)
  );
  const rows = users.length
  ? users
.map(
  (u) => `<tr>
  <td><b>${h(u.name)}</b><br><small class="muted">${h(u.phone)}</small></td>
  <td>${owned.has(u.id) ? `<span class="badge done">Ochilgan</span>`: `<span class="muted"> </span>`}</td>
  <td class="ta-right">
  <form method="post" action="/admin/lesson/${lesson.id}/access" class="inline">
  <input type="hidden" name="user_id" value="${u.id}">
  <input type="hidden" name="action" value="${owned.has(u.id) ? "remove": "add"}">
  <button class="btn btn-sm ${owned.has(u.id) ? "btn-danger": "btn-primary"}" type="submit">${
  owned.has(u.id) ? "Yopish": "Ochish"
  }</button>
  </form>
  </td>
  </tr>`
  )
.join("")
: `<tr><td colspan="3" class="muted">Hozircha o'quvchilar yo'q.</td></tr>`;

  const body = `
  <a class="back" href="/admin/course/${lesson.course_id}">  Kurs</a>
  <div class="page-head">
  <div><h1>${h(lesson.title)}</h1><p class="muted">Test narxi: ${formatSum(lesson.price)} so'm. PRO ruxsatlar</p></div>
  </div>
  <div class="card">
  <h2>Kimga ochilgan</h2>
  <div class="table-wrap">
  <table>
  <thead><tr><th>O'quvchi</th><th>Holat</th><th></th></tr></thead>
  <tbody>${rows}</tbody>
  </table>
  </div>
  </div>`;
  send(res, 200, layout({ title: "Ruxsatlar", body, admin }));
  return;
  }

  if (adminLessonMatch[2] === "/questions" && method === "GET") {
  const questions = db.prepare("SELECT * FROM questions WHERE lesson_id = ? ORDER BY id").all(lesson.id);
  const sectionCount = db
.prepare("SELECT COUNT(*) AS n FROM test_sections WHERE lesson_id = ?")
.get(lesson.id).n;
  const list = questions.length
  ? questions
.map(
  (q, i) => `<div class="question-item">
  <div><b>${i + 1}. ${h(q.text)}</b>${String(q.passage || "").trim() ? ` <span class="badge done">matn</span>`: ""}</div>
  <div class="muted small">To'g'ri javob: ${q.correct}) ${h(q["o" + q.correct])}</div>
  <details class="q-edit">
  <summary>Tahrirlash</summary>
  <form method="post" action="/admin/question/${q.id}/update" class="form">
  <div class="field"><label>Savol matni</label><input name="text" value="${h(q.text)}" required></div>
  <div class="grid two">
  <div class="field"><label>1-variant</label><input name="o1" value="${h(q.o1)}" required></div>
  <div class="field"><label>2-variant</label><input name="o2" value="${h(q.o2)}" required></div>
  <div class="field"><label>3-variant</label><input name="o3" value="${h(q.o3)}" required></div>
  <div class="field"><label>4-variant</label><input name="o4" value="${h(q.o4)}" required></div>
  </div>
  <div class="field">
  <label>To'g'ri javob</label>
  <select name="correct">
  ${[1, 2, 3, 4]
.map(
  (n) =>
  `<option value="${n}"${Number(q.correct) === n ? " selected": ""}>${n}-variant</option>`
  )
.join("")}
  </select>
  </div>
  </div>
  <div class="field"><label>Matn (savol yonida chiqadigan passage)</label><textarea name="passage" rows="5" placeholder="Bo'sh bo'lsa bo'lim matni yoki umumiy matn ishlatiladi">${h(q.passage || "")}</textarea></div>
  <button class="btn btn-primary btn-sm" type="submit">Saqlash</button>
  </form>
  </details>
  <form method="post" action="/admin/question/${q.id}/delete" class="inline" onsubmit="return confirm('Savol ochirilsinmi?')">
  <button class="btn btn-sm btn-danger" type="submit">O'chirish</button>
  </form>
  </div>`
  )
.join("")
: `<p class="muted">Hozircha savollar yo'q.</p>`;

  const body = `
  <a class="back" href="/admin/course/${lesson.course_id}">  Kurs</a>
  <div class="page-head">
  <div><h1>${h(lesson.title)}</h1><p class="muted">Test savollari. ${questions.length} ta</p></div>
  <div class="actions"><a class="btn btn-ghost btn-sm" href="/admin/lesson/${lesson.id}/sections">Bo'limlar va matnlar${
  sectionCount ? ` (${sectionCount})`: ""
  }</a></div>
  </div>
  ${
  url.searchParams.get("imported")
  ? alertBox(`${url.searchParams.get("imported")} ta savol muvaffaqiyatli qo'shildi.`, "success")
: ""
  }
  ${
  url.searchParams.get("err")
  ? alertBox(
  {
  nofile: "Fayl tanlanmadi.",
  format: "Faqat.xlsx yoki.docx fayl qabul qilinadi.",
  empty: "Fayldan savollar topilmadi. Formatni tekshiring."
  }[url.searchParams.get("err")] || "Yuklashda xatolik.",
  "error"
  )
: ""
  }
  <div class="card"><div class="question-list">${list}</div></div>
  <div class="card">
  <h2>Yangi savol</h2>
  <form method="post" action="/admin/lesson/${lesson.id}/question" class="form">
  <div class="field"><label>Savol matni</label><input name="text" required></div>
  <div class="grid two">
  <div class="field"><label>1-variant</label><input name="o1" required></div>
  <div class="field"><label>2-variant</label><input name="o2" required></div>
  <div class="field"><label>3-variant</label><input name="o3" required></div>
  <div class="field"><label>4-variant</label><input name="o4" required></div>
  </div>
  <div class="field">
  <label>To'g'ri javob</label>
  <select name="correct">
  <option value="1">1-variant</option>
  <option value="2">2-variant</option>
  <option value="3">3-variant</option>
  <option value="4">4-variant</option>
  </select>
  </div>
  <div class="field"><label>Matn (ixtiyoriy   savol yonida chiqadi)</label><textarea name="passage" rows="5" placeholder="Passage matni. Bo'sh qoldirsangiz   bo'lim matni yoki birinchi 15 savol uchun umumiy matn."></textarea></div>
  <button class="btn btn-primary" type="submit">Savol qo'shish</button>
  </form>
  </div>

  <div class="card">
  <h2>Excel / Word dan yuklash</h2>
  <p class="muted small">Tayyor savollarni <b>.xlsx</b> yoki <b>.docx</b> fayldan bir marta yuklab, testni to'ldirish mumkin. Maksimal 500 savol.</p>
  <div class="actions" style="margin-bottom:14px">
  <a class="btn btn-ghost btn-sm" href="/admin/template/xlsx">x  Namuna Excel faylni yuklab olish</a>
  </div>
  <form method="post" action="/admin/lesson/${lesson.id}/import" enctype="multipart/form-data" class="form">
  <div class="field">
  <label>Fayl (.xlsx yoki.docx)</label>
  <input type="file" name="file" accept=".xlsx,.docx" required>
  </div>
  <button class="btn btn-primary" type="submit">Yuklash</button>
  </form>
  <details class="q-edit">
  <summary>Fayl formati qanday bo'lishi kerak?</summary>
  <p class="muted small"><b>Excel:</b> birinchi qator sarlavha   <b>Savol | A | B | C | D | Javob | Matn</b>. Javob ustuniga A/B/C/D yoki 1 4 yoziladi. Matn ustuni ixtiyoriy.</p>
  <p class="muted small"><b>Word:</b> har bir savol shunday yoziladi:</p>
  <p class="muted small" style="white-space:pre-line">1. Savol matni
A) birinchi variant
B) ikkinchi variant
C) uchinchi variant
D) to'rtinchi variant
Javob: B
Matn: passage matni (ixtiyoriy)</p>
  </details>
  </div>`;
  send(res, 200, layout({ title: "Test savollari", body, admin }));
  return;
  }

  if (adminLessonMatch[2] === "/sections" && method === "GET") {
  const secs = db
.prepare("SELECT * FROM test_sections WHERE lesson_id = ? ORDER BY position, id")
.all(lesson.id);
  const qcount = db.prepare("SELECT COUNT(*) AS n FROM questions WHERE lesson_id = ?").get(lesson.id).n;
  const list = secs.length
  ? secs
.map(
  (s, i) => `<div class="card section-item">
  <form method="post" action="/admin/section/${s.id}" class="form">
  <div class="grid two">
  <div class="field"><label>Bo'lim nomi</label><input name="title" value="${h(s.title)}" required></div>
  <div class="field"><label>Savollar oralig'i</label>
  <div class="range-row">
  <input name="from_no" type="number" min="1" value="${s.from_no}" required>
  <span class="muted"> </span>
  <input name="to_no" type="number" min="0" value="${s.to_no}">
  </div>
  <small class="muted">0 = oxirgi savolgacha</small>
  </div>
  </div>
  <div class="field"><label>Matn (shu bo'lim savollari yonida chiqadi)</label>
  <textarea name="passage" rows="6" placeholder="Bo'sh bo'lsa matn ko'rsatilmaydi">${h(s.passage || "")}</textarea>
  </div>
  <div class="actions">
  <button class="btn btn-primary btn-sm" type="submit">Saqlash</button>
  <span class="muted small">${i + 1}-bo'lim</span>
  </div>
  </form>
  <form method="post" action="/admin/section/${s.id}/delete" class="inline" onsubmit="return confirm('Bolim ochirilsinmi? Savollar ochmaydi.')">
  <button class="btn btn-sm btn-danger" type="submit">Bo'limni o'chirish</button>
  </form>
  </div>`
  )
.join("")
: `<p class="muted">Hozircha bo'limlar sozlanmagan. Standart: 1 35 va 36 oxiri.</p>`;

  const body = `
  <a class="back" href="/admin/lesson/${lesson.id}/questions">  Savollar</a>
  <div class="page-head"><div><h1>${h(lesson.title)}</h1><p class="muted">Bo'limlar va matnlar. ${qcount} savol</p></div></div>
  <div class="card">
  <b>Qanday ishlaydi?</b>
  <p class="muted small">Har bir bo'lim uchun savollar oralig'ini va matnni belgilang. Shu oraliqdagi savollarda matn chap tomonda, savol o'ng tomonda chiqadi. Matn kiritilmagan bo'limlar oddiy test ko'rinishida bo'ladi. Savolga alohida matn ham qo'shish mumkin   u bo'lim matnidan ustun turadi.</p>
  </div>
  ${list}
  <div class="card">
  <h2>Yangi bo'lim</h2>
  <form method="post" action="/admin/lesson/${lesson.id}/section" class="form">
  <div class="grid two">
  <div class="field"><label>Bo'lim nomi</label><input name="title" placeholder="1-bosqich. Mutaxassislik fani" required></div>
  <div class="field"><label>Savollar oralig'i</label>
  <div class="range-row">
  <input name="from_no" type="number" min="1" value="1" required>
  <span class="muted"> </span>
  <input name="to_no" type="number" min="0" value="0">
  </div>
  <small class="muted">0 = oxirgi savolgacha</small>
  </div>
  </div>
  <div class="field"><label>Matn (ixtiyoriy)</label><textarea name="passage" rows="6" placeholder="Masalan, birinchi 15 savol uchun umumiy matn"></textarea></div>
  <button class="btn btn-primary" type="submit">Bo'lim qo'shish</button>
  </form>
  </div>`;
  send(res, 200, layout({ title: "Bo'limlar", body, admin }));
  return;
  }
  }

  if (p.match(/^\/admin\/lesson\/\d+\/question$/) && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const lessonId = Number(p.split("/")[3]);
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(lessonId);
  if (!lesson) return redirect(res, "/admin");

  const text = String(fields.text || "").trim();
  const o1 = String(fields.o1 || "").trim();
  const o2 = String(fields.o2 || "").trim();
  const o3 = String(fields.o3 || "").trim();
  const o4 = String(fields.o4 || "").trim();
  const correct = Math.min(4, Math.max(1, Number(fields.correct) || 1));
  const passage = String(fields.passage || "").trim().slice(0, 20000);

  if (text && o1 && o2 && o3 && o4) {
  db.prepare(
  "INSERT INTO questions (lesson_id, text, o1, o2, o3, o4, correct, passage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  ).run(lessonId, text, o1, o2, o3, o4, correct, passage);
  }
  redirect(res, `/admin/lesson/${lessonId}/questions`);
  return;
  }

  const questionUpdate = p.match(/^\/admin\/question\/(\d+)\/update$/);
  if (questionUpdate && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const q = db.prepare("SELECT * FROM questions WHERE id = ?").get(Number(questionUpdate[1]));
  if (!q) return redirect(res, "/admin");
  const text = String(fields.text || "").trim();
  const o1 = String(fields.o1 || "").trim();
  const o2 = String(fields.o2 || "").trim();
  const o3 = String(fields.o3 || "").trim();
  const o4 = String(fields.o4 || "").trim();
  const correct = Math.min(4, Math.max(1, Number(fields.correct) || 1));
  const passage = String(fields.passage || "").trim().slice(0, 20000);
  if (text && o1 && o2 && o3 && o4) {
  db.prepare(
  "UPDATE questions SET text = ?, o1 = ?, o2 = ?, o3 = ?, o4 = ?, correct = ?, passage = ? WHERE id = ?"
  ).run(text, o1, o2, o3, o4, correct, passage, q.id);
  }
  redirect(res, `/admin/lesson/${q.lesson_id}/questions`);
  return;
  }

  const sectionAdd = p.match(/^\/admin\/lesson\/(\d+)\/section$/);
  if (sectionAdd && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const lessonId = Number(sectionAdd[1]);
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(lessonId);
  if (!lesson) return redirect(res, "/admin");
  const title = String(fields.title || "").trim() || "Bo'lim";
  const fromNo = Math.max(1, Number(fields.from_no) || 1);
  const toNo = Math.max(0, Number(fields.to_no) || 0);
  const passage = String(fields.passage || "").trim().slice(0, 20000);
  const position =
  db.prepare("SELECT COALESCE(MAX(position), 0) + 1 AS n FROM test_sections WHERE lesson_id = ?").get(lessonId)
.n || 1;
  db.prepare(
  "INSERT INTO test_sections (lesson_id, title, from_no, to_no, passage, position) VALUES (?, ?, ?, ?, ?, ?)"
  ).run(lessonId, title, fromNo, toNo, passage, position);
  redirect(res, `/admin/lesson/${lessonId}/sections`);
  return;
  }

  const sectionEdit = p.match(/^\/admin\/section\/(\d+)(\/delete)?$/);
  if (sectionEdit && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const section = db.prepare("SELECT * FROM test_sections WHERE id = ?").get(Number(sectionEdit[1]));
  if (!section) return redirect(res, "/admin");
  if (sectionEdit[2] === "/delete") {
  db.prepare("DELETE FROM test_sections WHERE id = ?").run(section.id);
  } else {
  const title = String(fields.title || "").trim() || "Bo'lim";
  const fromNo = Math.max(1, Number(fields.from_no) || 1);
  const toNo = Math.max(0, Number(fields.to_no) || 0);
  const passage = String(fields.passage || "").trim().slice(0, 20000);
  db.prepare("UPDATE test_sections SET title = ?, from_no = ?, to_no = ?, passage = ? WHERE id = ?").run(
  title,
  fromNo,
  toNo,
  passage,
  section.id
  );
  }
  redirect(res, `/admin/lesson/${section.lesson_id}/sections`);
  return;
  }

  const lessonImport = p.match(/^\/admin\/lesson\/(\d+)\/import$/);
  if (lessonImport && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const lessonId = Number(lessonImport[1]);
  const lesson = db.prepare("SELECT * FROM lessons WHERE id = ?").get(lessonId);
  if (!lesson) return redirect(res, "/admin");
  const file = files.file;
  if (!file || !file.buffer || !file.buffer.length) {
  redirect(res, `/admin/lesson/${lessonId}/questions?err=nofile`);
  return;
  }
  const ext = path.extname(String(file.name || "")).toLowerCase();
  if (ext !== ".xlsx" && ext !== ".docx") {
  redirect(res, `/admin/lesson/${lessonId}/questions?err=format`);
  return;
  }
  let parsed = [];
  try {
  parsed = ext === ".xlsx" ? parseQuestionsFromXlsx(file.buffer): parseQuestionsFromDocx(file.buffer);
  } catch (e) {
  parsed = [];
  }
  if (!parsed.length) {
  redirect(res, `/admin/lesson/${lessonId}/questions?err=empty`);
  return;
  }
  const insert = db.prepare(
  "INSERT INTO questions (lesson_id, text, o1, o2, o3, o4, correct, passage) VALUES (?, ?, ?, ?, ?, ?, ?, ?)"
  );
  let added = 0;
  for (const q of parsed.slice(0, 500)) {
  insert.run(lessonId, q.text, q.o1, q.o2, q.o3, q.o4, q.correct, q.passage || "");
  added += 1;
  }
  db.prepare("UPDATE lessons SET question_count = ? WHERE id = ? AND question_count = 0").run(added, lessonId);
  redirect(res, `/admin/lesson/${lessonId}/questions?imported=${added}`);
  return;
  }

  const questionDelete = p.match(/^\/admin\/question\/(\d+)\/delete$/);
  if (questionDelete && method === "POST") {
  if (!admin) return redirect(res, "/admin/login");
  const q = db.prepare("SELECT * FROM questions WHERE id = ?").get(Number(questionDelete[1]));
  if (q) {
  db.prepare("DELETE FROM questions WHERE id = ?").run(q.id);
  redirect(res, `/admin/lesson/${q.lesson_id}/questions`);
  } else {
  redirect(res, "/admin");
  }
  return;
  }

  /* ---------------------------------------------------------------- 404 */
  return notFound(res, user, admin);
  } catch (err) {
  console.error("[error]", err);
  send(
  res,
  500,
  layout({
  title: "Server xatosi",
  body: `<div class="card"><h1>Server xatosi</h1><p class="muted">Iltimos, keyinroq qayta urinib ko'ring.</p><a class="btn" href="/">Bosh sahifa</a></div>`
  })
  );
  }
});

function notFound(res, user, admin) {
  send(
  res,
  404,
  layout({
  title: "Topilmadi",
  body: `<div class="card"><h1>Sahifa topilmadi</h1><p class="muted">Havola eskirgan yoki o'chirilgan.</p><a class="btn btn-primary" href="${admin ? "/admin": user ? "/courses": "/"}">Davom etish</a></div>`,
  user,
  admin
  })
  );
}

server.listen(PORT, () => {
  console.log(`Platforma ishga tushdi: http://localhost:${PORT}`);
  console.log(`Admin: http://localhost:${PORT}/admin  (parol: config.json ichida)`);
});

startTournamentScheduler();
startReminderScheduler();
startPlatformBot();

